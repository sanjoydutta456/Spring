# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 20:27:56 2018

@author: 455731
"""

import pyodbc

class CustomerComplaint:
    def __init__(self, name = None, mobileNumber = None, priority = None, complaint = None):
        self.name = name
        self.mobileNumber = mobileNumber
        self.priority = priority
        self.complaint = complaint
        
    def getName(self):
        return self.name
    
    def getMobileNumber(self):
        return self.mobileNumber
    
    def getPriority(self):
        return self.priority
    
    def getComplaint(self):
        return self.complaint
    
    def setName(self, name):
        self.name = name
    
    def setMobileNumber(self, mobileNumber):
        self.mobileNumber = mobileNumber
    
    def setPriority(self, priority):
        self.priority = priority
    
    def setComplaint(self, complaint):
        self.complaint = complaint
    
    def validateMobileNumber(self, mobileNumber):
        if mobileNumber[:].isdigit():
            if len(mobileNumber) == 10:
                return mobileNumber
            else:            
                return None
        else:
            return None
         
            
    def connectToDB(self):
        cnxn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};DATABASE=python_mysql;SERVER=localhost; USER=root; PASSWORD=root;')
        return cnxn
    
    def insertCustomerComplaint(self):
        db = self.connectToDB()
        cur = db.cursor()
        sql = """insert into customerComplaint values('""" + self.name + """','""" + str(self.mobileNumber) + """','""" + str(self.priority) + """','""" + self.complaint + """')"""
        cur.execute(sql)
        db.commit()
        db.close()
        
    def getCustomerComplaintsInOrder(self):
        complaintList = []
        db = self.connectToDB()
        cur = db.cursor()
        sql = "select * from customerComplaint order by priority"
        cur.execute(sql)
        data = cur.fetchall()
        for row in data:
            mb = CustomerComplaint()
            mb.setName(row[0])
            mb.setMobileNumber(row[1])
            mb.setPriority(row[2])
            mb.setComplaint(row[3])
            complaintList.append(mb)
        db.close()
        return complaintList
    
    def getCustomerComplaints(self):
        complaintList = []
        db = self.connectToDB()
        cur = db.cursor()
        sql = "select * from customerComplaint"
        cur.execute(sql)
        data = cur.fetchall()
        for row in data:
            mb = CustomerComplaint()
            mb.setName(row[0])
            mb.setMobileNumber(row[1])
            mb.setPriority(row[2])
            mb.setComplaint(row[3])
            complaintList.append(mb)
        db.close()
        return complaintList
    
    def displayComplaintDetails(self, complaintList):        
        for cc in complaintList:
            print("Name: " + str(cc.getName()))
            print("Mobile Number: " + str(cc.getMobileNumber()))
            print("Priority: " + str(cc.getPriority()))
            print("Complaint: " + str(cc.getComplaint()))
            
    