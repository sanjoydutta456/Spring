# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 14:07:57 2018

@author: 455731
"""

import CustomerComplaint

comObj = CustomerComplaint.CustomerComplaint()

while True:
    print("1.Create Complaint \n2.Display details \n3.Display details in priority order \n4.Exit")
    opt = input()
    if int(opt) == 1:
        print("Enter the name")
        inpName = input()
        print("Enter the mobile number")
        while True:            
            inpMob = input()
            mobNo = comObj.validateMobileNumber(inpMob)
            if mobNo == None:
                print("Invalid Mobile Number \n Enter the valid mobile number")
            else:
                break
        print("1.High \n2.Medium \n3.Low \nEnter the priority")
        inpPri = input()
        print("Enter the Complaint")
        inpCom = input()
        comObjIns = CustomerComplaint.CustomerComplaint()
        comObjIns.setName(inpName)
        comObjIns.setMobileNumber(int(mobNo))
        comObjIns.setPriority(int(inpPri))
        comObjIns.setComplaint(inpCom)
        comObjIns.insertCustomerComplaint()
        print("Complaint registered successfully")
    elif int(opt) == 2:
        comList = comObj.getCustomerComplaints()
        comObj.displayComplaintDetails(comList)
    elif int(opt) == 3:
        comList = comObj.getCustomerComplaintsInOrder()
        comObj.displayComplaintDetails(comList)
    elif int(opt) == 4:
        print("Exit")
        break
        
    
            
        