# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 19:17:19 2018

@author: 455731
"""

import Datausage

usageObj = Datausage.Datausage()

root = usageObj.readXML("usage.xml")
dataUsageList = usageObj.parseXML(root)
usageDict = usageObj.calculateUsage(dataUsageList)

while True:
    print("1) Calculate Usage \n2) Send Alert \n3) Exit")
    opt = input()
    if int(opt) == 1:
        print("CustomerId  \t Total Usage")
        for du in dataUsageList:
            print(du.getCustomerId() + "\t" + str(du.getPulse()))
        for key in usageDict:
            print(str(key) + "\t" + str(usageDict[key]))
    elif int(opt) == 2:
        print("Enter the warning limit")
        inpLim = input()
        usageObj.sendWarningAlert(int(inpLim), usageDict, dataUsageList)
    elif int(opt) == 3:
        print("Exit")
        break
    else:
        print("Invalid Input")
 