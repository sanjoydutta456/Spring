# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 16:37:38 2018

@author: 455731
"""

import xml.etree.ElementTree as ET

class Datausage:
    def __init__(self, customerId = None, limit = None, pulse = None, usageDate = None):
        self.customerId = customerId
        self.limit = limit             
        self.pulse = pulse
        self.usageDate = usageDate
        
    def getCustomerId(self):
        return self.customerId
    
    def getLimit(self):
        return self.limit
    
    def getPulse(self):        
        return self.pulse
    
    def getUsageDate(self):
        return self.usageDate
    
    def setCustomerId(self, customerId):
        self.customerId = customerId
    
    def setLimit(self, limit):
        if limit[:2].isdigit():
            self.limit = limit[:2]
        elif limit[:1].isdigit():
            self.limit = limit[:1]        
    
    def setPulse(self, pulse):
        if pulse[:3].isdigit():
            self.pulse = pulse[:3]
        elif pulse[:2].isdigit():
            self.pulse = pulse[:2]
        elif pulse[:1].isdigit():
            self.pulse = pulse[:1]        
    
    def setUsageDate(self, usageDate):
        self.usageDate = usageDate
        
    def readXML(self, path):        
        with open(path, "r") as xmlFile:
            tree = ET.parse(xmlFile)
            root = tree.getroot()
        return root
    
    def parseXML(self, root):
        dataUsageList = []
        limit = 0
        for child in root:
            cusId = child.attrib.get("id")
            for ch in child.getchildren():
                if ch.tag == "usage":
                    mb = Datausage()
                    mb.setCustomerId(cusId)
                    mb.setLimit(limit)
                    mb.setPulse(ch.find("pulse").text)
                    mb.setUsageDate(ch.find("date").text)
                    dataUsageList.append(mb)
                else:
                    limit = ch.text
        return dataUsageList
    
    def calculateUsage(self, dataUsageList):
        usageDict = {}
        totalUsage = 0
        for du in dataUsageList:
            if du.getCustomerId() in usageDict:
                totalUsage = usageDict[du.getCustomerId()]
                totalUsage += int(du.getPulse())
                usageDict[du.getCustomerId()] = totalUsage
            else:
                totalUsage = 0
                usageDict[du.getCustomerId()] = int(du.getPulse())
        return usageDict
    
    def sendWarningAlert(self, warnLim, usageDict, dataUsageList):
        for key in usageDict:
            for du in dataUsageList:
                if du.getCustomerId() == key:
                    limit = int(du.getLimit())
                    break
            lim = 1024 * limit
            per = int(usageDict[key]) * 100 / lim
            if int(per) > int(warnLim):
                print("Hi " + str(key) + ",\nYou've used about " + str(warnLim) + " of your data plan" )
            else:
                print("Warning Limit Not reached yet")
        