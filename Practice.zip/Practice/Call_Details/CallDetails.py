# -*- coding: utf-8 -*-
"""
Created on Tue Nov 27 12:51:49 2018

@author: 455731
"""
import time
import urllib3
import pyodbc
import re
##import ConfigParser
import xml.etree.ElementTree as ET

class CallDetails:
    def __init__(self, customerId = None, mobileNumber = None, duration = None, amount = None):
        self.customerId = customerId or ""
        self.mobileNumber = mobileNumber or  ""
        self.duration = duration or ""
        self.amount = amount or 0.0
        
    def getCustomerId(self):
        return self.customerId
    
    def getMobileNumber(self):
        return self.mobileNumber
    
    def getDuration(self):
        return self.duration
    
    def getAmount(self):
        return self.amount
    
    def setCustomerId(self, customerId):
        self.customerId = customerId
    
    def setMobileNumber(self, mobileNumber):
        self.mobileNumber = mobileNumber
    
    def setDuration(self, duration):
        self.duration = duration
    
    def setAmount(self, amount):
        self.amount = amount
        
    def readXML(self, path):
        ##req = urllib.request(path, headers = {"Accept" : "application/xml"})
        with open(path, "r") as xmlfile:
        ##u = http.request('GET', 'D:\My Files\Python\Practice\Call_Details\call.xml')
            tree = ET.parse(xmlfile)
            root = tree.getroot()
            return root
        
    def parseXML(self, root):
        callList = []
        for child in root:
            mb = CallDetails()
            mb.setCustomerId(child.find("customerid").text)
            mb.setMobileNumber(child.find("tonumber").text)
            mb.setDuration(child.find("duration").text)
            mb.setAmount(child.find("amount").text)
            callList.append(mb)
        return callList
    
    def generateBill(self, callList):
        db = self.connectToDB()
        cursor = db.cursor()
        for du in callList:
            sql = """insert into datausage values('""" + du.getCustomerId() + """','""" + du.getMobileNumber() + """','""" + du.getDuration() + """','""" + du.getAmount() + """')"""
            cursor.execute(sql)
            db.commit()
        db.close()
            
    def getCallDetails(self):
        callList = []
        db = self.connectToDB()
        sql = "select * from datausage"
        cursor = db.cursor()
        cursor.execute(sql)
        data = cursor.fetchall()
        for r in data:
            mb = CallDetails(r[0], r[1], r[2], r[3])
            callList.append(mb)
        return callList
    
    def displayCallDetails(self, callList):
        for du in callList:
            strTime = time.strptime(du.getDuration(), "%H:%M:%S")
            if strTime.tm_hour >= 2:
                print(du.getCustomerId() + "\t" + du.getMobileNumber() + "\t" + du.getDuration() + "\t" + str(du.getAmount()))
            
    def connectToDB(self):
        cnxn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};DATABASE=python_mysql;SERVER=localhost; USER=root; PASSWORD=root;')
        return cnxn
    
    