# -*- coding: utf-8 -*-
"""
Created on Tue Nov 27 13:58:33 2018

@author: 455731
"""
import CallDetails
callObj = CallDetails.CallDetails()
root = callObj.readXML("call.xml")
callList = callObj.parseXML(root)
insert = 0

while True:
    print("1) Generate Bill \n2) Display the bill details \n3) Exit")
    opt = input()
    if int(opt) == 1:
        if insert == 0:
            callObj.generateBill(callList)
            print("Bill Generated Successfully")
        else:
            print("Bill already generated")
    elif int(opt) == 2:
        callList1 = callObj.getCallDetails()
        print("Customer Id \t Mobile Number \t Duration \t Amount")
        callObj.displayCallDetails(callList1)       
    elif int(opt) == 3:
        print("Exit")
        break