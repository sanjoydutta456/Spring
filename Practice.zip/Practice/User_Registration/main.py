# -*- coding: utf-8 -*-
"""
Created on Fri Nov 30 14:15:42 2018

@author: 455731
"""

import User

userOb = User.User()
print("Enter the name:")
inpName = input()
print("Enter the phone number:")
while True:
    inpNum = input()
    if userOb.validatePhoneNumber(inpNum):
        break        
    else:
        print("Invalid mobile number. \nEnter the valid mobile number")

print("Enter the password:")
while True:
    inpPwd = input()
    if userOb.validatePassword(inpPwd):
        break
    else:
        print("Invalid password. \nEnter the valid password")

print("Enter the email")
while True:
    inpEmail = input()
    if userOb.validateEmail(inpEmail):
        break
    else:
        print("Invalid email. \nEnter the valid email")

print("Name: {0}".format(inpName))
print("PhoneNumber: {0}".format(inpNum))
print("Password: {0}".format(inpPwd))
print("Email: {0}".format(inpEmail))
    

    