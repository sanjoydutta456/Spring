# -*- coding: utf-8 -*-
"""
Created on Fri Nov 30 13:56:50 2018

@author: 455731
"""
import re

class User:
    def __init__(self, name = None, phoneNumber = None, password = None, email = None):
        self.name = name
        self.phoneNumber = phoneNumber
        self.password = password
        self.email = email
        
    def validatePassword(self, password):
        if re.match("^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8}", password):
            return 1
        else:
            return 0
        
    def validatePhoneNumber(self, phoneNumber):
        if re.match("^(?=.*\d).{10}", phoneNumber):
            if len(phoneNumber) == 10:
                return 1
            else:
                return 0
        else:
            return 0
        
    def validateEmail(self, email):
        if re.match("^(?=.*[@])(?=.*[.]).*", email):
            if email.count("@") == 1:
                return 1
            else:
                return 0
        else:
            return 0