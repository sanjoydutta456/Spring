package com.exigen.chartis.chome.policy.components;

import com.exigen.ipb.components.domain.ViewType;
import com.exigen.chartis.chome.policy.domain.TestAuto;
import com.exigen.chartis.chome.policy.components.ChMortgageeComponent;
import com.exigen.ipb.components.domain.ComponentInfo;
import java.util.List;


/**
 * Created by 449301 on 04-12-2014.
 */
public class TestPAutoComponent extends ChMortgageeComponent {

    public TestPAutoComponent() {
        super();
    }

   

    @Override
    public Object getViewModel(ComponentInfo runtimeInstance, List<ComponentInfo> dependencies, ViewType viewType) {

        TestAuto viewModel = (TestAuto) runtimeInstance;
        if (viewModel == null) {
            viewModel = new TestAuto();
        }       
        return viewModel;
    }


}
