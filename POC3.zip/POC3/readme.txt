D:\AIGCodebase\Chartis2\policy\chartis-policy-components\src\main\resources\META-INF\spring\pauto-test-component-beans.xml

D:\AIGCodebase\Chartis2\policy\chartis-policy-components\src\main\java\com\exigen\chartis\chome\policy\components\TestPAutoComponent.java

D:\AIGCodebase\Chartis2\policy\chartis-policy-domain\src\main\java\com\exigen\chartis\chome\policy\domain\TestAuto.java

D:\AIGCodebase\Chartis2\policy\premier-policy\premier-auto\premier-policy-deploy-auto\src\main\resources\db\Premier-1.19\QC-123521-auto-changelog.xml

D:\AIGCodebase\Chartis2\applications\premier-applications\premier-deploy\target\classes\csv\TestPaymentMode_Lookup.data.csv




---------------------------------------------- BUILD WORKSPACE ------------------------------------------------------------

mvn clean

mvn  clean install -Dmaven.test.skip=true -e



D:\AIGCodebase\Chartis2\applications\premier-applications\premier-app\target\premier-app\WEB-INF\lib


------------------------------------------------------------------ UPDATE DB ---------------------------------------------

run following bat file to run liquibase script.

1. D:\AIGCodebase\chartis2Premier\applications\premier-applications\premier-deploy\deploy.bat








