package com.exigen.chartis.chome.policy.domain;

import javax.persistence.Entity;
import com.exigen.chartis.chome.policy.domain.ChMortgagee;
import java.util.Date;

/**
 * Created by 449301 on 04-12-2014.
 */
@Entity
public class TestAuto extends ChMortgagee  {

    private Date tdate;
    private double tamount;
    private String tpaymentMode;

   public Date getTdate() {
        return tdate;
    }

    public void setTdate(Date tdate) {
        this.tdate = tdate;
    }

    public double getTamount() {
        return tamount;
    }

    public void setTamount(double tamount) {
        this.tamount = tamount;
    }

    public String getTpaymentMode() {
        return tpaymentMode;
    }

    public void setTpaymentMode(String tpaymentMode) {
        this.tpaymentMode = tpaymentMode;
    }
}
