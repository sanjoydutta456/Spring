package com.metlife.gsp.classSetup;

import org.junit.Before;
import org.openqa.selenium.WebDriver;

import com.metlife.gsp.login.Login_DEV;

public class ClassSetup_LandingPageTest {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

    

}
