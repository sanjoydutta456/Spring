package com.metlife.gsp.products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.Test;

public class LegalServicesMetlawTest {
	
	@Test
	public void metlaw()throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://int.custadmin.metlife.com");
		WebElement username=driver.findElement(By.id("USER"));
		username.sendKeys("gspcatqauser1");
		WebElement pass=driver.findElement(By.id("PASSWORD"));
		pass.sendKeys("metlife1");
		WebElement enter=driver.findElement(By.id("cmdEnter"));
		enter.click();
		
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MT2");
		WebElement submit=driver.findElement(By.id("SearchButtonIntUser"));
		submit.click();
		Thread.sleep(3000);
		WebElement edit=driver.findElement(By.id("editCustomer"));
		edit.click();
		Thread.sleep(1000);
		
		WebElement legalservices=driver.findElement(By.id("navDashHyatt"));
		legalservices.click();
		Thread.sleep(2000);
		
		//legal services(metlaw)
		WebElement replacementcoverage=driver.findElement(By.id("rdnHyattReplacementCoverageYes"));
		replacementcoverage.click();
		Thread.sleep(1000);
		
		Select typeOfEntity=new Select(driver.findElement(By.id("selecttypeOfEntity")));
		typeOfEntity.selectByIndex(5);
		Thread.sleep(1000);
		
		WebElement stateLocations=driver.findElement(By.id("txtHyattStateLocation"));
		stateLocations.sendKeys("West Bengal");
		Thread.sleep(1000);
		
		WebElement headquartersState=driver.findElement(By.id("txtHyattHeadquartersState"));
		headquartersState.sendKeys("Chennai");
		Thread.sleep(1000);
		
		WebElement incorporatedState=driver.findElement(By.id("txtHyattIncorporatedState"));
		incorporatedState.sendKeys("Karnataka");
		Thread.sleep(1000);
		
		WebElement executiveOffices=driver.findElement(By.id("txtHyattExecutiveOffices"));
		executiveOffices.sendKeys("Kolkata");
		Thread.sleep(1000);
		
		WebElement benefitAdministration=driver.findElement(By.id("txtHyattBenefitAdministration"));
		benefitAdministration.sendKeys("Yes!");
		Thread.sleep(1000);
		
		WebElement largestNoOfEmployees=driver.findElement(By.id("txtHyattLargestNoOfEmployees"));
		largestNoOfEmployees.sendKeys("14");
		Thread.sleep(1000);
		
		WebElement orny=driver.findElement(By.id("rdnHyattEmployeesResideYes"));
		orny.click();
		Thread.sleep(2000);
		
		WebElement specifyState=driver.findElement(By.id("txtHyattSpecifyState"));
		specifyState.sendKeys("WestBengal");
		Thread.sleep(1000);
		
		WebElement expatriates=driver.findElement(By.id("rdnHyattExpatriatesYes"));
		expatriates.click();
		Thread.sleep(1000);
		
		WebElement normalPlanYear=driver.findElement(By.id("txtHyattNormalPlanYear"));
		normalPlanYear.sendKeys("100");
		Thread.sleep(1000);
		
		WebElement numberOfEligibleemployees=driver.findElement(By.id("txtHyattBenefitEligibleEmployess"));
		numberOfEligibleemployees.sendKeys("10");
		Thread.sleep(1000);
		
		WebElement planLocalCode=driver.findElement(By.id("txtHyattPlanLocalCode"));
		planLocalCode.sendKeys("826");
		Thread.sleep(1000);
		
		WebElement planType=driver.findElement(By.id("txtHyattPlanType"));
		planType.sendKeys("A");
		Thread.sleep(1000);
		
		WebElement rate=driver.findElement(By.id("txtHyattRate"));
		rate.sendKeys("5*");
		Thread.sleep(2000);
		
		WebElement save=driver.findElement(By.id("btnHyattSave"));
		save.click();
		Thread.sleep(3000);
		
		WebElement logOut=driver.findElement(By.id("logoutLink"));
		logOut.click();
		Thread.sleep(1000);
		
		WebElement yesBtn=driver.findElement(By.id("btnlogoutYes"));
		yesBtn.click();
		Thread.sleep(1000);
		
		driver.quit();
		
	}

}
