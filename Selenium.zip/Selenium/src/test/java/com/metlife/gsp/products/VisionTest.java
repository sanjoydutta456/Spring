package com.metlife.gsp.products;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VisionTest {
@Test
public void Testing()throws Exception
{
System.setProperty("webdriver.chrome.driver", "D:/Selenium/CromeDriver/chromedriver.exe");
WebDriver driver=new ChromeDriver();
driver.get("https://int.custadmin.metlife.com");
WebElement user=driver.findElement(By.id("USER"));
user.sendKeys("gspcatqauser1");
WebElement pass=driver.findElement(By.id("PASSWORD"));
pass.sendKeys("metlife1");
WebElement login=driver.findElement(By.id("cmdEnter"));
login.click();
Thread.sleep(1000);
WebElement caseId=driver.findElement(By.id("RFPID"));
caseId.sendKeys("1-1F5MT2");
Thread.sleep(1000);
WebElement search=driver.findElement(By.id("SearchButtonIntUser"));
search.click();
Thread.sleep(2000);
WebElement edit=driver.findElement(By.id("editCustomer"));
edit.click();
Thread.sleep(1000);
WebElement productsSold=driver.findElement(By.id("navDashProductsSold"));
productsSold.click();
Thread.sleep(3000);
WebElement vision=driver.findElement(By.id("navProductSold102"));
vision.click();
Thread.sleep(1000);
WebElement yesBtn=driver.findElement(By.id("rdnVisionIsThisReplacementCoverageYes"));
yesBtn.click();
Thread.sleep(1000);
WebElement yesBtnPHI=driver.findElement(By.id("rdnVisionPHIAccessNo"));
yesBtnPHI.click();
Thread.sleep(1000);
//For no button
/*WebElement noBtnPHI=driver.findElement(By.id("rdnVisionPHIAccessYes"));
noBtnPHI.click();
Thread.sleep(1000);*/
WebElement marriage=driver.findElement(By.id("chkVisionMarriage"));
marriage.click();
Thread.sleep(1000);
WebElement birth=driver.findElement(By.id("chkVisionChild"));
birth.click();
Thread.sleep(1000);
WebElement divorce=driver.findElement(By.id("chkVisionDivorce"));
divorce.click();
Thread.sleep(1000);
WebElement death=driver.findElement(By.id("chkVisionDeath"));
death.click();
Thread.sleep(1000);
WebElement change=driver.findElement(By.id("chkVisionSpouse"));
change.click();
Thread.sleep(1000);
WebElement other=driver.findElement(By.id("chkVisionOther"));
other.click();
Thread.sleep(1000);
WebElement textBox=driver.findElement(By.id("txtVisionQualifyingTextBox"));
textBox.sendKeys("Other qualifying events");
Thread.sleep(1000);
WebElement saveBtn=driver.findElement(By.id("btnVisionSave"));
saveBtn.click();
Thread.sleep(3000);
WebElement logout=driver.findElement(By.id("logoutLink"));
logout.click();
Thread.sleep(1000);
WebElement yes=driver.findElement(By.id("btnlogoutViewYes"));
yes.click();
Thread.sleep(1000);
driver.quit();
}

}
