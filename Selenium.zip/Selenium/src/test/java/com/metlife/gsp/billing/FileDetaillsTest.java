package com.metlife.gsp.billing;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class FileDetaillsTest {
	
	@Test
	public void fileDetails()throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		//Writing URL
		driver.get("https://int.custadmin.metlife.com");
		Thread.sleep(1000);
		
		//Writing username and password
		WebElement user=driver.findElement(By.id("USER"));
		user.sendKeys("gspcatqauser1");
		Thread.sleep(2000);
		WebElement pass=driver.findElement(By.id("PASSWORD"));
		pass.sendKeys("metlife1");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("cmdEnter"));
		login.click();
		Thread.sleep(2000);
		driver.manage().window().maximize();

		//Search Page
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MT2");
		Thread.sleep(1000);
		WebElement searchBtn=driver.findElement(By.id("SearchButtonIntUser"));
		searchBtn.click();
		Thread.sleep(1000);
		WebElement edit=driver.findElement(By.id("editCustomer"));
		edit.click();
		Thread.sleep(1000);
		
		
		/*WebElement billingInformation=driver.findElement(By.id("navDashBillInfo"));
		billingInformation.click();
		Thread.sleep(1000);*/
	
		
		//DashBorad Page
		WebElement billingfileDetailtab=driver.findElement(By.id("navDashBillingFileDetailsInfo"));
		billingfileDetailtab.click();
		Thread.sleep(1000);
		
		
		//Eligibility File Details
		//for yes button
		WebElement firstname=driver.findElement(By.id("txtCustCompAssessContactFirstName"));
		firstname.sendKeys("Aniket");
		Thread.sleep(1000);
		WebElement lastname=driver.findElement(By.id("txtCustCompAssessContactLastName"));
		lastname.sendKeys("Das");
		Thread.sleep(1000);
		WebElement phonenumber=driver.findElement(By.id("txtCustCompAssessPhoneNum"));
		phonenumber.sendKeys("7686992600");
		Thread.sleep(1000);
		WebElement email=driver.findElement(By.id("txtCustCompAssessEmailAddress"));
		email.sendKeys("ani999@gmail.com");
		Thread.sleep(1000);
		
		driver.findElement(By.id("rdnCustthirdPartySumbitEnrollmentYes")).click();
		
		Select drpeligibility=new Select(driver.findElement(By.id("selectEligilbityOrParticipantType")));
		drpeligibility.selectByIndex(2);
		Thread.sleep(1000);
		Select drpformat=new Select(driver.findElement(By.id("selectBillingFileFormat")));
		drpformat.selectByIndex(2);
		Thread.sleep(1000);
		Select drpfileformat=new Select(driver.findElement(By.id("selectTypeOfFile")));
		drpfileformat.selectByIndex(1);
		Thread.sleep(1000);
		
		WebElement employeenumber=driver.findElement(By.id("txtEmployeeNumber"));
		employeenumber.sendKeys("CTS9099876");
		Thread.sleep(1000);
		WebElement employeenumberminimum=driver.findElement(By.id("txtEmployeeNumberMinimum"));
		employeenumberminimum.sendKeys("CTS909");
		Thread.sleep(1000);
		WebElement employeenumbermaximum=driver.findElement(By.id("txtEmployeeNumberMaximum"));
		employeenumbermaximum.sendKeys("CTS9099876543");
		Thread.sleep(1000);
		
		WebElement save=driver.findElement(By.id("btnBillingFileDetailsSave"));
		save.click();
		Thread.sleep(3000);
		
		//for no button
		WebElement nobtn=driver.findElement(By.id("rdnCustCompAssessElectronicEnrollmentNo"));
		nobtn.click();
		Thread.sleep(3000);
		driver.findElement(By.id("btnBillingFileDetailsSave")).click();
		
		Thread.sleep(2000);
		
		/*drpeligibility.selectByIndex(0);
		drpformat.selectByIndex(0);
		drpfileformat.selectByIndex(0);
		employeenumber.clear();
		employeenumberminimum.clear();
		employeenumbermaximum.clear();
		
		Thread.sleep(1000);
		drpeligibility.selectByIndex(2);
		drpformat.selectByIndex(1);
		drpfileformat.selectByIndex(1);
		employeenumber.sendKeys("CTS09876");
		employeenumberminimum.sendKeys("CTS098");
		employeenumbermaximum.sendKeys("CTS0987654321");
		save.click();
		Thread.sleep(1000);*/
		
		//Logout
		WebElement logout=driver.findElement(By.id("logoutLink"));
		logout.click();
		WebElement popup=driver.findElement(By.id("btnlogoutYes"));
		popup.click();
		Thread.sleep(2000);
		
		//Window closed
		driver.quit();
			
	}

}
