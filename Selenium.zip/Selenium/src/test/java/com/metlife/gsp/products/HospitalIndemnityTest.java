package com.metlife.gsp.products;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HospitalIndemnityTest {
	
	@Test
	public void indemnity()throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://int.custadmin.metlife.com");
		WebElement username=driver.findElement(By.id("USER"));
		username.sendKeys("gspcatqauser1");
		WebElement pass=driver.findElement(By.id("PASSWORD"));
		pass.sendKeys("metlife1");
		WebElement enter=driver.findElement(By.id("cmdEnter"));
		enter.click();
		
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MS2");
		WebElement submit=driver.findElement(By.id("SearchButtonIntUser"));
		submit.click();
		Thread.sleep(3000);
		WebElement edit=driver.findElement(By.id("editCustomer"));
		edit.click();
		Thread.sleep(1000);
		
		WebElement hospitalindemnity=driver.findElement(By.id("navDashHosIndemn"));
		hospitalindemnity.click();
		Thread.sleep(2000);
		
		WebElement replacementcov=driver.findElement(By.id("rdnHospIndmReplacementCoverageYes"));
		replacementcov.click();
		Thread.sleep(1000);
		
		WebElement retireescov=driver.findElement(By.id("rdnHospIndmRetireesCoveredYes"));
		retireescov.click();
		Thread.sleep(1000);
		
		WebElement expatriates=driver.findElement(By.id("rdnHospIndmExpatriatesYes"));
		expatriates.click();
		Thread.sleep(1000);
		
		WebElement adoption=driver.findElement(By.id("chkHospIndmLifeEventsAB"));
		adoption.click();
		Thread.sleep(1000);
		
		WebElement marriage=driver.findElement(By.id("chkHospIndmLifeEventsMD"));
		marriage.click();
		Thread.sleep(1000);
		
		WebElement death=driver.findElement(By.id("chkHospIndmLifeEventsDT"));
		death.click();
		Thread.sleep(1000);
		
		WebElement other=driver.findElement(By.id("chkHospIndmLifeEventsOT"));
		other.click();
		Thread.sleep(1000);
		
		WebElement othertext=driver.findElement(By.id("txtHospIndmQualifyingOther"));
		othertext.sendKeys("something other than normal reasons");
		Thread.sleep(1000);
		
		Select erisa=new Select(driver.findElement(By.id("selectErisaStatusHI")));
		erisa.selectByIndex(5);
		Thread.sleep(1000);
		
		WebElement erisawrapper=driver.findElement(By.id("rdnHospIndmErisaWrapperYes"));
		erisawrapper.click();
		Thread.sleep(1000);
		
		WebElement premiums=driver.findElement(By.id("rdnHospIndmPremiumTaxPre"));
		premiums.click();
		Thread.sleep(1000);
		
		WebElement enrollmentfirm=driver.findElement(By.id("rdnHospIndmEnrollmentFirmYes"));
		enrollmentfirm.click();
		Thread.sleep(1000);
		
		WebElement onballot=driver.findElement(By.id("rdnHospIndmEnrollmentOnBallot"));
		onballot.click();
		Thread.sleep(1000);
		
		WebElement callcenter=driver.findElement(By.id("rdnHospIndmEnrollmentCallCenter"));
		callcenter.click();
		Thread.sleep(1000);
		
		WebElement onsite=driver.findElement(By.id("rdnHospIndmEnrollmentOnSite"));
		onsite.click();
		Thread.sleep(1000);
		
		WebElement other1=driver.findElement(By.id("rdnHospIndmEnrollmentOther"));
		other1.click();
		Thread.sleep(1000);
		
		WebElement other1text=driver.findElement(By.id("txtHospIndmOtherStrategy"));
		other1text.sendKeys("other strategies that might be mentioned");
		Thread.sleep(1000);
		
		WebElement goingenrollments=driver.findElement(By.id("rdnHospIndmOnGoingEnrollmentYes"));
		goingenrollments.click();
		Thread.sleep(1000);
		
		WebElement annualrollments=driver.findElement(By.id("rdnHospIndmAnnualEnrollmentYes"));
		annualrollments.click();
		Thread.sleep(1000);
		
		WebElement customer=driver.findElement(By.id("rdnHospIndmEmployeeCustomer"));
		customer.click();
		Thread.sleep(1000);
		
		WebElement tpa=driver.findElement(By.id("rdnHospIndmEmployeeTPA"));
		tpa.click();
		Thread.sleep(1000);
		
		WebElement brokerproducer=driver.findElement(By.id("rdnHospIndmEmployeeBroker"));
		brokerproducer.click();
		Thread.sleep(1000);
		
		WebElement other2=driver.findElement(By.id("rdnHospIndmEmployeeOther"));
		other2.click();
		Thread.sleep(1000);
		
		WebElement other2text=driver.findElement(By.id("txtHospIndmOtherEmployee"));
		other2text.sendKeys("other coverage cancellation requests that can be mentioned");
		Thread.sleep(1000);
		
		WebElement companyname=driver.findElement(By.id("txtHospIndmCompanyName"));
		companyname.sendKeys("COGNIZANT");
		Thread.sleep(1000);
		
		WebElement contactfname=driver.findElement(By.id("txtHospIndmContactFirstName"));
		contactfname.sendKeys("Aniket");
		Thread.sleep(1000);
		
		WebElement contactlname=driver.findElement(By.id("txtHospIndmContactLastName"));
		contactlname.sendKeys("Das");
		Thread.sleep(1000);
		
		WebElement contactphone=driver.findElement(By.id("txtHospIndmContactPhoneNumber"));
		contactphone.sendKeys("03324567890");
		Thread.sleep(1000);
		
		WebElement contactemail=driver.findElement(By.id("txtHospIndmContactEmailAddress"));
		contactemail.sendKeys("ani999@gmail.com");
		Thread.sleep(1000);
		
		WebElement save=driver.findElement(By.id("btnHospIndmSave"));
		save.click();
		Thread.sleep(3000);
		
		WebElement logOut=driver.findElement(By.id("logoutLink"));
		logOut.click();
		Thread.sleep(1000);
		
		WebElement logOutBtn=driver.findElement(By.id("btnlogoutYes"));
		logOutBtn.click();
		Thread.sleep(1000);
		
		driver.quit();
	}

}
