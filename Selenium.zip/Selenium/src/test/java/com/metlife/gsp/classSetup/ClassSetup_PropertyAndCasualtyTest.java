package com.metlife.gsp.classSetup;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_INT;

public class ClassSetup_PropertyAndCasualtyTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();   
        Thread.sleep(1500);
        driver.findElement(By.id("navDashClass")).click();  
        driver.manage().window().maximize();
        Thread.sleep(8000);
        driver.findElement(By.id("btnClsSetupAddClass")).click(); 
        Thread.sleep(1500);
        driver.findElement(By.id("vbTab")).click();  
        Thread.sleep(2000);
        driver.findElement(By.id("PropertyCasualty9")).click();  
        driver.findElement(By.id("chkClsSelect207000_9_0")).click();
        driver.findElement(By.id("txtClsCINumOfEmpForPropertyCasualtyCov_9_0")).sendKeys("45");;
        driver.findElement(By.id("txtClsTempHoursWorkedPC9")).sendKeys("2");
        Select drop1=new Select(driver.findElement(By.id("selectClsTempPayPeriodPC9"))); 
        drop1.selectByIndex(1);
        drop1.selectByIndex(2);
        drop1.selectByIndex(3);
        drop1.selectByIndex(4);
      
        driver.findElement(By.id("rdnArePartTimeEmpCoveredPCNo9")).click();
        driver.findElement(By.id("rdnArePartTimeEmpCoveredPCYes9")).click();
        driver.findElement(By.id("txtClsPCPartTimeHoursWorked9")).sendKeys("2");  
        Select drop2=new Select(driver.findElement(By.id("selectClsPCPartTimePayPeriod9"))); 
        drop2.selectByIndex(1);
        drop2.selectByIndex(2);
        drop2.selectByIndex(3);
        drop2.selectByIndex(4);
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
		Thread.sleep(500); 
        driver.findElement(By.id("chkLeaveOfAbsencePC9")).click();
        driver.findElement(By.id("txtLeaveOfAbsenceDtPC9")).sendKeys("02/26/2019");   
        driver.findElement(By.id("chkInjuryOrSicknessPC9")).click(); 
        driver.findElement(By.id("txtInjuryOrSicknessDtPC9")).sendKeys("02/26/2019");   
        driver.findElement(By.id("chkPartTimeStatusPC9")).click(); 
        driver.findElement(By.id("txtPartTimeStatusDtPC9")).sendKeys("02/26/2019");   
        driver.findElement(By.id("chkLayoffPC9")).click(); 
        driver.findElement(By.id("txtLayoffDtPC9")).sendKeys("02/26/2019");   
        driver.findElement(By.id("chkStrikePC9")).click(); 
        driver.findElement(By.id("txtStrikeDtPC9")).sendKeys("02/26/2019");   
        driver.findElement(By.id("productNextBtn9")).click(); 
}
}