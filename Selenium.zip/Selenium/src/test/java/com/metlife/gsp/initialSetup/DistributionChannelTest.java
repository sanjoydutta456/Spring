package com.metlife.gsp.initialSetup;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class DistributionChannelTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        
        Thread.sleep(2000);
        driver.findElement(By.id("navDashAltDisChn")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("rdnBrokerGATPANo")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("rdnBrokerGATPAYes")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("btnAddTPA")).click();
        Thread.sleep(2000);
        
        Select disChannnel= new Select(driver.findElement(By.id("selectDistributionType5")));
        disChannnel.selectByIndex(2);
        driver.findElement(By.id("txtBrokerProducerFirstName5")).sendKeys("Aditya");
        //driver.findElement(By.className("w337")).click();
        driver.findElement(By.id("txtBrokerStrategicAllianceName5")).sendKeys("Raj");
        driver.findElement(By.id("txtBrokerFederalTaxID5")).sendKeys("123456789");
        driver.findElement(By.id("txtBrokerFirstNameTpaGaProd5")).sendKeys("Anisha");
        driver.findElement(By.id("txtBrokerLastNameTpaGaProd5")).sendKeys("Agarwal");
        driver.findElement(By.id("txtBrokerPhoneNumberTpaGaProd5")).sendKeys("9874563218");
        driver.findElement(By.id("txtBrokerExtnTpaGaProd5")).sendKeys("987456"); 
        driver.findElement(By.id("txtBrokerEmailAddressTpaGaProd5")).sendKeys("adi@gmail.com"); 
        driver.findElement(By.id("btnGATPASave5")).click();
        Thread.sleep(2000);
        driver.manage().window().maximize();
        driver.findElement(By.id("btnAddTPA")).click();
        Thread.sleep(2000);
        
        Select disChannnelGA= new Select(driver.findElement(By.id("selectDistributionType6")));
        disChannnelGA.selectByIndex(1);
        driver.findElement(By.id("txtBrokerProducerFirstName6")).sendKeys("Mohit");
        driver.findElement(By.id("txtBrokerStrategicAllianceName6")).sendKeys("Kumar");
        driver.findElement(By.id("txtBrokerFederalTaxID6")).sendKeys("123456780");
        driver.findElement(By.id("txtBrokerFirstNameTpaGaProd6")).sendKeys("Anisha");
        driver.findElement(By.id("txtBrokerLastNameTpaGaProd6")).sendKeys("Agarwal2");
        driver.findElement(By.id("txtBrokerPhoneNumberTpaGaProd6")).sendKeys("9874563287");
        driver.findElement(By.id("txtBrokerExtnTpaGaProd6")).sendKeys("987456"); 
        driver.findElement(By.id("txtBrokerEmailAddressTpaGaProd6")).sendKeys("mohit@gmail.com"); 
        driver.findElement(By.id("btnGATPASave6")).click();
        Thread.sleep(2000);
       /* driver.findElement(By.id("btnTPADelete1")).click();
        driver.findElement(By.id("rdnMetGATPAYes2")).click();
        driver.findElement(By.id("rdnMetGATPANo2")).click();*/
        
        driver.findElement(By.id("rdnMetGATPAYes5")).click();
        driver.findElement(By.id("rdnMetGATPANo5")).click();
        
        driver.findElement(By.id("rdLifeYes49")).click();
        driver.findElement(By.id("rdLifeNo49")).click(); 
        driver.findElement(By.id("rddentalYes9999")).click();  
        driver.findElement(By.id("rddentalNo9999")).click(); 
        driver.findElement(By.id("rddisabilityYes61")).click(); 
        driver.findElement(By.id("rddisabilityNo61")).click(); 
        
        driver.findElement(By.id("btnBrokerSave")).click(); 
        driver.findElement(By.id("btnBrokerAltDistChnProceed")).click(); 
    }

}
