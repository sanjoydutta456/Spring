package com.metlife.gsp.defects;

import static org.junit.Assert.fail;

import java.util.List;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UC_005 {

	
	@Test
	public void authorize() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://int.custadmin.metlife.com");
		Thread.sleep(1000);
		WebElement username = driver.findElement(By.id("USER"));
        WebElement password = driver.findElement(By.id("PASSWORD"));
        WebElement signIn = driver.findElement(By.id("cmdEnter"));
        username.sendKeys("chandrika_cust");
        Thread.sleep(1000);
        password.sendKeys("metlife1");
        Thread.sleep(1000);
        signIn.click();
        List<WebElement> editButtons = driver.findElements(By.id("editCustomer")); // we need the 4th edit button
        editButtons.get(3).click();                                               //Opportunity id: FEA 2.2 Final
        ((JavascriptExecutor)driver).executeScript("scroll(0,600)");
        Thread.sleep(2000);
        WebElement dashHyatt = driver.findElement(By.id("navDashHyatt"));
        dashHyatt.click();
        Thread.sleep(2000);
        WebElement yesReplacementCoverageRadio = driver.findElement(By.id("rdnHyattReplacementCoverageYes"));
        yesReplacementCoverageRadio.click();
        Thread.sleep(2000);
        WebElement yesNewEnrollment = driver.findElement(By.id("rdnHyattEnrollmentDesiredYes"));
        yesNewEnrollment.click();
        Thread.sleep(2000);
        WebElement search = driver.findElement(By.id("btnHyattSave"));
        search.click();
        Thread.sleep(2000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
        Thread.sleep(4000);
        WebElement completeAndSubmitNav = driver.findElement(By.id("leftNavAuthESign"));
        completeAndSubmitNav.click();
        Thread.sleep(2000);
        WebElement yesButton = driver.findElement(By.id("btnleftNavigationYes"));
        yesButton.click();
        Thread.sleep(4000);
        WebElement validateApplication = driver.findElement(By.id("btnValidateESign"));
        validateApplication.click();
        Thread.sleep(4000);
        List<WebElement> hyattErrorLink = driver.findElements(By.linkText("Product Legal Services (MetLaw)"));
        if(hyattErrorLink.size()!=0)
        {
        	System.err.println("\"Product Legal Services (MetLaw)\" link is coming under the list of error pages.");
        	fail("\"Product Legal Services (MetLaw)\" link is coming under the list of error pages.");
        }
        else
        {
        	System.out.println("\"Product Legal Services (MetLaw)\" link is not coming under the list of error pages.");
        }
        Thread.sleep(2500);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1500);
        WebElement yesButtonForLogout = driver.findElement(By.id("btnlogoutYes"));
        yesButtonForLogout.click();
        Thread.sleep(1000);
        driver.quit();
        
	}
	
}
