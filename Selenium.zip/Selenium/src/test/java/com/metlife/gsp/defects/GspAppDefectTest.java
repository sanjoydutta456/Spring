package com.metlife.gsp.defects;

import javax.naming.TimeLimitExceededException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.openqa.selenium.WebDriver;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.admin.manageOpportunity.ManageCommisionTest;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.LoginTest;

public class GspAppDefectTest {
	
	private WebDriver driver;
    private Login_DEV login;
	
/*    @Before
    public void setUp() {
    	login = new Login();
    	driver=login.setUp();
    }*/

    @RunWith(Suite.class)
    @Suite.SuiteClasses({
    	//UC_001_CustomerInformationTestCases.class,
    	UC_001_BrokerProducerInformationTestCases.class,
    	UC_001_ManageGATPATestCases.class,
    	//UC_001_ProductSoldTestCases.class,
    	UC_002_38676.class,
    	UC_002_38946_LifeTest.class,
    	UC_002_38946_DisabilityTest.class,
    	UC_002_39192.class,
    	UC_003.class,			
    	UC_004_38577.class,//test case 1
    	UC_004_38575.class,//test case 2
    	UC_004_EBS_873.class,
    	UC_004_EBS_874.class,
    	UC_004_EBS_877.class,
    	UC_004_EBS_900.class,//test case 4
    	UC_005.class,
    	UC_006.class,
    	UC_012.class
    })
    public class GSPDefectTestSuite {
    	//normally, this is an empty class
    }
}
