package com.metlife.gsp.defects;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.metlife.gsp.login.Login_DEV;

public class UC_006 {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
          }
    @Test
    public void succeeded() throws NoSuchElementException, ElementNotInteractableException, ElementNotVisibleException, InterruptedException, NoSuchMethodError {
    	
        WebElement oppID = driver.findElement(By.id("RFPID"));
        //oppID.sendKeys("0062a000005W9HDSS1");\
        oppID.sendKeys("0061100000DVvsdAAD");
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        Thread.sleep(2000);
        
        //admin 
	        WebElement admin = driver.findElement(By.id("leftNavAdminInfo"));
	        admin.click();  
	        Thread.sleep(2000);   
            WebElement ManageMetLifeContacts = driver.findElement(By.id("breadManageContacts"));
            ManageMetLifeContacts.click();
            Thread.sleep(2000); 
            WebElement save = driver.findElement(By.id("btnSecMgnmtHeaderYes"));
            save.click();
            System.out.println("1");
            Thread.sleep(2000);      
            if(driver.findElement(By.xpath("//*[@id=\"appDataMap'SSA.SalesOffice'\"]")).getAttribute("value").contentEquals("SAn")){ 
	        System.out.println("Test Case Passed");	      	      
	        }              
         else {
       	   System.out.println("Test Case Failed");
          }
   	   
            //Logout
            WebElement logOut = driver.findElement(By.id("logoutLink"));
            logOut.click();
            Thread.sleep(2000);
            WebElement yesButton = driver.findElement(By.id("btnlogoutViewYes"));
            yesButton.click();
            Thread.sleep(1000);
            driver.quit();  	   
        
    }
}
