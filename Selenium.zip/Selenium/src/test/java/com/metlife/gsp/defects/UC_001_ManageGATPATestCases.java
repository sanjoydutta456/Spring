package com.metlife.gsp.defects;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class UC_001_ManageGATPATestCases {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    
    public void searchOpportunity() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"editCustomer\"]"))).click();
		
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
    	driver.findElement(By.id("RFPID")).sendKeys("1-1F5MS1"); 
        searchOpportunity();
    	Thread.sleep(1000);
    	driver.manage().window().maximize();
    	// Defect - 38117 (Test Case 1) --> Check if the Instructional text displayed is correct
    	driver.findElement(By.id("leftNavInitialSetupInfo")).click();
    	Thread.sleep(2000);
    
    	Assert.assertTrue("Distribution channel does not exist", driver.findElement(By.id("distChannelTab")).isDisplayed());
    	Thread.sleep(1000);
    	driver.findElement(By.id("distChannelTab")).click();
    	Assert.assertTrue("Navigation popup does not exist", driver.findElement(By.id("customerHeaderOverlay")).isDisplayed());
    	driver.findElement(By.id("btnCustomerHeaderNo")).click();
    	Thread.sleep(2000);
    	Assert.assertTrue("Instructional text does not exist.Test Case failed", driver.findElement(By.xpath("//*[@id=\"resultSub\"]/div[1]/span")).isDisplayed());
    	if(driver.findElement(By.xpath("//*[@id=\"resultSub\"]/div[1]/span")).getText().contentEquals("Third Party Administrators/General Agents that have been added are outlined below. You can view, edit, or delete by clicking on the appropriate link next to the company name."))
    		System.out.println("Test Case 1 passed");
    	else
    		System.out.println("Test Case 1 failed");
    	
    	driver.findElement(By.id("logoutLink")).click();
    	Thread.sleep(1000);
    	Assert.assertTrue(driver.findElement(By.id("viewLogoutOverlay")).isDisplayed());
    	driver.findElement(By.id("btnlogoutViewYes")).click();
    	driver.quit();
    }
}
