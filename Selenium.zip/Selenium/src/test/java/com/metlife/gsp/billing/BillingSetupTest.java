package com.metlife.gsp.billing;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.metlife.gsp.login.Login_INT;

public class BillingSetupTest {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void billingSetupPageTest() throws InterruptedException {
    	
    	driver.findElement(By.id("RFPID")).sendKeys("1-1F5MM2");
        Thread.sleep(1000);
        driver.findElement(By.id("SearchButtonIntUser")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("editCustomer")).click();
        driver.findElement(By.id("leftNavBilling")).click();
        Thread.sleep(2000);
        
    	Select drpBillType = new Select(driver.findElement(By.id("selectBillTypePerProd")));
    	drpBillType.selectByIndex(2);
    	Thread.sleep(1000);
    	
    	Select drpPayFreq = new Select(driver.findElement(By.id("selectPremPaymentFreq")));
    	drpPayFreq.selectByIndex(1);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(2);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(3);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(4);
    	Thread.sleep(1000);
    	WebElement OtherText = driver.findElement(By.id("txtOtherText"));
    	OtherText.clear();
    	OtherText.sendKeys("Decade");
    	Thread.sleep(2000);
    	driver.findElement(By.id("rdnCustPrimaryBillingDepartBillingYes")).click();
    	Thread.sleep(500);
    	driver.findElement(By.id("rdnCustPrimaryBillingDepartBillingNo")).click();
    	Thread.sleep(500);
    	driver.findElement(By.id("rdnCustPrimaryBillingDepartBillingYes")).click();
    	Thread.sleep(1000);
    	driver.findElement(By.id("btnCustPrimaryBillingDepartAdd")).click();
    	Thread.sleep(2000);
    	WebElement PrimaryBillingDepartName = driver.findElement(By.id("txtCustPrimaryBillingDepartName10"));
    	PrimaryBillingDepartName.clear();
    	PrimaryBillingDepartName.sendKeys("Metlife");
	    Thread.sleep(1000);
	    WebElement PrimaryBillingDepartCode = driver.findElement(By.id("txtCustPrimaryBillingDepartCode10"));
	    PrimaryBillingDepartCode.clear();
	    PrimaryBillingDepartCode.sendKeys("MetlifeInc");
	    Thread.sleep(1000);
        driver.findElement(By.id("btnCustPrimaryBillingDepartAdd")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("btnCustPrimaryBillingDepartRemove10")).click();             	    	
    	Thread.sleep(1000);
    	driver.findElement(By.id("btnDeleteWarningYes")).click();
    	Thread.sleep(2000);
    	WebElement MetBillGeneratedDate = driver.findElement(By.id("txtMetBillGeneratedDate"));
    	MetBillGeneratedDate.clear();
    	MetBillGeneratedDate.sendKeys("10");
    	Thread.sleep(1000);
    	Select drpDataDisp = new Select(driver.findElement(By.id("selectDataBillDisplay")));
    	drpDataDisp.selectByIndex(1);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(2);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(3);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(4);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(5);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(6);
    	Thread.sleep(500);
    	drpDataDisp.selectByIndex(7);
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnCustBillingInfoSave")).click();
    	drpBillType.selectByIndex(1);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(1);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(2);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(3);
    	Thread.sleep(500);
    	drpPayFreq.selectByIndex(4);
    	Thread.sleep(2000);
    	drpBillType.selectByIndex(3);
    	Thread.sleep(500);
    	drpBillType.selectByIndex(4);
    	Thread.sleep(1000);
    	WebElement BreakoutNo = driver.findElement(By.id("rdnBillingBreakoutNo"));
    	BreakoutNo.click();
    	Thread.sleep(1000);
    	driver.findElement(By.id("rdnBillingBreakoutYes")).click();
    	Thread.sleep(1000);
    	WebElement Breakouttxt = driver.findElement(By.id("txtNoOfBreakouts"));
    	Breakouttxt.clear();
    	Breakouttxt.sendKeys("15");
    	Thread.sleep(1000);
    	drpPayFreq.selectByIndex(2);
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnCustBillingInfoSave")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnCustBillingInfoProceed")).click();
    	
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
    	
    }
}
