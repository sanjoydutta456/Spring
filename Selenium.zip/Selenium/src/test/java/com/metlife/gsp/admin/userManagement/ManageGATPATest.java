package com.metlife.gsp.admin.userManagement;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_INT;

public class ManageGATPATest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	WebDriverWait wait = new WebDriverWait(driver,40);
        
        /*driver.findElement(By.id("RFPID")).sendKeys("0062a000005PJ10AAG"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.findElement(By.id("breadoppUserList")).click(); 
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      //Test case 1 when no GA/TPA
        if("Currently there are no GA/TPA for this opportunity.".contentEquals("Currently there are no GA/TPA for this opportunity.")) {
        	 driver.findElement(By.id("btnReturnToDashMangGATPA")).click();
        	 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        System.out.println("Test case 1 Passed");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        */
        //Test 2 when only 1 GA/TPA
        /*driver.findElement(By.id("leftNavsearchCustomer")).click();
        driver.findElement(By.id("RFPID")).clear();*/
        driver.findElement(By.id("RFPID")).sendKeys("6-4A7ONV");
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        /*driver.findElement(By.id("editCustomer")).click();*/
        Thread.sleep(2000);
        driver.findElement(By.className("P10")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        driver.manage().window().maximize();
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.id("breadoppUserList")).click(); 
        Thread.sleep(2000);
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        Thread.sleep(2000);
        try {
        	 if(driver.findElement(By.id("rndGATPAApproval1")).isDisplayed()) {
        		 driver.findElement(By.id("btnReturnToDashMangGATPA")).click();
        		 
             }
    
        }
       catch(Exception ex){/*
    	   Assert.assertTrue(driver.findElement(By.id("logoutLink")).isDisplayed());
       		driver.findElement(By.id("logoutLink")).click();
       		Assert.assertTrue(driver.findElement(By.id("viewLogoutOverlay")).isDisplayed());
           driver.findElement(By.id("btnlogoutViewYes")).click();
    	   System.out.println("Test case 2 Passed");
       */
    	   driver.findElement(By.id("btnReturnToDashMangGATPA")).click();
    	   System.out.println("Test case 1 Passed");
           Thread.sleep(2000);
       		driver.findElement(By.id("logoutLink")).click();
           driver.findElement(By.id("btnlogoutYes")).click();
           driver.close();
       }
        
        
        //test case 2 no ga tpa
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        System.out.println("passed");
        /*driver.quit();*/
        Thread.sleep(2000);
        driver.findElement(By.id("leftNavsearchCustomer")).isDisplayed();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"leftNavsearchCustomer\"]")).click();
       
        
    } 

}
