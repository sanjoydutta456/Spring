package com.metlife.gsp.classSetup;


import static org.junit.Assert.assertTrue;

 

import java.util.concurrent.TimeUnit;

 

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.ElementNotInteractableException;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

 

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class ClassSetup_DisabilityTest {

 

                private WebDriver driver;

                private Login_INT login;

                private boolean iterationFlag;

 

                @Before

                public void setUp() {

                                login = new Login_INT();

                                driver = login.setUp();

                }

                 /*               private void returnToHome(){

                               

                                WebElement homeEle = driver.findElement(By.className("summary"));

                                homeEle.click();

                                driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                                driver.findElement(By.id("btnleftNavigationYes")).click();

                }

                private void returnToHomeforBroker(){

                                WebElement homeEle = driver.findElement(By.className("summary"));

                                if(!iterationFlag){

                                                driver.manage().window().maximize();

                                                iterationFlag = true;

                                                JavascriptExecutor js = (JavascriptExecutor)driver;

                                                js.executeScript("scroll(250,0)");

                                }

                                homeEle.click();

                                driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                                driver.findElement(By.id("btnleftNavigationYes")).click();

                }
*/
                @Test

                public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

                               

                                JavascriptExecutor js = (JavascriptExecutor) driver;

                               

                               

                                WebElement oppID = driver.findElement(By.id("RFPID"));

                                oppID.sendKeys("1-4BIM0T");

                                driver.findElement(By.id("SearchButtonIntUser")).click();

                                driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

                                driver.findElement(By.id("editCustomer")).click();


                            	

                           	 driver.findElement(By.id("navDashClass")).click();
                           	 Thread.sleep(500);
                           	 
                           	driver.manage().window().maximize();
                           	 
                           	 
                           	/* 
                           	 driver.findElement(By.xpath("//*[@id=\"btnClsSetupAddClass\"]")).click();
                           	 Thread.sleep(4000);
                           		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                           */
                           	 /*
                           		driver.findElement(By.id("btnClsSetupAddClass")).click();
                           	    Thread.sleep(5000);
                           	 */
                           	
                           	Thread.sleep(8000);

                           	 WebElement addClassbbtn = driver.findElement(By.id("btnClsSetupAddClass"));
                           		if(addClassbbtn.isDisplayed())
                           		{
                           			 addClassbbtn.click();
                           			
                           			// Thread.sleep(10000);
                           			//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                           			 System.out.println(1);
                           		}
                           		
                           	 System.out.println(2);
                           	Thread.sleep(1000);
                           	 
                           	 
                           		 driver.findElement(By.id("divClassSetupProdTab")).click();
                           		 Thread.sleep(1000);
                           		
                           		
/*
                           		 driver.findElement(By.id("chkClsSelect61_5_0")).click();
                           		 
                           		 
                           		 Thread.sleep(500);*/
                           		
                           		 /*
                           		 driver.findElement(By.id("")).click();
                           		 Thread.sleep(500);
                           	 
                           	 */
                           		
                           		Select status = new Select(driver.findElement(By.id("selectClsDesc5")));
                        		status.selectByIndex(19);
                             	Thread.sleep(1000);

                        		
                           	  driver.findElement(By.id("txtClsTempClassDescription5")).sendKeys("cat");
                           	  Thread.sleep(1000);
                        		
                           	driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes5")).click();
                      		 Thread.sleep(500);

                      		driver.findElement(By.id("rdnClsTempOpenClass5")).click();
                     		 Thread.sleep(500);
                     		driver.findElement(By.id("rdnClsTempClosedClass5")).click();
                    		 Thread.sleep(500);
                    		 
                    		 
                    		 driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass5")).sendKeys("dog");
                          	  Thread.sleep(1000);
                    		 
                          	 driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass5")).sendKeys("pup");
                         	  Thread.sleep(4000);
                         	  
                         	  
                         	 
                         	 
                          	 driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo5")).click();
                         	  Thread.sleep(4000);
                         	  
                         	  
                         	 
                      		 
                      		 
                      		driver.findElement(By.id("Disability5")).click();
                     		 Thread.sleep(4000);
                         	 System.out.println(7);
                         	
                         	
                         	driver.findElement(By.id("chkClsSelect61_5_0")).click();
                   		 Thread.sleep(500);
                         	 driver.findElement(By.id("txtClsDisabilityNoOfEmployeesLTD_5_0")).sendKeys("6");
                       	  Thread.sleep(4000);

                      	 driver.findElement(By.id("txtClsDisabilityEmpContLTD_5_0")).sendKeys("8");
                    	  Thread.sleep(4000);
                    	  
                         	
                         	
                         	
                         	
                         	 
                    			Select stat = new Select(driver.findElement(By.id("selectClsDisabilityEarningsDefinition5")));
                        		stat.selectByIndex(6);
                             	Thread.sleep(1000);
                             	 driver.findElement(By.id("txtDisabClsOtherEarningsDescription5")).sendKeys("meow");
                            	  Thread.sleep(1000);
                      		 
                            	Select statu = new Select(driver.findElement(By.id("selectClsDisabilityAveragedOver5")));
                        		statu.selectByIndex(4);
                             	Thread.sleep(1000);
                             	
                             	 driver.findElement(By.id("txtDisabClsOtherAveragedOver5")).sendKeys("bow");
                            	  Thread.sleep(1000);
                      		 
                             	
                             	
                             	 
                              	driver.findElement(By.id("rdnClassDisEligibilityWaitingPeriodExistYes5")).click();
                          		 Thread.sleep(1000);

                             	 
                              	driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo5")).click();
                          		 Thread.sleep(5000);
                          	
                         	
                               	driver.findElement(By.id("rdnClassDisEligibilityWaitingPeriodExistNo5")).click();
                           		 Thread.sleep(1000);
                           	
                             	

                     			Select st = new Select(driver.findElement(By.id("selectDisablityWaitingPeriodEffective5")));
                         		st.selectByIndex(9);
                              	Thread.sleep(1000);
                              	driver.findElement(By.id("otherDisabEffDateBtn5")).click();
                          	  Thread.sleep(1000);
                          	  driver.findElement(By.xpath("/html/body/div[8]/div/div[3]/ul[5]/li[5]/div")).click();
                           	  Thread.sleep(1000);
                           	 
                             	
                              
                              		Select benefitsEffective = new Select(driver.findElement(By.id("selectDisablityWaitingPeriodEffective5")));
                              				benefitsEffective.selectByIndex(9);
                              				Thread.sleep(100);
                              				driver.findElement(By.id("otherDisabEffDate5")).click();  
                              				Thread.sleep(1000);
                              				driver.findElement(By.xpath("//*[@id=\"otherDisabEffDateBtn5\"]")).click(); 
                              		 
                              				Thread.sleep(1000);
                             	
                              				
                             	
                             	
                              				Select s = new Select(driver.findElement(By.id("selectDisabilityNewHireWaitingPeriod5")));
                                     		s.selectByIndex(8);
                                          	Thread.sleep(1000);
                             	
                                       	 driver.findElement(By.id("txtDisabilityNewHireWaitingPeriodValue5")).sendKeys("haha");
                                   	  Thread.sleep(1000);
                             	
                             	

                        				Select ss = new Select(driver.findElement(By.id("selectDisabilityWaitingPeriodWaive5")));
                               		ss.selectByIndex(1);
                                    	Thread.sleep(1000);
                             	
                             	
                                    	Select sk = new Select(driver.findElement(By.id("selectDisabilityClassEmploymentEnds5")));
                                   		sk.selectByIndex(3);
                                        	Thread.sleep(1000);
                                         	 driver.findElement(By.id("txtdivDisabilityEmploymentEndsOther5")).sendKeys("hah");
                                          	  Thread.sleep(1000);
                             	
                             	
                                        	Select sl = new Select(driver.findElement(By.id("selectDisabilityClassEligibleClassDate5")));
                                       		sl.selectByIndex(3);
                                            	Thread.sleep(1000);
                             	
                                             	 driver.findElement(By.id("txtdivDisabilityEligibleClassDateOther5")).sendKeys("ha");
                                              	  Thread.sleep(1000);
                                              	  
                                            	Select sj = new Select(driver.findElement(By.id("selectDisabilityRetirement5")));
                                           		sj.selectByIndex(3);
                                                	Thread.sleep(1000);
                                                 	 driver.findElement(By.id("txtdivDisabilityRetirementOther5")).sendKeys("hi");
                                                  	  Thread.sleep(1000);
                             	
                             	
                             	
                             	
                                                	Select sn = new Select(driver.findElement(By.id("selectDisabilityDependentLimitingAge5")));
                                               		sn.selectByIndex(3);
                                                    	Thread.sleep(1000);
                                                     	 driver.findElement(By.id("txtdivDisabilityDependentLimitingAgeOther5")).sendKeys("hello");
                                                      	  Thread.sleep(1000);
                             	
                                                    	Select sm = new Select(driver.findElement(By.id("selectDisabilityDependentNotMetDefinition5")));
                                                   		sm.selectByIndex(3);
                                                        	Thread.sleep(1000);
                             	
                                                         	 driver.findElement(By.id("txtdivDisabilityDependentNotMetDefinitionOther5")).sendKeys("bye");
                                                          	  Thread.sleep(10000);
                                                          	  
                                                          	  
                             	
                                                        	driver.findElement(By.id("chkDisApplyChangesToAll5")).click();
                                              				Thread.sleep(8000);
                                              				System.out.println(99);
                                              				 driver.findElement(By.id("txtClsTempHoursWorkedDisability5")).sendKeys("7");
                                                         	  Thread.sleep(8000);   
                                                         	  System.out.println(998);
                                                         	 driver.findElement(By.id("txtClsTempAddComments5")).sendKeys("month");
                                                         	  Thread.sleep(1000);
                                                         	  
                                              				
                                              				
                                              				
                                              				
                                              				
}
}
               

