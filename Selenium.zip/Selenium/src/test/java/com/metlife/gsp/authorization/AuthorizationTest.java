package com.metlife.gsp.authorization;

import org.junit.Before;
import org.openqa.selenium.WebDriver;

import com.metlife.gsp.login.Login_DEV;

public class AuthorizationTest {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

    

}
