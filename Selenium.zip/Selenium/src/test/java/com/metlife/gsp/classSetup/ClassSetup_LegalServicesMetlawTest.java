package com.metlife.gsp.classSetup;


import static org.junit.Assert.assertTrue;

 

import java.util.concurrent.TimeUnit;

 

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.ElementNotInteractableException;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

 

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class ClassSetup_LegalServicesMetlawTest {

 

                private WebDriver driver;

                private Login_INT login;

                private boolean iterationFlag;

 

                @Before

                public void setUp() {

                                login = new Login_INT();

                                driver = login.setUp();

                }

                @Test

                public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

                               

                                JavascriptExecutor js = (JavascriptExecutor) driver;

                               

                               

                                WebElement oppID = driver.findElement(By.id("RFPID"));

                                oppID.sendKeys("0062a000005PNpOAAW");

                                driver.findElement(By.id("SearchButtonIntUser")).click();

                                driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

                                driver.findElement(By.id("editCustomer")).click();


                            	

                           	 driver.findElement(By.id("navDashClass")).click();
                           	 Thread.sleep(500);
                           	 
                           	driver.manage().window().maximize();
                           	 
                           	 
                         
                           	
                           	Thread.sleep(8000);

                           	 WebElement addClassbbtn = driver.findElement(By.id("btnClsSetupAddClass"));
                           		if(addClassbbtn.isDisplayed())
                           		{
                           			 addClassbbtn.click();
                           			
                           			 System.out.println(1);
                           		}
                           		
                           	 System.out.println(2);
                           	Thread.sleep(4000);
                           	 
                           	 
                           		 driver.findElement(By.id("divClassSetupProdTab")).click();
                           		 Thread.sleep(4000);
                           		 
                           		 driver.findElement(By.id("vbTab")).click();
                           		 Thread.sleep(4000);
                           		 
                           		
                           		 
                           		Select stat = new Select(driver.findElement(By.id("selectClsDesc4")));
                         		stat.selectByIndex(19);
                              	Thread.sleep(1000);
                           		 
                              	
                              	
                           		 

                          		 driver.findElement(By.id("txtClsTempClassDescription4")).sendKeys("hi");
                          		 Thread.sleep(4000);
                          		 
                          		 driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes4")).click();
                          		 Thread.sleep(4000);
                          		 

                          		 driver.findElement(By.id("rdnClsTempOpenClass4")).click();
                          		 Thread.sleep(4000);
                          		
                          		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass4")).sendKeys("ghgf");
                         		 Thread.sleep(500);
                          		 driver.findElement(By.id("rdnClsTempClosedClass4")).click();
                          		 Thread.sleep(5000);
                          		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass4")).sendKeys("ggf");
                        		 Thread.sleep(500);
                          		 driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo4")).click();
                          		 Thread.sleep(1000);
                          		 
                          		
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                          		 driver.findElement(By.id("Hyatt4")).click();
                          		 Thread.sleep(1000); 
                          		                		 
                          		 driver.findElement(By.id("chkClsSelect206000_4_0")).click();
                          		 Thread.sleep(1000); 
                          		                	
                          		
                           		 
                          		 
                        		   driver.findElement(By.id("txtClsHyattNumOfEmpForHyattCov_4_0")).sendKeys("12");
                                Thread.sleep(1000); 
                           	 
                        		   driver.findElement(By.id("txtClassHyattBasicHyattEmployerCov_4_0")).sendKeys("2");
                                Thread.sleep(1000); 
                           	 
                        		   driver.findElement(By.id("txtClassHyattPartialContribution_4_0")).sendKeys("11");
                                Thread.sleep(1000); 
                          		
                          		
                          		
                          		
                          		
                          		
                          		 driver.findElement(By.id("rdnClassExpatriatesImpatriatesHyattYes4")).click();
                         		 Thread.sleep(1000); 
                         		 
                         		 driver.findElement(By.id("rdnClassExpatriatesImpatriatesHyattNo4")).click();
                          		 Thread.sleep(1000); 
                          		 
                          		
                           		 
                           		 
                          		 
                        		 driver.findElement(By.id("rdnArePartTimeEmpCoveredHyattYes4")).click();
                         		 Thread.sleep(1000); 
                         		
                         		
                         	   driver.findElement(By.id("txtClsHyattPartTimeHoursWorked4")).sendKeys("11");
                                Thread.sleep(1000);
                                Select status = new Select(driver.findElement(By.id("selectClsHyattPartTimePayPeriod4")));
                        		status.selectByIndex(3);
                             	Thread.sleep(1000);
                                
                                
                         		 driver.findElement(By.id("rdnArePartTimeEmpCoveredHyattNo4")).click();
                          		 Thread.sleep(1000); 
                           		 
                           		 
                           
                           		 
                           		 
                               //need for calenders
                           		 
                               
                               driver.findElement(By.id("chkLeaveOfAbsenceHyatt4")).click();
                        		 Thread.sleep(1000);
                        		 
                               driver.findElement(By.id("btnLeaveOfAbsenceHyatt4")).click();
                        		 Thread.sleep(4000);
                        		 
                        		 driver.findElement(By.xpath("/html/body/div[142]/div/div[3]/ul[5]/li[5]/div")).click();  
                          		 Thread.sleep(4000);
                          		 
                          		 
                           		 
                          		 
                                 driver.findElement(By.id("chkInjuryOrSicknessHyatt4")).click();
                          		 Thread.sleep(1000);
                          		 
                                 driver.findElement(By.id("btnInjuryOrSicknessHyatt4")).click();
                          		 Thread.sleep(4000);
                          		 
                          		 driver.findElement(By.xpath("/html/body/div[143]/div/div[3]/ul[5]/li[5]/div")).click();
                            		 Thread.sleep(4000);
                            		 
                           		 
                           		 
                            		 
                              		 
                                     driver.findElement(By.id("chkPartTimeStatusHyatt4")).click();
                              		 Thread.sleep(1000);
                              		 
                                     driver.findElement(By.id("btnPartTimeStatusHyatt4")).click();
                              		 Thread.sleep(4000);
                              		 
                              		 driver.findElement(By.xpath("/html/body/div[144]/div/div[3]/ul[5]/li[5]/div")).click();
                                      Thread.sleep(8000);
                                		 
                           		 
                           		 
                                      
                                     driver.findElement(By.xpath("//*[@id=\"chkLayoffHyatt4\"]")).click();
                               		 Thread.sleep(4000);
                               		 System.out.println(3);
                                     driver.findElement(By.xpath("//*[@id=\"btnLayoffHyatt4\"]")).click();
                               		 Thread.sleep(4000);
                               		 System.out.println(4);
                               		 driver.findElement(By.xpath("/html/body/div[145]/div/div[3]/ul[5]/li[5]/div")).click();
                                     Thread.sleep(4000);
                                 		 
                                     
                                     
                                     
                                     
                                     
                                     driver.findElement(By.id("chkStrikeHyatt4")).click();
                               		 Thread.sleep(4000);
                               		 System.out.println(6);
                                     driver.findElement(By.id("btnStrikeHyatt4")).click();
                               		 Thread.sleep(4000);
                               		 
                               		 driver.findElement(By.xpath("/html/body/div[146]/div/div[3]/ul[5]/li[5]/div")).click();
                                     Thread.sleep(4000);
                            		 
                                 
                            		 
                           		 
                           		 
                           		 
                               		 
                                  		Select st = new Select(driver.findElement(By.id("selectClsEmployeeLiveNyOr4")));
                                		st.selectByIndex(2);
                                     	Thread.sleep(1000);

                                     	 driver.findElement(By.id("txtClsTempAddComments4")).sendKeys("hi");
                                         Thread.sleep(1000); 
                                   		 
                                     	 
                               		  
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                           		 
                }
}
                           		