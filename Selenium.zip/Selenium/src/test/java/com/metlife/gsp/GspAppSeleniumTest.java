package com.metlife.gsp;

import javax.naming.TimeLimitExceededException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.openqa.selenium.WebDriver;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.admin.manageOpportunity.CustomerAgreementSettingsTest;
import com.metlife.gsp.admin.manageOpportunity.ManageCommisionTest;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.LoginTest;
import com.metlife.gsp.search.SearchTest;

public class GspAppSeleniumTest {
	
	private WebDriver driver;
    private Login_DEV login;
	
/*    @Before
    public void setUp() {
    	login = new Login();
    	driver=login.setUp();
    }*/

    @RunWith(Suite.class)
    @Suite.SuiteClasses({
    	CustomerAgreementSettingsTest.class, //test case 1
    	ManageCommisionTest.class  //test case 2
              
    })
    public class GSPTestSuite {
    	//normally, this is an empty class
    }
}
