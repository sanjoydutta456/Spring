package com.metlife.gsp;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.poi.sl.usermodel.Shape;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.sl.usermodel.TextParagraph;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;


public class CustomExecutionListener extends RunListener {
	
	public void testRunStarted(Description description) throws Exception {
        System.out.println("Number of tests to execute: " + description.testCount());
    }

    public void testRunFinished(Result result) throws Exception {
        System.out.println("Number of tests executed: " + result.getRunCount());
    }

    public void testStarted(Description description) throws Exception {
        System.out.println("Starting: " + description.getMethodName());
        
    }

    public void testFinished(Description description) throws Exception {
        System.out.println("Finished: " + description.getMethodName());
    }

    public void testFailure(Failure failure) throws Exception {
        System.out.println("Failed: " + failure.getDescription().getMethodName());
//        String failedMethodName = failure.getDescription().getMethodName();
        String failedClassName = failure.getDescription().getClassName();
//       if(failedMethodName.equals("loginPage"))
//         {
//    	   GspAppTestRunner.loginSuccessFlag = false;
//         }
//        else if(failedMethodName.equals("succeeded"))
//         {
//        	GspAppTestRunner.searchSuccessFlag = false;
//         }   
       if(failedClassName.equals("LoginTest"))
       {
  	   GspAppTestRunner.loginSuccessFlag = false;
       }
      else if(failedClassName.equals("SearchTest"))
       {
      	GspAppTestRunner.searchSuccessFlag = false;
       } 
    }

    public void testAssumptionFailure(Failure failure) {
        System.out.println("Failed: " + failure.getDescription().getMethodName());
    }

    public void testIgnored(Description description) throws Exception {
        System.out.println("Ignored: " + description.getMethodName());
    }
    
}
