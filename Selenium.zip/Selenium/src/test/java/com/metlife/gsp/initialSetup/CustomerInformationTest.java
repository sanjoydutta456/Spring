package com.metlife.gsp.initialSetup;

import java.util.NoSuchElementException;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class CustomerInformationTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	WebDriverWait myWaitVar = new WebDriverWait(driver,20);
        driver.findElement(By.id("RFPID")).sendKeys("0061100000Dh0pvAAB"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.className("P10")).click();
        driver.manage().window().maximize();
        if(driver.findElement(By.id("navDashCustInfoBroker")).isDisplayed()) {
        	driver.findElement(By.id("navDashCustInfoBroker")).click();
        }
        
        //Customer Information
        driver.findElement(By.id("txtCustCustomerNumber")).clear();
        driver.findElement(By.id("txtCustCustomerNumber")).sendKeys("168650");
        
        driver.findElement(By.id("txtCustCustomerLegalName")).clear();
        driver.findElement(By.id("txtCustCustomerLegalName")).sendKeys("test account 1");
        
        driver.findElement(By.id("txtCustCustomerName")).clear();
        driver.findElement(By.id("txtCustCustomerName")).sendKeys("test account 1");
        
        driver.findElement(By.id("txtCustProspectNumber")).clear();
        driver.findElement(By.id("txtCustProspectNumber")).sendKeys("P1010133");
        
        driver.findElement(By.id("selectBusinessType")).click();
        Select type =new Select(driver.findElement(By.id("selectBusinessType")));
        type.selectByVisibleText("Addition");
        
        driver.findElement(By.id("rdnCustSpecialtyMarketsYes")).click();
        
        driver.findElement(By.id("rdnCustAffinityMemberBenYes")).click();
        
        driver.findElement(By.id("txtCustFederalTaxIDCustDet")).sendKeys("12345");
        driver.findElement(By.id("selectCustCustOrgType")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerFederalTaxID")).isDisplayed());
        driver.findElement(By.id("txtCustFederalTaxIDCustDet")).clear();
        driver.findElement(By.id("txtCustFederalTaxIDCustDet")).sendKeys("123456789");
        
        driver.findElement(By.id("selectCustCustOrgType")).click();
        Select orgType =new Select(driver.findElement(By.id("selectCustCustOrgType")));
        orgType.selectByVisibleText("Government Group");
        
        driver.findElement(By.id("selectCustSitusState")).click();
        Select situsState =new Select(driver.findElement(By.id("selectCustSitusState")));
        situsState.selectByVisibleText("KY");
        
        if(driver.findElement(By.id("txtCustSICDescription")).isEnabled()) {
        	driver.findElement(By.id("txtCustSICDescription")).sendKeys("testing");
        }
        
        driver.findElement(By.id("selectEnrollDatesConsistency")).click();
        Select dateEnroll =new Select(driver.findElement(By.id("selectEnrollDatesConsistency")));
        dateEnroll.selectByVisibleText("Applies to all MetLife products");
        
        driver.findElement(By.id("enrollmentStartDt")).click();
        driver.findElement(By.id("enrollmentStartDt")).sendKeys("01/16/2019");
        
        driver.findElement(By.id("enrollmentEndDt")).click();
        driver.findElement(By.id("enrollmentEndDt")).sendKeys("01/16/2020");
        
        driver.findElement(By.id("rdnCustEnrollmentCreditYes")).click();
        
        driver.findElement(By.id("selectCreditType")).click();
        Select credit =new Select(driver.findElement(By.id("selectCreditType")));
        credit.selectByVisibleText("Enrollment Credit");
        
        //Corporate Headquarters Address
        
        driver.findElement(By.id("txtCustHQAddressLineOne")).clear();
        driver.findElement(By.id("txtCustHQAddressLineOne")).sendKeys("123 PS");
        
        driver.findElement(By.id("txtCustHQAddressLineTwo")).clear();
        driver.findElement(By.id("txtCustHQAddressLineTwo")).sendKeys("abc321");
        
        driver.findElement(By.id("txtCustHQAddressCity")).clear();
        driver.findElement(By.id("txtCustHQAddressCity")).sendKeys("NYC");
        
        driver.findElement(By.id("selectCustHQAddressState")).click();
        Select state =new Select(driver.findElement(By.id("selectCustHQAddressState")));
        state.selectByVisibleText("NY");
        
        driver.findElement(By.id("txtCustHQAddressZip")).clear();
        driver.findElement(By.id("txtCustHQAddressZip")).sendKeys("1234");
        driver.findElement(By.id("rdnCustMailingSameHeadquarterYes")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerAddressZip")).isDisplayed());
        driver.findElement(By.id("txtCustHQAddressZip")).clear();
        driver.findElement(By.id("txtCustHQAddressZip")).sendKeys("12345");
        
        driver.findElement(By.id("rdnCustMailingSameHeadquarterNo")).click();
        
        //Mailing Address
        
        if(driver.findElement(By.id("txtCustMailingCustomerName")).isEnabled()) {
        	driver.findElement(By.id("txtCustMailingCustomerName")).sendKeys("test account 1");
        }
        
        driver.findElement(By.id("txtCustMailingAddressLineOne")).clear();
        driver.findElement(By.id("txtCustMailingAddressLineOne")).sendKeys("abc two");
        
        driver.findElement(By.id("txtCustMailingAddressLineTwo")).clear();
        driver.findElement(By.id("txtCustMailingAddressLineTwo")).sendKeys("jadavpur");
        
        driver.findElement(By.id("txtCustMailingAddressLineCity")).clear();
        driver.findElement(By.id("txtCustMailingAddressLineCity")).sendKeys("kolkata");
        
        driver.findElement(By.id("selectCustMailingAddressLineState")).click();
        Select state2 =new Select(driver.findElement(By.id("selectCustMailingAddressLineState")));
        state2.selectByVisibleText("AR");
        
        driver.findElement(By.id("txtCustMailingAddressLineZip")).clear();
        driver.findElement(By.id("txtCustMailingAddressLineZip")).sendKeys("1234");
        driver.findElement(By.id("txtCustExecutiveContactFirstName")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerAddressZipMailAddr")).isDisplayed());
        driver.findElement(By.id("txtCustMailingAddressLineZip")).clear();
        driver.findElement(By.id("txtCustMailingAddressLineZip")).sendKeys("123456789");
        
        //Executive Contact
        driver.findElement(By.id("txtCustExecutiveContactFirstName")).clear();
        driver.findElement(By.id("txtCustExecutiveContactFirstName")).sendKeys("jaya");
        
        driver.findElement(By.id("txtCustExecutiveContactLastName")).clear();
        driver.findElement(By.id("txtCustExecutiveContactLastName")).sendKeys("ganguly");
        
        driver.findElement(By.id("txtCustExecTitle")).clear();
        driver.findElement(By.id("txtCustExecTitle")).sendKeys("testing");
        
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumber")).clear();
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumberExtn")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerPhoneNumberExecCont")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumber")).clear();
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumber")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumberExtn")).clear();
        driver.findElement(By.id("txtCustExecutiveContactPhoneNumberExtn")).sendKeys("123456");
        
        driver.findElement(By.id("txtCustExecutiveContactEmailAddress")).clear();
        driver.findElement(By.id("txtCustExecutiveContactEmailAddress")).sendKeys("abc.com");
        driver.findElement(By.id("rdnCustPrimaryBenefitAdminSameExecutiveCorrYes")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerEmailAddressExecCont")).isDisplayed());
        driver.findElement(By.id("txtCustExecutiveContactEmailAddress")).clear();
        driver.findElement(By.id("txtCustExecutiveContactEmailAddress")).sendKeys("abc@gmail.com");
        
        driver.findElement(By.id("rdnCustPrimaryBenefitAdminSameExecutiveCorrNo")).click();
        
        //Day to Day Contact
        
        driver.findElement(By.id("txtCustFirstName")).clear();
        driver.findElement(By.id("txtCustFirstName")).sendKeys("sayani");
        
        driver.findElement(By.id("txtCustLastName")).clear();
        driver.findElement(By.id("txtCustLastName")).sendKeys("basak");
        
        driver.findElement(By.id("txtCustTitle")).clear();
        driver.findElement(By.id("txtCustTitle")).sendKeys("testing2");
        
        driver.findElement(By.id("txtCustPhoneNumber")).clear();
        driver.findElement(By.id("txtCustPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtCustExtn")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerPhoneNumberBenefitAdmin")).isDisplayed());
        driver.findElement(By.id("txtCustPhoneNumber")).clear();
        driver.findElement(By.id("txtCustPhoneNumber")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtCustExtn")).clear();
        driver.findElement(By.id("txtCustExtn")).sendKeys("123456");
        
        driver.findElement(By.id("txtCustEmailAddress")).clear();
        driver.findElement(By.id("txtCustEmailAddress")).sendKeys("abc.com");
        driver.findElement(By.id("txtCustExtn")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerEmailAddressBenefitAdmin")).isDisplayed());
        driver.findElement(By.id("txtCustEmailAddress")).clear();
        driver.findElement(By.id("txtCustEmailAddress")).sendKeys("xyz@gmail.com");
        
        //Additional Location Popup
        driver.findElement(By.id("employeeEligibleNo")).click();
        driver.findElement(By.id("employeeEligibleYes")).click();
        
        driver.findElement(By.id("btnCustSubsidiaryAddLocation")).click();
        js.executeScript("scroll(0,1000)");
        driver.findElement(By.id("btnCustAdditionalLocSaveLocation0")).click();
        Assert.assertTrue(driver.findElement(By.id("errMandField0")).isDisplayed());
        
        driver.findElement(By.id("selectCustLocationType0")).click();
        Select location =new Select(driver.findElement(By.id("selectCustLocationType0")));
        location.selectByVisibleText("Additional Location");
        
        if(driver.findElement(By.id("txtCustCompanyName0"))!=null) {
        	if(driver.findElement(By.id("txtCustCompanyName0")).getAttribute("value").contentEquals(driver.findElement(By.id("txtCustCustomerLegalName")).getAttribute("value"))){
        		System.out.println("Test Case Auto-Populated 1 Passed");
        	}
        }
        
        if(driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0"))!=null) {
        	if(driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0")).getAttribute("value").contentEquals(driver.findElement(By.id("txtCustFederalTaxIDCustDet")).getAttribute("value"))){
        		System.out.println("Test Case Auto-Populated 2 Passed");
        	}
        }
        else{
        	driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0")).sendKeys("11111");
            driver.findElement(By.id("txtCustAdditionalLocAddLineOne0")).click();
            Assert.assertTrue(driver.findElement(By.id("errCustomerSubLocFederalTaxID0")).isDisplayed());
            driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0")).clear();
            driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0")).sendKeys("123456789");
        }
        

        driver.findElement(By.id("txtCustAdditionalLocAddLineOne0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocAddLineOne0")).sendKeys("xyz two");
        
        driver.findElement(By.id("txtCustAdditionalLocAddLineTwo0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocAddLineTwo0")).sendKeys("baghajatin");
        
        driver.findElement(By.id("txtCustAdditionalLocCity0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocCity0")).sendKeys("Mumbai");
        
        driver.findElement(By.id("selectCustAdditionalLocState0")).click();
        Select addSate =new Select(driver.findElement(By.id("selectCustAdditionalLocState0")));
        addSate.selectByVisibleText("CA");
        
        driver.findElement(By.id("txtCustAdditionalLocZipCode0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocZipCode0")).sendKeys("1234");
        driver.findElement(By.id("txtCustAdditionalLocCity0")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustomerSubAddLocZipCode0")).isDisplayed());
        driver.findElement(By.id("txtCustAdditionalLocZipCode0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocZipCode0")).sendKeys("123456789");
        
        driver.findElement(By.id("rndCustAdditionalLocPrimContactYes0")).click();
        
        driver.findElement(By.id("rndCustAdditionalLocPrimContactNo0")).click();
        
        //Subsidiary/Additional Location Day to Day Contact
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactFirstName0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactFirstName0")).sendKeys("amit");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactLastName0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactLastName0")).sendKeys("dhara");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactEmail0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactEmail0")).sendKeys("abc.com");
        driver.findElement(By.id("txtCustAdditionalLocPrimContactPhoneNumberExtn0")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustAdditionalLocPrimContactEmail0")).isDisplayed());
        driver.findElement(By.id("txtCustAdditionalLocPrimContactEmail0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactEmail0")).sendKeys("xyzabcd@gmail.com");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactPhoneNumber0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactPhoneNumber0")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactPhoneNumberExtn0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactPhoneNumberExtn0")).sendKeys("123456");
        
        //contact's address
        driver.findElement(By.id("rndCustAdditionalLocPrimAddressYes0")).click();
        
        driver.findElement(By.id("rndCustAdditionalLocPrimAddressNo0")).click();
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactAddressLineOne0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactAddressLineOne0")).sendKeys("xyz 123");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactAddressLineTwo0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactAddressLineTwo0")).sendKeys("newtown");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactCity0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactCity0")).sendKeys("delhi");
        
        driver.findElement(By.id("selectCustAdditionalLocPrimContactState0")).click();
        Select newSate =new Select(driver.findElement(By.id("selectCustAdditionalLocPrimContactState0")));
        newSate.selectByVisibleText("AK");
        
        driver.findElement(By.id("txtCustAdditionalLocPrimContactZip0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactZip0")).sendKeys("1234");
        driver.findElement(By.id("txtCustAdditionalLocPrimContactCity0")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustAdditionalLocPrimContactZip0")).isDisplayed());
        driver.findElement(By.id("txtCustAdditionalLocPrimContactZip0")).clear();
        driver.findElement(By.id("txtCustAdditionalLocPrimContactZip0")).sendKeys("123456789");
        
        /*driver.findElement(By.id("btnCustAdditionalLocCancel0")).click();
        Assert.assertTrue(driver.findElement(By.id("divCancelMsg0")).isDisplayed());
        js.executeScript("scroll(0,1000)");*/
        
        driver.findElement(By.id("btnCustAdditionalLocSaveLocation0")).click();
        
        js.executeScript("scroll(0,1500)");
        //Metlink Access
        
        driver.findElement(By.id("rdnMetExecutiveCorrespondentNo")).click();
        
        driver.findElement(By.id("rdnMetPrimaryContactBenefitAdminYes")).click();
        
        driver.findElement(By.id("rndExecStopPaperBillNo")).click();
        
        driver.findElement(By.id("rndExecStopPaperBillYes")).click();
        
        driver.findElement(By.id("rdnMetDoYouWishForYourBrokerYes")).click();
        
        //Additional Metlink User
        
        driver.findElement(By.id("rdnMetDoYouWishToProvideMetYes")).click();
        driver.findElement(By.id("btnMetlinkAddUser")).click();
        
        driver.findElement(By.id("btnMetlinkAddUserSave0")).click();
        Assert.assertTrue(driver.findElement(By.id("errMandField0")).isDisplayed());
        
        driver.findElement(By.id("txtMetlinkUserFirstName0")).clear();
        driver.findElement(By.id("txtMetlinkUserFirstName0")).sendKeys("aditya");
        
        driver.findElement(By.id("txtMetlinkUserLastName0")).clear();
        driver.findElement(By.id("txtMetlinkUserLastName0")).sendKeys("raj");
        
        driver.findElement(By.id("txtMetlinkUserEmail0")).clear();
        driver.findElement(By.id("txtMetlinkUserEmail0")).sendKeys("abc.com");
        driver.findElement(By.id("txtMetlinkUserFirstName0")).click();
        Assert.assertTrue(driver.findElement(By.id("errCustAdditionalLocPrimContactEmail0")).isDisplayed());
        driver.findElement(By.id("txtMetlinkUserEmail0")).clear();
        driver.findElement(By.id("txtMetlinkUserEmail0")).sendKeys("adityad@gmail.com");
        
        driver.findElement(By.id("selectMetlinkUserType0")).click();
        Select userType =new Select(driver.findElement(By.id("selectMetlinkUserType0")));
        userType.selectByVisibleText("Broker Producer");
        
        driver.findElement(By.id("txtMetlinkUserCurntMetAccessYes0")).click();
        
        driver.findElement(By.id("btnMetlinkAddUserCancel0")).click();
        Assert.assertTrue(driver.findElement(By.id("divCancelMsgMetlinkAddUser0")).isDisplayed());
        driver.findElement(By.id("btnMetlinkAddUserSave0")).click();
        
        js.executeScript("scroll(0,2000)");
        
        driver.findElement(By.id("btnCustCustDetailsSave")).click();
        
        driver.findElement(By.id("logoutLink")).click();
        if(driver.findElement(By.id("logoutOverlay")).isDisplayed()) {
        	driver.findElement(By.id("btnlogoutYes")).click();
        }
        
    }

}
