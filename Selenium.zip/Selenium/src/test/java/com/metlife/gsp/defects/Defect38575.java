package com.metlife.gsp.defects;

import java.util.concurrent.TimeUnit;

import javax.naming.TimeLimitExceededException;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

public class Defect38575 {

    private WebDriver driver;
 private Login_DEV login;
    
 @Before
 public void setUp() {
    login = new Login_DEV();
    driver=login.setUp();
 }
 

 @Test
 public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
     
    
    JavascriptExecutor js = (JavascriptExecutor)driver; 
    driver.findElement(By.id("RFPID")).sendKeys("0062a000005W9HDSS1"); 
    driver.findElement(By.id("SearchButtonIntUser")).click();
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    driver.findElement(By.id("editCustomer")).click();
    Thread.sleep(2000);
    driver.findElement(By.id("navDashClass")).click(); 
    //driver.findElement(By.xpath("//*[@id=\"navDashClass\"]"));
    Thread.sleep(2000);
    driver.findElement(By.id("btnClsSetupAddClass")).click();
    Thread.sleep(2000);
    
    Select classDesc= new Select(driver.findElement(By.id("selectLifeNewHireWaitingPeriod1")));
    
    classDesc.selectByIndex(8);
    
    driver.close();
    
}

	

}
