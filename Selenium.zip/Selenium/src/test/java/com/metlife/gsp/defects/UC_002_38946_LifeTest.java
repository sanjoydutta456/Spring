package com.metlife.gsp.defects;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

public class UC_002_38946_LifeTest {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }
    
    @Test
   	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

   		WebElement oppID = driver.findElement(By.id("RFPID"));
   		//INT
   		oppID.sendKeys("5-4A7ONV");
   		driver.findElement(By.id("SearchButtonIntUser")).click();
   		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
   		driver.findElement(By.id("editCustomer")).click();
   		
   		WebElement lifeProductLink = driver.findElement(By.id("navDashLife"));
   		if (lifeProductLink.isDisplayed()) {
   			lifeProductLink.click();
   			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
   			assertTrue(driver.findElement(By.id("lifeTab")).isDisplayed());
   		}
   				
   		driver.manage().window().maximize();
   		Thread.sleep(2000);
   		try {
   			boolean containPresent = driver.getPageSource().contains("What is the effective date for an increase/decrease in salary");
   			if(containPresent){
   				WebElement salIncrDesc = driver.findElement(By.xpath("//*[@id=\"divProductLife\"]/div/div/div[1]/div[3]/div[1]/div[1]/span"));  		
   				String isMandate = salIncrDesc.getAttribute("class");
   				if(!isMandate.isEmpty() && isMandate.contains("mandatory")){
   					System.out.println("Testcase Fail");
   				}else{
   					System.out.println("Testcase Pass");
   				}
   			}else{
   				System.out.println("Testcase Not Present");
   			}
   			Thread.sleep(2000);
   		}catch(Exception e) {
   			System.out.println("Exception :- "+ e);
   		}
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
   	}
    
}
