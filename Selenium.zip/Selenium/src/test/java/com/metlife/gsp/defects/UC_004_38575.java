package com.metlife.gsp.defects;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class UC_004_38575 {

	
	@Test
	public void testAlphanumericEntry() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://int.custadmin.metlife.com");
		WebElement userID =  driver.findElement(By.id("USER"));
        WebElement pwd = driver.findElement(By.id("PASSWORD"));
        userID.sendKeys("gspcatqauser1");
        Thread.sleep(1000);
        pwd.sendKeys("metlife1");
        Thread.sleep(1000);
        WebElement signIn =driver.findElement(By.id("cmdEnter")); 
        signIn.click();
		Thread.sleep(2000);
        WebElement customerName = driver.findElement(By.id("customerName"));
        customerName.sendKeys("all core");
        Thread.sleep(1000);
        WebElement search = driver.findElement(By.id("SearchButtonIntUser"));
        search.click();
        Thread.sleep(3000);
        WebElement editButton = driver.findElement(By.id("editCustomer"));
        editButton.click();
        Thread.sleep(2000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
        WebElement classSetupInfo = driver.findElement(By.id("navDashClass"));
        classSetupInfo.click();
        Thread.sleep(7000);
        
        //For Add Class
        WebElement addClass =driver.findElement(By.id("btnClsSetupAddClass"));
        addClass.click();
        Thread.sleep(1000);
        
        
        //For Life
        WebElement selectCheckbox = driver.findElement(By.id("chkClsSelect49_9_0"));
        selectCheckbox.click();
        Thread.sleep(1000);
        JavascriptExecutor js = ((JavascriptExecutor)driver);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
        WebElement selectWaitingPeriod = driver.findElement(By.id("selectLifeNewHireWaitingPeriod9"));
        selectWaitingPeriod.click();
        Select dropdown = new Select(driver.findElement(By.id("selectLifeNewHireWaitingPeriod9")));
        dropdown.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriod = driver.findElement(By.id("txtClsLifeEnterWaitperiod9"));
        specifyWaitingPeriod.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Life");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-600);
        
        //For Dental
        WebElement dentalTab = driver.findElement(By.id("Dental9"));
        dentalTab.click();
        Thread.sleep(1000);
        WebElement selectCheckboxForDental = driver.findElement(By.id("chkClsSelect9999_9_1"));
        selectCheckboxForDental.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),400);
        WebElement selectWaitingPeriodForDental = driver.findElement(By.id("selectDentalNewHireWaitingPeriod9"));
        selectWaitingPeriodForDental.click();
        Select dropdownForDental = new Select(driver.findElement(By.id("selectDentalNewHireWaitingPeriod9")));
        dropdownForDental.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForDental = driver.findElement(By.id("txtClsDentalEnterWaitperiod9"));
        specifyWaitingPeriodForDental.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Dental");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-400);
        
      //For Disability
        WebElement disabilityTab = driver.findElement(By.id("Disability9"));
        disabilityTab.click();
        Thread.sleep(1000);
        WebElement selectCheckboxForDisability = driver.findElement(By.id("chkClsSelect61_9_0"));
        selectCheckboxForDisability.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
        WebElement selectWaitingPeriodForDisability = driver.findElement(By.id("selectDisabilityNewHireWaitingPeriod9"));
        selectWaitingPeriodForDisability.click();
        Select dropdownForDisability = new Select(driver.findElement(By.id("selectDisabilityNewHireWaitingPeriod9")));
        dropdownForDisability.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForDisability = driver.findElement(By.id("txtDisabilityNewHireWaitingPeriodValue9"));
        specifyWaitingPeriodForDisability.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Disability");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-600);
        
        //For Vision
        WebElement visionTab = driver.findElement(By.id("Vision9"));
        visionTab.click();
        Thread.sleep(1000);
        WebElement selectCheckboxForVision = driver.findElement(By.id("chkClsSelect102_9_0"));
        selectCheckboxForVision.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),400);
        WebElement selectWaitingPeriodForVision = driver.findElement(By.id("selectVisionNewHireWaitingPeriod9"));
        selectWaitingPeriodForVision.click();
        Select dropdownForVision = new Select(driver.findElement(By.id("selectVisionNewHireWaitingPeriod9")));
        dropdownForVision.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForVision = driver.findElement(By.id("txtClsVisionEnterWaitperiod9"));
        specifyWaitingPeriodForVision.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Vision");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-400);
        
        WebElement closeButton = driver.findElement(By.id("closeBtn9"));
        closeButton.click();
        Thread.sleep(1000);
        closeButton.click();
        Thread.sleep(1000);
        
        //For Edit/Review
        WebElement editAndReview =driver.findElement(By.id("btnClsTempEditReview8"));
        editAndReview.click();
        
        
        //For Life
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1100);
        WebElement selectWaitingPeriodEdit = driver.findElement(By.id("selectLifeNewHireWaitingPeriod8"));
        selectWaitingPeriodEdit.click();
        Select dropdownEdit = new Select(driver.findElement(By.id("selectLifeNewHireWaitingPeriod8")));
        dropdownEdit.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodEdit = driver.findElement(By.id("txtClsLifeEnterWaitperiod8"));
        specifyWaitingPeriodEdit.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Life under Edit");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-300);
        
        //For Dental Edit
        WebElement dentalTabEdit = driver.findElement(By.id("Dental8"));
        dentalTabEdit.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),800);
        WebElement selectWaitingPeriodForDentalEdit = driver.findElement(By.id("selectDentalNewHireWaitingPeriod8"));
        selectWaitingPeriodForDentalEdit.click();
        Select dropdownForDentalEdit = new Select(driver.findElement(By.id("selectDentalNewHireWaitingPeriod8")));
        dropdownForDentalEdit.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForDentalEdit = driver.findElement(By.id("txtClsDentalEnterWaitperiod8"));
        specifyWaitingPeriodForDentalEdit.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Dental under Edit");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-300);
   
      //For Disability Edit
        WebElement disabilityTabEdit = driver.findElement(By.id("Disability8"));
        disabilityTabEdit.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),800);
        WebElement selectWaitingPeriodForDisabilityEdit = driver.findElement(By.id("selectDisabilityNewHireWaitingPeriod8"));
        selectWaitingPeriodForDisabilityEdit.click();
        Select dropdownForDisabilityEdit = new Select(driver.findElement(By.id("selectDisabilityNewHireWaitingPeriod8")));
        dropdownForDisabilityEdit.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForDisabilityEdit = driver.findElement(By.id("txtDisabilityNewHireWaitingPeriodValue8"));
        specifyWaitingPeriodForDisabilityEdit.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Disability");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-300);
        
        //For Vision Edit
        WebElement visionTabEdit = driver.findElement(By.id("Vision8"));
        visionTabEdit.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),800);
        WebElement selectWaitingPeriodForVisionEdit = driver.findElement(By.id("selectVisionNewHireWaitingPeriod8"));
        selectWaitingPeriodForVisionEdit.click();
        Select dropdownForVisionEdit = new Select(driver.findElement(By.id("selectVisionNewHireWaitingPeriod8")));
        dropdownForVisionEdit.selectByIndex(8);
        Thread.sleep(1000);
        Thread.sleep(2000);
        WebElement specifyWaitingPeriodForVisionEdit = driver.findElement(By.id("txtClsVisionEnterWaitperiod8"));
        specifyWaitingPeriodForVisionEdit.sendKeys("Qwerty123#");
        System.out.println("Waiting period field is taking numeric, alphanumeric and special characters for Vision");
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),-300);
        
        WebElement closeButtonEdit = driver.findElement(By.id("closeBtn8"));
        closeButtonEdit.click();
        Thread.sleep(1000);
        closeButtonEdit.click();
        Thread.sleep(1000);
        
        
        //Logout and quit
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.quit();
        
	}
}

