package com.metlife.gsp.login;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.stereotype.Component;


public class Login_DEV {
	
	private WebDriver driver;
	

    public WebDriver setUp() {
   	
        System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
        driver = new ChromeDriver();
        //gspLogin("https://dev.custadmin.metlife.com", "gspcatqauser1","metlife1");
        gspLogin("https://dev.custadmin.metlife.com/siteminderagent/forms/login.fcc", "gspcatqauser1","metlife1");
        
		return driver;
    }
    
    
    public void gspLogin(String url, final String username, final String password) {
    	if(url != null) {
    		driver.get(url);
    		//driver.get("https://int.custadmin.metlife.com");
    		
    	}
        WebElement userID =  driver.findElement(By.id("USER"));
        WebElement pwd = driver.findElement(By.id("PASSWORD"));
        userID.sendKeys(username);
        pwd.sendKeys(password);
        driver.findElement(By.id("cmdEnter")).click();

        
    }
}
