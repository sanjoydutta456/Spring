package com.metlife.gsp.products;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class PropertyAndCasualtyTest {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        
        Thread.sleep(1500);  
        driver.findElement(By.id("navDashPropCas")).click();
        driver.findElement(By.id("txtMinHoursForPayroll")).sendKeys("44");; 
        driver.findElement(By.id("rndPropertyCasualtyIncludeAuto")).click();
        driver.findElement(By.id("rndPropertyCasualtyIncludeHome")).click();
        driver.findElement(By.id("rndPropertyCasualtyIncludeBoth")).click(); 
        
}
}