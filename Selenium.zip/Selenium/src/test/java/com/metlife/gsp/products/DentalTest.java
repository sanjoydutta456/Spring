package com.metlife.gsp.products;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;
//import com.metlife.gsp.login.Login_INT;

public class DentalTest {

	private WebDriver driver;
	private Login_INT login;
	private boolean iterationFlag;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}

/*	private void returnToHome(){
		
		WebElement homeEle = driver.findElement(By.className("summary"));
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}
	private void returnToHomeforBroker(){
		WebElement homeEle = driver.findElement(By.className("summary"));
		if(!iterationFlag){
			driver.manage().window().maximize();
			iterationFlag = true;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("scroll(250,0)");
		}
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}*/
	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("0062a000005PIv9AAG");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		
		driver.manage().window().maximize();
		
		
		WebElement DentalLink = driver.findElement(By.id("navDashDental"));
				if (DentalLink.isDisplayed()) {
					DentalLink.click();
					//assertTrue(driver.findElement(By.id("divbillingContactContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					
		
	 driver.findElement(By.id("rdnProdSetIsReplacementCoverageYes")).click();
	 Thread.sleep(1000);
	 driver.findElement(By.id("rdnProdSetIsReplacementCoverageNo")).click();
	 Thread.sleep(1000); 
	 
	 driver.findElement(By.id("rdnsummaryPlanDescriptionYes")).click();
	 Thread.sleep(1000);
	 driver.findElement(By.id("rdnsummaryPlanDescriptionNo")).click();
	 Thread.sleep(1000);

	 
	 driver.findElement(By.xpath("//*[@id=\"enrollmentStartDtDental\"]")).click();
	 Thread.sleep(2000);
	 
	 driver.findElement(By.id("enrollmentEndDtDental")).click();
		Thread.sleep(2000);
		
		
		 
		 driver.findElement(By.id("chkOutsideDirectors")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.id("chkCobra")).click();
		 Thread.sleep(1000);

	
		driver.findElement(By.id("rdnSponsoredCoverageYes")).click();
		 Thread.sleep(1000); 
		 driver.findElement(By.id("rdnSponsoredCoverageNo")).click();       
		 Thread.sleep(1000);

			
			driver.findElement(By.id("chkCurrentEmployees")).click();
			 Thread.sleep(1000); 
			 driver.findElement(By.id("chkFormerEmployees")).click();      
			 Thread.sleep(1000);

				driver.findElement(By.id("chkRetirees")).click();
				 Thread.sleep(1000); 
				 driver.findElement(By.id("chkDependents")).click();      
				 Thread.sleep(1000);
			 

					driver.findElement(By.id("chkQualifyingEvents")).click();
					 Thread.sleep(1000); 
					 driver.findElement(By.id("chkAdoption")).click();       
					 Thread.sleep(1000);

						
						driver.findElement(By.id("chkAnnulment")).click();
						 Thread.sleep(1000); 
						 driver.findElement(By.id("chkDeathofDependent")).click();      
						 Thread.sleep(1000);

							driver.findElement(By.id("chkSpouseEmploymentstatus")).click();
							 Thread.sleep(1000); 
							 driver.findElement(By.id("chkOther")).click();      
							 Thread.sleep(1000);
						 
							 
							 driver.findElement(By.id("txtDentalQualifyingTextBox")).sendKeys("NHF");      
							 Thread.sleep(1000);
							 
							
							 
						/*	 
							 driver.findElement(By.id("")).sendKeys("cat");
							
				              Thread.sleep(2000);*/
				 
				          	
								driver.findElement(By.id("rdnSponsoredCoverageYes")).click();
								 Thread.sleep(1000); 
								 driver.findElement(By.id("rdnSponsoredCoverageNo")).click();      
								 Thread.sleep(1000);

									driver.findElement(By.id("rdnVoluntaryCoverageYes")).click();
									 Thread.sleep(1000); 
									 driver.findElement(By.id("rdnVoluntaryCoverageNo")).click();      
									 Thread.sleep(1000);
								 
									 driver.findElement(By.id("txtPriorCarrierCompany")).clear();      
									 driver.findElement(By.id("txtPriorCarrierCompany")).sendKeys("company") ;     
									 Thread.sleep(1000);
									 
									 
									 driver.findElement(By.id("txtPriorCarrierHistoryFirstName")).clear();     

									 driver.findElement(By.id("txtPriorCarrierHistoryFirstName")).sendKeys("Arka");     
									 Thread.sleep(1000);
									 
									 driver.findElement(By.id("txtPriorCarrierHistoryLastName")).clear();      
									 driver.findElement(By.id("txtPriorCarrierHistoryLastName")).sendKeys("Das");      
									 Thread.sleep(1000);
									 
									 driver.findElement(By.id("txtPriorCarrierHistoryPhoneNumber")).clear();      
									 driver.findElement(By.id("txtPriorCarrierHistoryPhoneNumber")).sendKeys("12345678");      
									 Thread.sleep(1000);
									 
									 driver.findElement(By.id("txtPriorCarrierHistoryExt")).clear();      
									 driver.findElement(By.id("txtPriorCarrierHistoryExt")).sendKeys("1223");      
									 Thread.sleep(1000);
									 
									 driver.findElement(By.id("txtPriorCarrierHistoryEmailAddress")).clear();      
									 driver.findElement(By.id("txtPriorCarrierHistoryEmailAddress")).sendKeys("ghyj@cognizant.com");      
									 Thread.sleep(1000);
							 
				              
									 
							
									 
										driver.findElement(By.id("rdnPriorCarrierContactYes")).click();
									 Thread.sleep(1000); 
									 driver.findElement(By.id("rdnPriorCarrierContactNo")).click();      
									 Thread.sleep(1000);

									 
										driver.findElement(By.id("rdnReachPriorCarrierContactYes")).click();
									 Thread.sleep(1000); 
									 driver.findElement(By.id("rdnReachPriorCarrierContactNo")).click();      
									 Thread.sleep(1000);
									 

										driver.findElement(By.id("btnDentalSave")).click();
									 Thread.sleep(1000); 
									 

		try {

			Thread.sleep(500);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			//WebElement logoutLink = driver.findElement(By.id("logoutLink"));
			if(driver.findElement(By.id("logoutLink")).isDisplayed()) {
				js.executeScript("arguments[0].click();",  driver.findElement(By.id("logoutLink")));
				Thread.sleep(500);
			js.executeScript("arguments[0].click();",  driver.findElement(By.id("btnlogoutYes")));
			 
			}
		}catch (Exception e) {}		
		
		
		driver.quit();	
		
		
		
		
		
	}
}