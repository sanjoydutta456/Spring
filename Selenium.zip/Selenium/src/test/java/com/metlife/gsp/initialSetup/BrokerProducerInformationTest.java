package com.metlife.gsp.initialSetup;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

//for DEV
/*
import com.metlife.gsp.login.Login_DEV;

public class BrokerProducerInformationTest {

	private WebDriver driver;
	private Login_DEV login;

	@Before
	public void setUp() {
		login = new Login_DEV();
		driver = login.setUp();
	}

	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MT1");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();

		
		

		// broker producer information
		try {
			WebElement brokerProducerInformationLink = driver.findElement(By.linkText("Broker Producer Information"));
			if (brokerProducerInformationLink.isDisplayed()) {
				brokerProducerInformationLink.click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				assertTrue(driver.findElement(By.id("divBrokerProdInfoProducerDetails")).isDisplayed());
			}
		}catch(Exception e) {}
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.findElement(By.id("btnBrokerAddProducer")).click();
		Thread.sleep(500);
		
		
		driver.findElement(By.id("txtBrokerFirstName9")).sendKeys("Arka");
		driver.findElement(By.id("txtBrokerMiddleInitial9")).sendKeys("P");
		driver.findElement(By.id("txtBrokerLastName9")).sendKeys("Das");
		driver.findElement(By.id("txtBrokerAddressLineOne9")).sendKeys("Shapoorji");
		driver.findElement(By.id("txtBrokerAddressLineTwo9")).sendKeys("Newtown");
		driver.findElement(By.id("txtBrokerCity9")).sendKeys("Kolkata");
		Select state = new Select(driver.findElement(By.id("selectBrokerState9")));
		state.selectByIndex(4);
		
		
		driver.findElement(By.id("txtBrokerZipCode9")).sendKeys("70013");;
		driver.findElement(By.id("txtBrokerPhoneNumber9")).sendKeys("9836637686");;
		driver.findElement(By.id("txtBrokerExtn9")).sendKeys("324234");;
		driver.findElement(By.id("txtBrokerEmailAddress9")).sendKeys("A.Das@cognizant.com");
		driver.findElement(By.id("txtBrokerLicense9")).sendKeys("234567");

		Select type = new Select(driver.findElement(By.id("selectBrokerProducerType9")));   
		type.selectByIndex(2);
		
		driver.findElement(By.id("txtBrokerProducerSSN9")).sendKeys("333556789");
		driver.findElement(By.id("rdnIndependentProducerYes9")).click();
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay9\"]/div")),600);
		WebElement sameCommission = driver.findElement(By.id("chkCommissionAcrossProduct9"));
		sameCommission.click();
		
		driver.findElement(By.id("txtBrokerCommissions9")).sendKeys("25");
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay9\"]/div")),800);
		driver.findElement(By.id("rdnBrokerRecvElecCommQuesYes9")).click();
		Thread.sleep(500);
		
		//System.out.println("1");
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay9\"]/div")),800);
		driver.findElement(By.id("rdnBrokerContactAtProducerOfficeYes9")).click();
		Thread.sleep(500);
		//System.out.println("2");
		
		
		driver.findElement(By.id("txtBrokerFirstNameProdCont9")).sendKeys("Kamalika");
		driver.findElement(By.id("txtBrokerLastNameProdCont9")).sendKeys("Dasgupta");
		driver.findElement(By.id("txtBrokerPhoneNumberProdCont9")).sendKeys("9051633051");
		driver.findElement(By.id("txtBrokerExtnProdCont9")).sendKeys("257321");
		driver.findElement(By.id("txtBrokerEmailAddrProdCont9")).sendKeys("K.DG@cognizant.com");
		
		//System.out.println("3");
		
		driver.findElement(By.id("btnBrokerProdInfoSaveProd9")).click();
		
		*/
		
		
		  //for int
		
		  import com.metlife.gsp.login.Login_INT;

public class BrokerProducerInformationTest {

	private WebDriver driver;
	private Login_INT login;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}

	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		 
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("0062a000005PNpOAAW"); //eligible life 35
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();

		
		

		// broker producer information
		try {
			WebElement brokerProducerInformationLink = driver.findElement(By.linkText("Broker Producer Information"));
			if (brokerProducerInformationLink.isDisplayed()) {
				brokerProducerInformationLink.click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				assertTrue(driver.findElement(By.id("divBrokerProdInfoProducerDetails")).isDisplayed());
			}
		}catch(Exception e) {}
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		
		//add broker producer popup
		
				/*
		driver.findElement(By.id("btnBrokerAddProducer")).click();
		Thread.sleep(500);
		System.out.println("test");
		
		
		
		driver.findElement(By.id("txtBrokerFirstName3")).sendKeys("Arka");
		driver.findElement(By.id("txtBrokerMiddleInitial3")).sendKeys("P");
		driver.findElement(By.id("txtBrokerLastName3")).sendKeys("Das");
		driver.findElement(By.id("txtBrokerAddressLineOne3")).sendKeys("Shapoorji");
		driver.findElement(By.id("txtBrokerAddressLineTwo3")).sendKeys("Newtown");
		driver.findElement(By.id("txtBrokerCity3")).sendKeys("Kolkata");
		Select state = new Select(driver.findElement(By.id("selectBrokerState3")));
		state.selectByIndex(4);
		
		
		driver.findElement(By.id("txtBrokerZipCode3")).sendKeys("70013");;
		driver.findElement(By.id("txtBrokerPhoneNumber3")).sendKeys("9836637686");;
		driver.findElement(By.id("txtBrokerExtn3")).sendKeys("324234");;
		driver.findElement(By.id("txtBrokerEmailAddress3")).sendKeys("A.Das@cognizant.com");
		driver.findElement(By.id("txtBrokerLicense3")).sendKeys("234567");

		Select type = new Select(driver.findElement(By.id("selectBrokerProducerType3")));   
		type.selectByIndex(2);
		
		driver.findElement(By.id("txtBrokerProducerSSN3")).sendKeys("333556789");
		driver.findElement(By.id("rdnIndependentProducerYes3")).click();
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay3\"]/div")),600);
		WebElement sameCommission = driver.findElement(By.id("chkCommissionAcrossProduct3"));
		sameCommission.click();
		
		driver.findElement(By.id("txtBrokerCommissions3")).sendKeys("25");
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay3\"]/div")),1000);
		driver.findElement(By.id("rdnBrokerRecvElecCommQuesYes3")).click();
		driver.findElement(By.id("rdnBrokerRecvElecCommQuesYes3")).click();
		Thread.sleep(500);
		
		//System.out.println("1");
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.xpath("//*[@id=\"addProducerOverlay3\"]/div")),1000);
		driver.findElement(By.id("rdnBrokerContactAtProducerOfficeYes3")).click();
		driver.findElement(By.id("rdnBrokerContactAtProducerOfficeYes3")).click();
		Thread.sleep(500);
		//System.out.println("2");
		
		
		driver.findElement(By.id("txtBrokerFirstNameProdCont3")).sendKeys("Kamalika");
		driver.findElement(By.id("txtBrokerLastNameProdCont3")).sendKeys("Dasgupta");
		driver.findElement(By.id("txtBrokerPhoneNumberProdCont3")).sendKeys("9051633051");
		driver.findElement(By.id("txtBrokerExtnProdCont3")).sendKeys("257321");
		driver.findElement(By.id("txtBrokerEmailAddrProdCont3")).sendKeys("K.DG@cognizant.com");
		
		//System.out.println("3");
		
		driver.findElement(By.id("btnBrokerProdInfoSaveProd3")).click();
		
		*/
		
		//after hitting save button of add broker producer pop up
		
		driver.findElement(By.id("rdnBrokerAnotherApproverNo")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("rdnBrokerAnotherApproverYes")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("rdnBrokerPriAppExistingContacts")).click();
		Thread.sleep(1000);
		
		Select existingContact = new Select(driver.findElement(By.id("selectPriAppExistingContact")));
		existingContact.selectByIndex(3);
		
		
		driver.findElement(By.id("txtBrokerPriAppExistingUserMiddleInitial3")).sendKeys("X");
		driver.findElement(By.id("txtBrokerPriAppExistingUserAddressLineOne3")).sendKeys("Garia");
		driver.findElement(By.id("txtBrokerPriAppExistingUserAddressLineTwo3")).sendKeys("Bus Stand");
		driver.findElement(By.id("txtBrokerPriAppExistingUserCity3")).sendKeys("Kolkata");
		Select brokerState = new Select(driver.findElement(By.id("selectBrokerPriAppExistingUserState3")));
		brokerState.selectByIndex(4);
		driver.findElement(By.id("txtBrokerPriAppExistingUserZipCode3")).sendKeys("70101");
		driver.findElement(By.id("txtBrokerPriAppExistingUserLicense3")).sendKeys("5678901");
		driver.findElement(By.id("txtBrokerPriAppExistingUserSSN3")).sendKeys("111770000");
		
		driver.findElement(By.id("btnBrokerSave")).click();
		System.out.println("Contacts");
		
		
		
		
		
		
	}

}
