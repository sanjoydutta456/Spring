package com.metlife.gsp.products;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class DisabilityTest {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        
        Thread.sleep(1500);
        driver.findElement(By.id("navDashDisability")).click();
        driver.findElement(By.id("rdnDisabreplacementCoverageYes")).click();
        driver.findElement(By.id("rdnDisabreplacementCoverageNo")).click();
        Select drop1=new Select(driver.findElement(By.id("selectDisabilityEmployeeTax")));
        drop1.selectByIndex(1);
        drop1.selectByIndex(2);
        
        Select drop2=new Select(driver.findElement(By.id("selectDisabilityEffectiveSalDateSTD")));
        drop2.selectByIndex(1);
        drop2.selectByIndex(2);
        drop2.selectByIndex(3);
        drop2.selectByIndex(4);
       // drop2.selectByIndex(5);
        driver.findElement(By.id("txtMetlifePriorCarrierSTD")).sendKeys("xyz"); 
        driver.findElement(By.id("rdnDisabilitySalContinuationYes")).click();
        driver.findElement(By.id("rdnDisabilitySalContinuationNo")).click();
        driver.findElement(By.id("txtExplain")).sendKeys("A quick brown fox");
        driver.findElement(By.id("txtMetlifePriorCarrier")).sendKeys("Abrownfox");
        driver.findElement(By.id("rdnDisabilityMetlifePriorCarrierRetainYes")).click();
        driver.findElement(By.id("rdnDisabilityMetlifePriorCarrierRetainNo")).click();
        driver.findElement(By.id("chkMarriage")).click();
        driver.findElement(By.id("chkChild")).click();
        driver.findElement(By.id("chkDivorce")).click();
        driver.findElement(By.id("chkDisabOther")).click();
        driver.findElement(By.id("chkDeath")).click();
        driver.findElement(By.id("txtDisabilityQualifyingTextBox")).sendKeys("XRRFFF");
        Select drop3=new Select(driver.findElement(By.id("selectDisabilityEffectiveSalDateLTD")));
        drop3.selectByIndex(1);
        drop3.selectByIndex(2);
        drop3.selectByIndex(3);
        drop3.selectByIndex(4);
        //drop2.selectByIndex(5);
        driver.findElement(By.id("txtExplainEffectiveSalLTD")).sendKeys("XRRFFF"); 
        driver.findElement(By.id("txtMetlifePriorCarrierLTD")).sendKeys("XRRFFF"); 
        driver.findElement(By.id("txtReoccurringDisability")).sendKeys("Xhujhuuh");   
        driver.findElement(By.id("chkTelephonicIntake")).click();
        driver.findElement(By.id("chkMetlinkIntake")).click();
        driver.findElement(By.id("chkEmployeeIntake")).click();
        driver.findElement(By.id("chkPaperClaimForm")).click();
        driver.findElement(By.id("chkStatutoryStatePlan0")).click();
        driver.findElement(By.id("txtAdditionalCompNames")).sendKeys("XRRFFF"); 
        driver.findElement(By.id("rdnDisabilityCloseIntakeNo")).click();
        driver.findElement(By.id("rdnDisabilityCloseIntakeYes")).click();
        driver.findElement(By.id("txtCloseIntakeExplain")).sendKeys("explain"); 
        driver.findElement(By.id("txtStatutoryAdministrator")).sendKeys("Aditya");
        Select drop4=new Select(driver.findElement(By.id("selectDisabilityPreferredComm")));
        drop4.selectByIndex(1);
        drop4.selectByIndex(2);
        drop4.selectByIndex(3);
        //drop4.selectByIndex(4);
        driver.findElement(By.id("txtTextPreferredComm")).sendKeys("prefeerfd");
        driver.findElement(By.id("rdnDisabRetirementProgYes")).click();
        driver.findElement(By.id("txtRetirementProgYes")).sendKeys("Aditya Rajj");
        driver.findElement(By.id("rdnDisabOtherRetirementProgNo")).click();
        driver.findElement(By.id("rdnDisabOtherRetirementProgYes")).click();
        driver.findElement(By.id("txtOtherRetirementProgExplain")).sendKeys("Mohit Kumar");
        driver.findElement(By.id("rdnDisabCBAClaimPaymentsYes")).click(); 
        driver.findElement(By.id("rdnDisabCBAClaimPaymentsNo")).click(); 
        driver.findElement(By.id("rdnDisabSTDCovYes")).click();
        driver.findElement(By.id("rdnDisabSTDDuringLTDElimYes")).click();
        driver.findElement(By.id("txtSTDDuringLTDElimExplain")).sendKeys("xyxx");
        //driver.findElement(By.id("rdnDisabSTDCovNo")).click(); 
        driver.findElement(By.id("txtEmpNotAccomodate")).sendKeys("mohit"); 
        //driver.findElement(By.id("rdnDisabOtherRetirementProgYes")).click(); 
        Select drop5=new Select(driver.findElement(By.id("selectDisabilityDutiesOffered")));
        drop5.selectByIndex(1);
        drop5.selectByIndex(2);
        drop5.selectByIndex(3);
        //drop5.selectByIndex(4);
        driver.findElement(By.id("txtExplain")).sendKeys("mohit");  
        driver.findElement(By.id("rdnDisabStatePensionProgBenefitsNo")).click();
        driver.findElement(By.id("rdnDisabStatePensionProgBenefitsYes")).click();
        Select drop6=new Select(driver.findElement(By.id("selectDisabilityEligibleEmployee")));
        drop6.selectByIndex(1);
        drop6.selectByIndex(2);
       // drop6.selectByIndex(3);
        driver.findElement(By.id("txtSegCriteria")).sendKeys("mohit"); 
        driver.findElement(By.id("txtInfoOffsetBenefits")).sendKeys("mohit");
        driver.findElement(By.id("txtContactInfoOffsetBenefits")).sendKeys("mohit");
        Select drop7=new Select(driver.findElement(By.id("selectDisabilityErisaClaimFiduciary")));
        drop7.selectByIndex(1);
        drop7.selectByIndex(2);
        driver.findElement(By.id("txtSelectNonErisaLevelOfAppeal")).sendKeys("mohit");  
        driver.findElement(By.id("txtSelectNonErisaHandleAppeal")).sendKeys("mohit"); 
        driver.findElement(By.id("txtSelectNonErisaCivilAction")).sendKeys("mohit"); 
        driver.findElement(By.id("txtSelectNonErisaDuration")).sendKeys("mohit");  
        driver.findElement(By.id("txtSelectNonErisaAppealProcess")).sendKeys("mohit");  
        driver.findElement(By.id("rdnDisabClaimJobDescNo")).click();
        driver.findElement(By.id("rdnDisabClaimJobDescYes")).click();
        driver.findElement(By.id("rdnDisabFICAExemptNo")).click(); 
        driver.findElement(By.id("rdnDisabFICAExemptYes")).click();
        driver.findElement(By.id("rdntaxReportingExemptStatusSocialSecurityExemptNew")).click(); 
        driver.findElement(By.id("rdntaxReportingExemptStatusMedicareExemptNew")).click(); 
        driver.findElement(By.id("rdntaxReportingExemptSSAndMedicareNew")).click(); 
        driver.findElement(By.id("rdnDisabOnsiteMedClaimNo")).click();  
        driver.findElement(By.id("rdnDisabOnsiteMedClaimYes")).click();
        driver.findElement(By.id("txtOnsiteMedClaimContName")).sendKeys("Aditya");   
        driver.findElement(By.id("txtOnsiteMedClaimContactAddress")).sendKeys("Kolkata"); 
        driver.findElement(By.id("txtJobDescAndMethodFirstName")).sendKeys("Aditya"); 
        driver.findElement(By.id("txtJobDescAndMethodLastName")).sendKeys("Raj"); 
        driver.findElement(By.id("txtJobDescAndMethodAddress")).sendKeys("Kolkata");  
        driver.findElement(By.id("txtJobDescAndMethodPhoneNum")).sendKeys("9874563210");  
        Select drop8=new Select(driver.findElement(By.id("selectDisabilityMethod"))); 
        drop8.selectByIndex(1);
        drop8.selectByIndex(2);
        driver.findElement(By.id("txtWCContName")).sendKeys("Aditya"); 
        driver.findElement(By.id("txtWCcontadd")).sendKeys("Kolkata"); 
        driver.findElement(By.id("txtWCContPhoneNum")).sendKeys("9874563210"); 
        Select drop9=new Select(driver.findElement(By.id("selectDisabilitydivPrefContMethod"))); 
        drop9.selectByIndex(1);
        drop9.selectByIndex(2);
        drop9.selectByIndex(3);
       // drop9.selectByIndex(4);
        driver.findElement(By.id("txtDLContFName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtDLContLName")).sendKeys("Aditya"); 
        driver.findElement(By.id("txtDLContAddress")).sendKeys("Kolkata");  
        driver.findElement(By.id("txtCoordWCFirstName")).sendKeys("Aditya"); 
        driver.findElement(By.id("txtCoordWCLastName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtCoordWCPhoneNum")).sendKeys("9874563210");  
        driver.findElement(By.id("txtCoordWCExt")).sendKeys("25565"); 
        driver.findElement(By.id("txtCoordWCEmailAdd")).sendKeys("Aditya@gmail.com"); 
        driver.findElement(By.id("txtTaxReportFirstName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtDLContFName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtTaxReportLastName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtTaxReportPhoneNum")).sendKeys("9874563210");   
        driver.findElement(By.id("txtTaxReportExt")).sendKeys("52236");   
        driver.findElement(By.id("txtTaxReportEmailAdd")).sendKeys("Aditya@gmail.com");  
        driver.findElement(By.id("txtFICAFirstName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtFICALastName")).sendKeys("Aditya");   
        driver.findElement(By.id("txtFICAPhoneNum")).sendKeys("9874563210");  
        driver.findElement(By.id("txtFICAExt")).sendKeys("56325");  
        driver.findElement(By.id("txtFICAEmailAdd")).sendKeys("Aditya@gmail.com");  
        driver.findElement(By.id("txtYearEndFirstName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtYearEndLastName")).sendKeys("Aditya");  
        driver.findElement(By.id("txtYearEndPhoneNum")).sendKeys("9874563210");   
        driver.findElement(By.id("txtYearEndExt")).sendKeys("55568");  
        driver.findElement(By.id("txtYearEndEmailAdd")).sendKeys("Aditya@gmail.com");  
        driver.findElement(By.id("rdnDisabEmpActivelyWorkQuesNo")).click();  
        driver.findElement(By.id("rdnDisabEmpActivelyWorkQuesYes")).click();  
    }
}
