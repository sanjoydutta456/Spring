package com.metlife.gsp.admin.userManagement;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_INT;



public class ManageMetlifeContacts {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    	
    }
    
public void searchOpportunity() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
        
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"editCustomer\"]"))).click();
		
    }


    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
        
    	
    	WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
    	driver.findElement(By.id("RFPID")).sendKeys("1-1F5MS1"); 
        searchOpportunity();
    	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"leftNavAdminInfo\"]"))).click();
		System.out.println("t1");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"breadManageContacts\"]"))).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("t2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//wait.until(ExpectedConditions.elementToBeClickable(By.id("breadManageContacts"))).click();
        //driver.findElement(By.id("breadManageContacts")).click(); 
       // wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"btnSecMgnmtHeaderNo\"]"))).click();
       // driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        
        
        //Implementation Lead Details
        
	        //test case 1 - check if the salesOffice field is not disabled
	        //Assert.assertFalse(driver.findElement(By.id("appDataMap'SSA.SalesOffice'")).isEnabled());
	        System.out.println("Test Case 1 passed");
      
        
	        //test case 2 - when no attributes are filled up and the user clicks on update
	        Thread.sleep(1000);
        	driver.findElement(By.id("txtManageContactFirstName")).clear();
            driver.findElement(By.id("txtManageContactLastName")).clear();
            driver.findElement(By.id("txtManageContactUserId")).clear();
            driver.findElement(By.id("txtManageContactEmailAddress")).clear();
            driver.findElement(By.id("txtManageContactPhoneNumber")).clear();
            driver.findElement(By.id("txtManageContactFaxNumber")).clear();
            driver.findElement(By.id("txtManageContactAddressLineOne")).clear();
            driver.findElement(By.id("txtManageContactAddressLineTwo")).clear();
            driver.findElement(By.id("txtManageContactAddressLineThree")).clear();
            driver.findElement(By.id("txtManageContactAddressLineFour")).clear();
            driver.findElement(By.id("txtManageContactCity")).clear();
            driver.findElement(By.id("txtManageContactZip")).clear();
            Assert.assertTrue(driver.findElement(By.id("btnAdminManageConUpdate")).isDisplayed());
            driver.findElement(By.id("btnAdminManageConUpdate")).click();
            Assert.assertTrue("Test Case 2 failed", driver.findElement(By.id("errMandField")).isDisplayed());
            System.out.println("Test Case 2 passed");
            
        
            //test case 3 - when all the attributes are filled up and the user clicks on update
            driver.findElement(By.id("txtManageContactFirstName")).clear();
            driver.findElement(By.id("txtManageContactFirstName")).sendKeys("Sayani");
            driver.findElement(By.id("txtManageContactLastName")).clear();
            driver.findElement(By.id("txtManageContactLastName")).sendKeys("Basak");
            driver.findElement(By.id("txtManageContactUserId")).clear();
            driver.findElement(By.id("txtManageContactUserId")).sendKeys("123456");
            driver.findElement(By.id("txtManageContactEmailAddress")).clear();
            driver.findElement(By.id("txtManageContactEmailAddress")).sendKeys("sbasak@gmail.com");
            driver.findElement(By.id("txtManageContactPhoneNumber")).clear();
            driver.findElement(By.id("txtManageContactPhoneNumber")).sendKeys("12345");
            driver.findElement(By.id("txtManageContactEmailAddress")).click();
            Assert.assertTrue(driver.findElement(By.id("errManageContactPhoneNumber")).isDisplayed());
            driver.findElement(By.id("txtManageContactPhoneNumber")).clear();
            driver.findElement(By.id("txtManageContactPhoneNumber")).sendKeys("1234567980");
            driver.findElement(By.id("txtManageContactFaxNumber")).clear();
            driver.findElement(By.id("txtManageContactFaxNumber")).sendKeys("123435");
            driver.findElement(By.id("txtManageContactPhoneNumber")).click();
            Assert.assertTrue(driver.findElement(By.id("errManageContactFaxNumber")).isDisplayed());
            driver.findElement(By.id("txtManageContactFaxNumber")).clear();
            driver.findElement(By.id("txtManageContactFaxNumber")).sendKeys("2549751622");
            
            driver.findElement(By.id("txtManageContactAddressLineOne")).clear();
            driver.findElement(By.id("txtManageContactAddressLineOne")).sendKeys("Dum Dum");
            driver.findElement(By.id("txtManageContactAddressLineTwo")).clear();
            driver.findElement(By.id("txtManageContactAddressLineTwo")).sendKeys("Nagerbazar");
            driver.findElement(By.id("txtManageContactAddressLineThree")).clear();
            driver.findElement(By.id("txtManageContactAddressLineThree")).sendKeys("Kolkata");
            driver.findElement(By.id("txtManageContactAddressLineFour")).clear();
            driver.findElement(By.id("txtManageContactAddressLineFour")).sendKeys("North 24 Parganas");
            driver.findElement(By.id("txtManageContactCity")).clear();
            driver.findElement(By.id("txtManageContactCity")).sendKeys("Kolkata");
            driver.findElement(By.id("selectManageContactState")).click();
            Select state=new Select (driver.findElement(By.id("selectManageContactState")));
            state.selectByVisibleText("WY");
            driver.findElement(By.id("txtManageContactZip")).clear();
            driver.findElement(By.id("txtManageContactZip")).sendKeys("123");
            driver.findElement(By.id("txtManageContactCity")).click();
            Assert.assertTrue(driver.findElement(By.id("errManageContactZipCode")).isDisplayed());
            driver.findElement(By.id("txtManageContactZip")).clear();
            driver.findElement(By.id("txtManageContactZip")).sendKeys("9000000000");
            Assert.assertTrue(driver.findElement(By.id("btnAdminManageConUpdate")).isDisplayed());
            driver.findElement(By.id("btnAdminManageConUpdate")).click();
            Assert.assertTrue("Test case 3 failed",driver.findElement(By.id("divOppListStatusMessage")).isDisplayed());
            
            System.out.println("Test case 3 passed");
            
            
            
          //Account Executive Test Cases
        	
        	Assert.assertTrue((driver.findElement(By.id("accountExecutive")).isDisplayed()));
        	driver.findElement(By.id("accountExecutive")).click();
        	Assert.assertTrue((driver.findElement(By.id("div_secMgnmtHeaderOverlay")).isDisplayed()));
        	
        	//Nagivating without saving data of previous page
        	driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        	Assert.assertTrue((driver.findElement(By.id("divLicensedMetLifeAgentESign")).isDisplayed()));
        	
        	
        		//Test Case 4 - Clear all fields and click on Update
        	
        		driver.findElement(By.id("txtAccountExecutiveName")).clear();
        		driver.findElement(By.id("txtAccountExecutiveLastName")).clear();
        		driver.findElement(By.id("txtAccountExecutiveEmail")).clear();
        		driver.findElement(By.id("txtlicensedMetLifeAgentSLN")).clear();
        		Assert.assertFalse("Situs State is not disabled", (driver.findElement(By.id("txtAccountExecutiveSitusState")).isEnabled()));
        		Assert.assertFalse("Signature Date is not disabled", (driver.findElement(By.id("txtlicensedMetLifeAgentDate")).isEnabled()));
        		driver.findElement(By.id("btnAccountExecutiveUpdate")).click();
        		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        		Assert.assertTrue("Test Case 4 Failed",(driver.findElement(By.id("errMandField")).isDisplayed()));
        		driver.findElement(By.id("logoutLink")).click();
        		Assert.assertTrue((driver.findElement(By.id("div_logout")).isDisplayed()));
        		driver.findElement(By.id("btnlogoutNo")).click();
        		System.out.println("Test Case 4 passed");
        		
        		//Test Case 5 - Fill Up all fields and click on Update
        		
        		driver.findElement(By.id("txtAccountExecutiveName")).sendKeys("Bumba");
        		driver.findElement(By.id("txtAccountExecutiveLastName")).sendKeys("Da");
        		driver.findElement(By.id("txtAccountExecutiveEmail")).sendKeys("sg");
        		driver.findElement(By.id("txtAccountExecutiveLastName")).click();
        		Assert.assertTrue((driver.findElement(By.id("errAccountExecutiveEmailAddress")).isDisplayed()));
        		driver.findElement(By.id("txtAccountExecutiveEmail")).clear();
        		driver.findElement(By.id("txtAccountExecutiveEmail")).sendKeys("sg@gmail.com");
        		driver.findElement(By.id("txtlicensedMetLifeAgentSLN")).sendKeys("154");
        		Assert.assertFalse("Situs State is not disabled", (driver.findElement(By.id("txtAccountExecutiveSitusState")).isEnabled()));
        		Assert.assertFalse("Signature Date is not disabled", (driver.findElement(By.id("txtlicensedMetLifeAgentDate")).isEnabled()));
        		driver.manage().window().maximize();
        		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        		
        		driver.findElement(By.id("btnAccountExecutiveUpdate")).click();
        		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        		Assert.assertFalse("Test Case 5 Failed",(driver.findElement(By.id("errMandField")).isDisplayed()));
        		System.out.println("s1");
        		
        		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"btnAccountExecutiveToDash\"]")));
        		System.out.println("Test Case 5 passed");
        		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        		
        		
        		//Nagivating by saving data of previous page
        		js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"leftNavAdminInfo\"]")));
        		js.executeScript("arguments[0].click();", driver.findElement(By.id("btnleftNavigationYes")));
        		System.out.println("s2");
        		
        		Thread.sleep(2000);
        		Assert.assertTrue((driver.findElement(By.id("breadSubUserMgt")).isDisplayed()));
        		Assert.assertTrue((driver.findElement(By.id("breadManageContacts")).isDisplayed()));
        		
        		
        		js.executeScript("arguments[0].click();", driver.findElement(By.id("breadManageContacts")));
        		System.out.println("s3");
        		Assert.assertTrue((driver.findElement(By.id("divSecMgnmtHeaderOverlay")).isDisplayed()));
        		js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSecMgnmtHeaderYes")));
        		Assert.assertTrue((driver.findElement(By.id("implementationLead")).isDisplayed()));
        		Assert.assertTrue((driver.findElement(By.id("accountExecutive")).isDisplayed()));
        		js.executeScript("arguments[0].click();", driver.findElement(By.id("accountExecutive")));
        		Assert.assertTrue((driver.findElement(By.id("divSecMgnmtHeaderOverlay")).isDisplayed()));
        		js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSecMgnmtHeaderYes")));
        		
	        		//Test Case 6 - Clear all fields and click on Update
	            	
	        		driver.findElement(By.id("txtAccountExecutiveName")).clear();
	        		driver.findElement(By.id("txtAccountExecutiveLastName")).clear();
	        		driver.findElement(By.id("txtAccountExecutiveEmail")).clear();
	        		driver.findElement(By.id("txtlicensedMetLifeAgentSLN")).clear();
	        		Assert.assertFalse("Situs State is not disabled", (driver.findElement(By.id("txtAccountExecutiveSitusState")).isEnabled()));
	        		Assert.assertFalse("Signature Date is not disabled", (driver.findElement(By.id("txtlicensedMetLifeAgentDate")).isEnabled()));
	        		
	        		js.executeScript("arguments[0].click();",driver.findElement(By.id("btnAccountExecutiveUpdate")));
	        		Assert.assertTrue("Test Case 1 Failed",(driver.findElement(By.id("errMandField")).isDisplayed()));
	        		js.executeScript("arguments[0].click();",driver.findElement(By.id("logoutLink")));
	        		Assert.assertTrue((driver.findElement(By.id("div_logout")).isDisplayed()));
	        		Thread.sleep(2000);
	        		js.executeScript("arguments[0].click();",driver.findElement(By.id("btnlogoutNo")));
	        		System.out.println("Test Case 6 passed");
	        		
	        		//Test Case 7 - Fill Up all fields and click on Update
	        		
	        		driver.findElement(By.id("txtAccountExecutiveName")).sendKeys("Bumba");
	        		driver.findElement(By.id("txtAccountExecutiveLastName")).sendKeys("Da");
	        		driver.findElement(By.id("txtAccountExecutiveEmail")).sendKeys("sg");
	        		driver.findElement(By.id("txtAccountExecutiveLastName")).click();
	        		Assert.assertTrue((driver.findElement(By.id("errAccountExecutiveEmailAddress")).isDisplayed()));
	        		driver.findElement(By.id("txtAccountExecutiveEmail")).clear();
	        		driver.findElement(By.id("txtAccountExecutiveEmail")).sendKeys("sg@gmail.com");
	        		driver.findElement(By.id("txtlicensedMetLifeAgentSLN")).sendKeys("154");
	        		Assert.assertFalse("Situs State is not disabled", (driver.findElement(By.id("txtAccountExecutiveSitusState")).isEnabled()));
	        		Assert.assertFalse("Signature Date is not disabled", (driver.findElement(By.id("txtlicensedMetLifeAgentDate")).isEnabled()));
	        		driver.findElement(By.id("btnAccountExecutiveUpdate")).click();
	        		Assert.assertFalse("Test Case 7 Failed",(driver.findElement(By.id("errMandField")).isDisplayed()));
	        		System.out.println("Test Case 7 passed");
	        		
	        	//Sales Represnetative Test Cases
	        		//Test Case 8 - check if Sales Represntative Tab is present or not
	        		try{
	        			
	        			Assert.assertTrue((driver.findElement(By.id("salesSpecialist")).isDisplayed()));
	        			
	        			}
	        			catch(Exception e)
	        			{
	        				js.executeScript("arguments[0].click();", driver.findElement(By.id("leftNavsearchCustomer")));
	        				js.executeScript("arguments[0].click();", driver.findElement(By.id("btnleftNavigationNo")));
	        				System.out.println("Test Case 8 passed");
	        			}
	        		
	        			//Test Case 9 - When all attriubutes are empty
	        			driver.findElement(By.id("RFPID")).clear();
	        			driver.findElement(By.id("RFPID")).sendKeys("0063D000007llaMQAQ");
	        			searchOpportunity();
	        		    
	        		    js.executeScript("arguments[0].click();", driver.findElement(By.id("leftNavAdminInfo")));
	        		    js.executeScript("arguments[0].click();", driver.findElement(By.id("breadManageContacts"))); 
	        		    js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSecMgnmtHeaderNo")));
	        			Assert.assertTrue((driver.findElement(By.id("salesSpecialist")).isDisplayed()));
	        			js.executeScript("arguments[0].click();", driver.findElement(By.id("salesSpecialist")));
	        			Assert.assertTrue((driver.findElement(By.id("div_secMgnmtHeaderOverlay")).isDisplayed()));
	        			js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSecMgnmtHeaderYes")));
	        			Thread.sleep(1000);
	        			driver.findElement(By.id("txtSalesSpecialistFirstName")).clear();
	        			driver.findElement(By.id("txtSalesSpecialistLastName")).clear();
	        			driver.findElement(By.id("txtSalesSpecialistEmail")).clear();
	        			Assert.assertTrue((driver.findElement(By.id("btnSaleSpecUpdate")).isDisplayed()));
	        			js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSaleSpecUpdate")));
	        			
	        			Assert.assertTrue((driver.findElement(By.id("errMandField")).isDisplayed()));
	        			System.out.println("Test Case 9 passed");
	        			
	        			//Test Case 10 - when all attributes are filled and update is clicked
	        			driver.findElement(By.id("txtSalesSpecialistFirstName")).sendKeys("Bumba");
	        			driver.findElement(By.id("txtSalesSpecialistLastName")).sendKeys("DA");
	        			driver.findElement(By.id("txtSalesSpecialistEmail")).sendKeys("DA");
	        			driver.findElement(By.id("txtSalesSpecialistLastName")).click();
	        			Assert.assertTrue((driver.findElement(By.id("errSalesSpecialistEmailAddress")).isDisplayed()));
	        			driver.findElement(By.id("txtSalesSpecialistEmail")).clear();
	        			driver.findElement(By.id("txtSalesSpecialistEmail")).sendKeys("sayani@gmail.com");
	        			js.executeScript("arguments[0].click();", driver.findElement(By.id("btnSaleSpecUpdate")));
	        			Thread.sleep(500);
	        			//Assert.assertFalse((driver.findElement(By.id("errMandField")).isDisplayed()));
	        			System.out.println("Test Case 10 passed");
	        			
	        			js.executeScript("arguments[0].click();", driver.findElement(By.id("logoutLink")));
	        			Thread.sleep(500);
        				Assert.assertTrue((driver.findElement(By.id("viewLogoutOverlay")).isDisplayed()));
        				js.executeScript("arguments[0].click();", driver.findElement(By.id("btnlogoutViewYes")));
        				driver.close();
        	
         }
    
    
    	

}
