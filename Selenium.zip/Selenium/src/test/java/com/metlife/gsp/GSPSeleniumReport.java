package com.metlife.gsp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.runner.Result;

public class GSPSeleniumReport {
	   public static void main(String[] args) throws Exception {
		  /* String result=null;
		   GSPSeleniumReport gspSelRep = new GSPSeleniumReport();
		   gspSelRep.gspReportGenerator(result);*/
	   }
	     
	   public static void gspReportGenerator(String result) throws IOException {
		   
 
	      //Create blank workbook
	      XSSFWorkbook workbook = new XSSFWorkbook(); 

	      //Create a blank sheet
	      XSSFSheet spreadsheet = workbook.createSheet("Writesheet");

	      //Create row object
	      XSSFRow row;
	      String loginResult = result;
	      String serachResult = result;
	      //This data needs to be written (Object[])
	      Map < String, Object[] > empinfo = 
	      new TreeMap < String, Object[] >();
	      empinfo.put( "1", new Object[] { "TAB", "USE CASE", "RESULT" });
	      empinfo.put( "2", new Object[] { "ADMIN", "Customer Agreement Settings", loginResult });
	      empinfo.put( "3", new Object[] { "ADMIN", "Manage Commision", serachResult });

	      //Iterate over data and write to sheet
	      Set < String > keyid = empinfo.keySet();
	      int rowid = 0;

	      for (String key : keyid) {
	         row = spreadsheet.createRow(rowid++);
	         Object [] objectArr = empinfo.get(key);
	         int cellid = 0;

	         for (Object obj : objectArr) {
	            Cell cell = row.createCell(cellid++);
	            cell.setCellValue((String)obj);
	         }
	      }

	      //Write the workbook in file system
	      FileOutputStream out = new FileOutputStream(new File("Writesheet.xlsx"));
	      workbook.write(out);
	      out.close();
	      System.out.println("Writesheet.xlsx written successfully");
	   
		   
	   }
}
