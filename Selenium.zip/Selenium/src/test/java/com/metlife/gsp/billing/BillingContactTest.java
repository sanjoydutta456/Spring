package com.metlife.gsp.billing;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;
//import com.metlife.gsp.login.Login_INT;

public class BillingContactTest {

	private WebDriver driver;
	private Login_INT login;
	private boolean iterationFlag;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}

	private void returnToHome(){
		
		WebElement homeEle = driver.findElement(By.className("summary"));
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}
	private void returnToHomeforBroker(){
		WebElement homeEle = driver.findElement(By.className("summary"));
		if(!iterationFlag){
			driver.manage().window().maximize();
			iterationFlag = true;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("scroll(250,0)");
		}
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}
	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MT1");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		
		driver.manage().window().maximize();
		
		WebElement billingContactsLink = driver.findElement(By.id("navDashBillingContacts"));
		if (billingContactsLink.isDisplayed()) {
			billingContactsLink.click();
			//assertTrue(driver.findElement(By.id("divbillingContactContentId")).isDisplayed());
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			}
	
			
		WebElement SameLink = driver.findElement(By.id("rdnCustHQAddressIndicator"));
		SameLink.click();

		
		
		WebElement YesLink = driver.findElement(By.id("rdnCustBillingContactAddressYes"));
		YesLink.click();
		Thread.sleep(1000);
		WebElement txtCustHQAddressLineOne = driver.findElement(By.id("txtCustHQAddressLineOne"));
		/*txtCustHQAddressLineOne.clear();
		txtCustHQAddressLineOne.sendKeys("300 davidson avenue");
		Thread.sleep(500);*/
		//driver.findElement(By.id("txtCustHQAddressLineOne")).sendKeys("300 davidson avenue");
		WebElement txtCustHQAddressLineTwo = driver.findElement(By.id("txtCustHQAddressLineTwo"));
		//txtCustHQAddressLineOne.clear();
		txtCustHQAddressLineOne.sendKeys("sdfh");
		Thread.sleep(500);
		//driver.findElement(By.id("txtCustHQAddressLineTwo")).sendKeys("sdfh");
		WebElement txtCustHQAddressCity = driver.findElement(By.id("txtCustHQAddressCity"));
		//txtCustHQAddressCity.clear();
		txtCustHQAddressCity.sendKeys("SCHENECTADY");
		//driver.findElement(By.id("txtCustHQAddressCity")).sendKeys("SCHENECTADY");
		Thread.sleep(1000);
		Select dropdown = new Select(driver.findElement(By.id("selectCustHQAddressState")));
		dropdown.selectByIndex(2);	 
		
		WebElement txtCustHQAddressZip = driver.findElement(By.id("txtCustHQAddressZip"));
		//txtCustHQAddressZip.clear();
		txtCustHQAddressZip.sendKeys("12345");
		//driver.findElement(By.id("txtCustHQAddressZip")).sendKeys("12345");
		Thread.sleep(1000);
		

		WebElement saveLink = driver.findElement(By.id("btnBillingContactsSave"));
		saveLink.click();
		
		Thread.sleep(4000);
		
		//......................................................................................
		driver.findElement(By.id("rdnCustBillingContactAddressNo")).click();

		Thread.sleep(2000);
		
		
		WebElement txtCustBillingContactAddressFirstName = driver.findElement(By.id("txtCustBillingContactAddressFirstName"));
		txtCustBillingContactAddressFirstName.clear();
		txtCustBillingContactAddressFirstName.sendKeys("X");
		//driver.findElement(By.id("txtCustBillingContactAddressFirstName")).sendKeys("X");
		Thread.sleep(500);
		WebElement txtCustBillingContactAddressLastName = driver.findElement(By.id("txtCustBillingContactAddressLastName"));
		txtCustBillingContactAddressLastName.clear();
		txtCustBillingContactAddressLastName.sendKeys("Y");
		//driver.findElement(By.id("txtCustBillingContactAddressLastName")).sendKeys("Y");
		Thread.sleep(500);
		WebElement txtCustBillingContactAddressEmail = driver.findElement(By.id("txtCustBillingContactAddressEmail"));
		txtCustBillingContactAddressEmail.clear();
		txtCustBillingContactAddressEmail.sendKeys("wsedfgd@cognizant.com");
		//driver.findElement(By.id("txtCustBillingContactAddressEmail")).sendKeys("wsedfgd@cognizant.com");
		Thread.sleep(500);
		WebElement txtCustBillingContactAddressPhoneNumber = driver.findElement(By.id("txtCustBillingContactAddressPhoneNumber"));
		txtCustBillingContactAddressPhoneNumber.clear();
		txtCustBillingContactAddressPhoneNumber.sendKeys("444-444-4675");
		//driver.findElement(By.id("txtCustBillingContactAddressPhoneNumber")).sendKeys("444-444-4675");
		Thread.sleep(500);
		WebElement txtCustBillingContactAddressPhoneNumExtn = driver.findElement(By.id("txtCustBillingContactAddressPhoneNumExtn"));
		txtCustBillingContactAddressPhoneNumExtn.clear();
		txtCustBillingContactAddressPhoneNumExtn.sendKeys("1234567898");
		//driver.findElement(By.id("txtCustBillingContactAddressPhoneNumExtn")).sendKeys("1234567898");

		Thread.sleep(1000);
		

		
		//....................................................................................
	
	 driver.findElement(By.id("btnBillingContactsSave")).click();
		
		//..................................................................................................................
		
		
		//Same as mailing Address?
	 	Thread.sleep(2000);
		 WebElement rdnCustMailAddressIndicator =  driver.findElement(By.xpath("//*[@id=\"rdnCustMailAddressIndicator\"]"));
		 rdnCustMailAddressIndicator.click();
		 //driver.findElement(By.id("rdnCustMailAddressIndicator")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("rdnCustBillingContactAddressYes")).click();
		 
 
		Thread.sleep(500);
		Select down = new Select(driver.findElement(By.id("selectCustMailingAddressLineState"))); 
		down.selectByIndex(2);	
		
		driver.findElement(By.id("txtCustMailingAddressLineZip")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("rdnCustBillingContactAddressNo")).click();
		Thread.sleep(500);
		//txtCustBillingContactAddressFirstName.clear();
		txtCustBillingContactAddressFirstName.sendKeys("X");
		//driver.findElement(By.id("txtCustBillingContactAddressFirstName")).sendKeys("X");
		Thread.sleep(500);
		txtCustBillingContactAddressLastName.clear();
		txtCustBillingContactAddressLastName.sendKeys("Y");
		//driver.findElement(By.id("txtCustBillingContactAddressLastName")).sendKeys("Y");
		Thread.sleep(500);
		txtCustBillingContactAddressEmail.clear();
		txtCustBillingContactAddressEmail.sendKeys("fdfd@cognizant.com");
		//driver.findElement(By.id("txtCustBillingContactAddressEmail")).sendKeys("fdfd@cognizant.com");

		Thread.sleep(500);
		txtCustBillingContactAddressPhoneNumber.clear();
		txtCustBillingContactAddressPhoneNumber.sendKeys("764-568-7864");
		//driver.findElement(By.id("txtCustBillingContactAddressPhoneNumber")).sendKeys("764-568-7864");
		Thread.sleep(500);
		txtCustBillingContactAddressPhoneNumExtn.clear();
		txtCustBillingContactAddressPhoneNumExtn.sendKeys("5798");
		driver.findElement(By.id("txtCustBillingContactAddressPhoneNumExtn")).sendKeys("5798");
		
		Thread.sleep(1000);
		
		driver.findElement(By.id("btnBillingContactsSave")).click();
		

		Thread.sleep(2000);
		
		
		
		
		//....................................................................................
		
	
		//......................................................................................
		
		
		//TPA billed
	
		driver.findElement(By.id("rdnCustTPAAddressIndicator")).click();  
		
		Thread.sleep(2000);
		

			driver.findElement(By.id("rdnCustRemittingPaymentYes")).click();
	
			Thread.sleep(500);
			WebElement txtCustPrimBillInfoTPACompanyName = driver.findElement(By.id("txtCustPrimBillInfoTPACompanyName"));
			txtCustPrimBillInfoTPACompanyName.clear();
			txtCustPrimBillInfoTPACompanyName.sendKeys("catdog");
			//driver.findElement(By.id("txtCustPrimBillInfoTPACompanyName")).sendKeys("catdog");
			Thread.sleep(500);
			WebElement txtCustPrimBillInfoFirstName = driver.findElement(By.id("txtCustPrimBillInfoFirstName"));
			txtCustPrimBillInfoFirstName.clear();
			txtCustPrimBillInfoFirstName.sendKeys("300 davidson avenue");
			//driver.findElement(By.id("txtCustPrimBillInfoFirstName")).sendKeys("300 davidson avenue");
			Thread.sleep(500);
			WebElement txtCustPrimBillInfoLastName = driver.findElement(By.id("txtCustPrimBillInfoLastName"));
			txtCustPrimBillInfoLastName.clear();
			txtCustPrimBillInfoLastName.sendKeys("sdfh");
			//driver.findElement(By.id("txtCustPrimBillInfoLastName")).sendKeys("sdfh");

			Thread.sleep(500);
			WebElement txtCustPrimBillInfoEmailAddress = driver.findElement(By.id("txtCustPrimBillInfoEmailAddress"));
			txtCustPrimBillInfoEmailAddress.clear();
			txtCustPrimBillInfoEmailAddress.sendKeys("SCHENECTADY@cognizant.com");
			//driver.findElement(By.id("txtCustPrimBillInfoEmailAddress")).sendKeys("SCHENECTADY@cognizant.com");
			Thread.sleep(500);
			WebElement txtCustPrimBillContactPhoneNumber = driver.findElement(By.id("txtCustPrimBillContactPhoneNumber"));
			txtCustPrimBillContactPhoneNumber.clear();
			txtCustPrimBillContactPhoneNumber.sendKeys("776-766-8765");
			//driver.findElement(By.id("txtCustPrimBillContactPhoneNumber")).sendKeys("776-766-8765");
			Thread.sleep(500);
			WebElement txtCustPrimBillPhoneNumbeeExtn = driver.findElement(By.id("txtCustPrimBillPhoneNumbeeExtn"));
			txtCustPrimBillPhoneNumbeeExtn.clear();
			txtCustPrimBillPhoneNumbeeExtn.sendKeys("6563");
			//driver.findElement(By.id("txtCustPrimBillPhoneNumbeeExtn")).sendKeys("6563");
			Thread.sleep(500);
			WebElement txtCustPrimaryBillingAddLineOne = driver.findElement(By.id("txtCustPrimaryBillingAddLineOne"));
			txtCustPrimaryBillingAddLineOne.clear();
			txtCustPrimaryBillingAddLineOne.sendKeys("gfg");
			//driver.findElement(By.id("txtCustPrimaryBillingAddLineOne")).sendKeys("gfg");
			Thread.sleep(500);
			WebElement txtCustPrimaryBillingAddLineTwo = driver.findElement(By.id("txtCustPrimaryBillingAddLineTwo"));
			txtCustPrimaryBillingAddLineTwo.clear();
			txtCustPrimaryBillingAddLineTwo.sendKeys("ggfj");
			//driver.findElement(By.id("txtCustPrimaryBillingAddLineTwo")).sendKeys("ggfj");
			Thread.sleep(500);
			WebElement txtCustPrimaryBillingCity = driver.findElement(By.id("txtCustPrimaryBillingCity"));
			txtCustPrimaryBillingCity.clear();
			txtCustPrimaryBillingCity.sendKeys("fbfghhfg");
			//driver.findElement(By.id("txtCustPrimaryBillingCity")).sendKeys("fbfghhfg");
			
			Thread.sleep(500);
			WebElement txtCustPrimaryBillingZipCode = driver.findElement(By.id("txtCustPrimaryBillingZipCode"));
			txtCustPrimaryBillingZipCode.clear();
			txtCustPrimaryBillingZipCode.sendKeys("3546434");
			//driver.findElement(By.id("txtCustPrimaryBillingZipCode")).sendKeys("3546434");
			
			
			Thread.sleep(500);
			Select drop = new Select(driver.findElement(By.id("selectCustPrimaryBillingState")));
			drop.selectByIndex(2);	
			
			Thread.sleep(1000);

			driver.findElement(By.id("txtCustPrimaryBillingZipCode")).click();
		
			
			driver.findElement(By.id("btnBillingContactsSave")).click();
			
			
			
			
			
		Thread.sleep(2000);
		driver.findElement(By.id("rdnCustRemittingPaymentNo")).click();
		
		Thread.sleep(500);
		txtCustPrimBillInfoFirstName.clear();
		txtCustPrimBillInfoFirstName.sendKeys("X");
		//driver.findElement(By.id("txtCustPrimBillInfoFirstName")).sendKeys("X");
		Thread.sleep(500);
		txtCustPrimBillInfoLastName.clear();
		txtCustPrimBillInfoLastName.sendKeys("Y");
		//driver.findElement(By.id("txtCustPrimBillInfoLastName")).sendKeys("Y");
		Thread.sleep(500);
		txtCustPrimBillInfoLastName.clear();
		txtCustPrimBillInfoLastName.sendKeys("wsedfgd@cognizant.com");
		//driver.findElement(By.id("txtCustPrimBillInfoEmailAddress")).clear();
		//driver.findElement(By.id("txtCustPrimBillInfoEmailAddress")).sendKeys("wsedfgd@cognizant.com");
		Thread.sleep(500);
		txtCustPrimBillContactPhoneNumber.clear();
		txtCustPrimBillContactPhoneNumber.sendKeys("444-444-4675");
		//driver.findElement(By.id("txtCustPrimBillContactPhoneNumber")).sendKeys("444-444-4675");
		Thread.sleep(500);
		txtCustPrimBillPhoneNumbeeExtn.clear();
		txtCustPrimBillPhoneNumbeeExtn.sendKeys("1234567898");
		//driver.findElement(By.id("txtCustPrimBillPhoneNumbeeExtn")).sendKeys("1234567898");
		
		Thread.sleep(1000);
		driver.findElement(By.id("btnBillingContactsSave")).click();
		
		Thread.sleep(2000);
		
		//..........................................................................................
		
		
		
	
		
		Select dro = new Select(driver.findElement(By.id("selectContactForSubmitting"))); 
		dro.selectByIndex(3);
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,500)", "");
		
		Thread.sleep(500);
		WebElement txtBillingContactAddressEmail = driver.findElement(By.id("txtBillingContactAddressEmail"));
		txtBillingContactAddressEmail.clear();
		txtBillingContactAddressEmail.sendKeys("catdog");
		//driver.findElement(By.id("txtBillingContactAddressEmail")).clear();
		//driver.findElement(By.id("txtBillingContactFirstName")).sendKeys("catdog"); 	
		Thread.sleep(500);
		txtBillingContactAddressEmail.clear();
		txtBillingContactAddressEmail.sendKeys("davidson");
		//driver.findElement(By.id("txtBillingContactAddressEmail")).clear();
		//driver.findElement(By.id("txtBillingContactLastName")).sendKeys("davidson");
		Thread.sleep(500);
		txtBillingContactAddressEmail.clear();
		txtBillingContactAddressEmail.sendKeys("111-538-7876");
		//driver.findElement(By.id("txtBillingContactAddressEmail")).clear();
		//driver.findElement(By.id("txtBillingContactPhoneNumber")).sendKeys("111-538-7876");
		Thread.sleep(2000);
	
		txtBillingContactAddressEmail.clear();
		txtBillingContactAddressEmail.sendKeys("wsedfgd@cognizant.com");
		//driver.findElement(By.id("txtBillingContactAddressEmail")).clear();
		//driver.findElement(By.id("txtBillingContactAddressEmail")).sendKeys("wsedfgd@cognizant.com");
		Thread.sleep(2000);
		
		//......................................................................................................................
		//itfile
		
		/*js.executeScript("window.scrollBy(0,500)", "");
		driver.findElement(By.id("txtBillingContactFirstName1")).sendKeys("cag"); 	
		Thread.sleep(4000);
		
		driver.findElement(By.id("txtBillingContactLastName1")).sendKeys("davidson");
		Thread.sleep(2000);
		driver.findElement(By.id("txtBillingContactPhoneNumber1")).sendKeys("111-538-7876");
		Thread.sleep(4000);		
		driver.findElement(By.id("txtCustBillingContactAddressPhoneNumExtn1")).sendKeys("7876");
		
		Thread.sleep(4000);	
		driver.findElement(By.id("txtBillingContactAddressEmail1")).sendKeys("jhj@cognizant.com");
		Thread.sleep(4000);	*/
		
		driver.findElement(By.id("btnBillingContactsSave")).click();

		Thread.sleep(6000);
		
		

		try {

			Thread.sleep(500);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			//WebElement logoutLink = driver.findElement(By.id("logoutLink"));
			if(driver.findElement(By.id("logoutLink")).isDisplayed()) {
				js.executeScript("arguments[0].click();",  driver.findElement(By.id("logoutLink")));
				Thread.sleep(500);
			js.executeScript("arguments[0].click();",  driver.findElement(By.id("btnlogoutYes")));
			 
			}
		}catch (Exception e) {}		
		
		
		driver.quit();
	}
	
		
}