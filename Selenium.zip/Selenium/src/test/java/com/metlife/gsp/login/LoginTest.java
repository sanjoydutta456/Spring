package com.metlife.gsp.login;

import java.util.concurrent.TimeUnit;

import javax.naming.TimeLimitExceededException;

import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class LoginTest {

    private WebDriver driver;
    @Before
    public void setUp() {

        // Windows
        //System.setProperty("webdriver.chrome.driver", "../driver/chromedriver.exe");
        // Mac
        //System.setProperty("webdriver.chrome.driver", "../driver/chromedriver");
    	
        System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void loginPage() throws InterruptedException, TimeLimitExceededException, ElementNotFoundException {
        driver.get("https://int.custadmin.metlife.com");
        success();     
              
    }
    public void credential(String url, final String username, final String password) {
    	if(url != null) {
    		driver.get(url);
    	}
        WebElement userID =  driver.findElement(By.id("USER"));
        WebElement pwd = driver.findElement(By.id("PASSWORD"));
        userID.clear();
        pwd.clear();
        userID.sendKeys(username);
        pwd.sendKeys(password);
    }
    
   public void success() throws InterruptedException,ElementNotFoundException,TimeLimitExceededException {
	   Thread.sleep(2000);
	 // Only UserName
       credential(null, "gspcatqauser1","");
       Thread.sleep(2000);
       driver.findElement(By.id("cmdEnter")).click();
       Thread.sleep(2000);
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
       Thread.sleep(2000);
	 // Only Password
       credential(null, "","metlife1");
       Thread.sleep(2000);
       driver.findElement(By.id("cmdEnter")).click(); 
       Thread.sleep(2000);
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
       Thread.sleep(2000); 
     //Right UserName and Right Password
       credential(null, "gspcatqauser1","metlife1");
       Thread.sleep(2000);
       driver.findElement(By.id("cmdEnter")).click();
       Thread.sleep(2000);
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
       Thread.sleep(2000);
     //Logout
       driver.findElement(By.id("logoutLink")).click();
       Thread.sleep(2000);
       driver.findElement(By.id("btnlogoutViewYes")).click();
       Thread.sleep(2000);
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);     
       
       Thread.sleep(2000);
      //Wrong UserName and Wrong Password
        credential("https://int.custadmin.metlife.com", "wronguser","wrongpass");
        Thread.sleep(2000);
        driver.findElement(By.id("cmdEnter")).click();
        Thread.sleep(2000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
        Thread.sleep(2000);
      //Right UserName and Wrong Password
        credential("https://int.custadmin.metlife.com", "gspcatqauser1", "metlife2");
        Thread.sleep(2000);
        driver.findElement(By.id("cmdEnter")).click();
        Thread.sleep(2000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        Thread.sleep(2000);
      //Wrong UserName and Right Password
        credential("https://int.custadmin.metlife.com", "gspcat", "metlife1");
        Thread.sleep(2000);
        driver.findElement(By.id("cmdEnter")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);      
       
    
   }
    

    @After
    public void tearDown() {
       driver.close();
    	
        //driver.findElement(By.id("logoutLink")).click();
    }
}
