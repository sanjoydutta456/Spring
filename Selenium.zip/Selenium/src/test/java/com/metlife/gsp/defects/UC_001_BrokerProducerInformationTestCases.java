package com.metlife.gsp.defects;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class UC_001_BrokerProducerInformationTestCases {

	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    	
    }

public void searchOpportunity() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"editCustomer\"]"))).click();
		
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
        
    	
    	WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
    	driver.findElement(By.id("RFPID")).sendKeys("1-1F5MD2"); 
        searchOpportunity();
    	Thread.sleep(1000);
    	
    	//Defect - 38766 (Test Case 1)--> Check whether the State field is disabled when an opportunity is opened in View mode
    	try{
    		Assert.assertTrue(driver.findElement(By.linkText("Broker Producer Information")).isDisplayed());
    		Thread.sleep(2000);
    		wait.until(ExpectedConditions.elementToBeClickable(By.id("navDashProdInfo"))).click();
    		Thread.sleep(1000);
    		driver.manage().window().maximize();
    		js.executeScript("window.scrollBy(0,250)");
    		//Assert.assertTrue(driver.findElement(By.id("selectBrokerPriAppExistingUserState1")).isDisplayed());
    		
    		if(driver.findElement(By.id("selectBrokerPriAppExistingUserState1")).isEnabled()!= true)
    			System.out.println("Test case 1 passed");
    		else
    			System.out.println("Test Case 1 failed");
    	}
    	catch(Exception e)
    	{
    		wait.until(ExpectedConditions.elementToBeClickable(By.id("leftNavsearchCustomer"))).click();
    		
    	}
    	Thread.sleep(2000);
    	//Defect - 38766 (Test Case 2)--> Check whether the State field is disabled when an opportunity is opened in IN PROGRESS mode
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("leftNavsearchCustomer"))).click();
    	driver.findElement(By.id("RFPID")).clear();
    	Thread.sleep(1000);
    	driver.findElement(By.id("RFPID")).sendKeys("1-4ABSU3"); 
    	searchOpportunity();
    	Thread.sleep(1000);
    	try{
    		Assert.assertTrue(driver.findElement(By.linkText("Broker Producer Information")).isDisplayed());
    		wait.until(ExpectedConditions.elementToBeClickable(By.id("navDashProdInfo"))).click();
    		Thread.sleep(1000);
    		driver.manage().window().maximize();
    		js.executeScript("window.scrollBy(0,250)");
    		//Assert.assertTrue(driver.findElement(By.id("selectBrokerPriAppExistingUserState1")).isDisplayed());
    		
    		if(driver.findElement(By.id("selectBrokerPriAppExistingUserState1")).isEnabled()!= true)
    			System.out.println("Test case 2 failed");
    		else
    			System.out.println("Test Case 2 passed");
    	}
    	catch(Exception e)
    	{
    		wait.until(ExpectedConditions.elementToBeClickable(By.id("leftNavsearchCustomer"))).click();
    		
    	}
    	
    	Thread.sleep(1000);
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("logoutLink"))).click();
    	Thread.sleep(2000);
    	Assert.assertTrue(driver.findElement(By.id("logoutOverlay")).isDisplayed());
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("btnlogoutYes"))).click();
    	driver.quit();
    	
    }
}
