package com.metlife.gsp.classSetup;

import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import com.metlife.gsp.login.Login_INT;

public class ClassSetup_WstdTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    @Test
	public void productSetup()throws Exception
	{
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MS2");
		WebElement submit=driver.findElement(By.id("SearchButtonIntUser"));
		submit.click();
		Thread.sleep(3000);
		WebElement edit=driver.findElement(By.id("editCustomer"));
		edit.click();
		Thread.sleep(1000);
		
		WebElement wstd=driver.findElement(By.id("navDashWstd"));
		wstd.click();
		Thread.sleep(2000);
		
		WebElement replacementcov=driver.findElement(By.id("rdnwstdReplacementCoverageYes"));
		replacementcov.click();
		Thread.sleep(1000);
		
		WebElement newenrollment=driver.findElement(By.id("rdnwstdEnrollmentDesiredYes"));
		newenrollment.click();
		Thread.sleep(1000);
		
		WebElement states=driver.findElement(By.id("chkContractState22"));
		states.click();
		Thread.sleep(1000);
		
		WebElement tollfreenum=driver.findElement(By.id("txtTollFreeNumber"));
		tollfreenum.sendKeys("03325678901");
		Thread.sleep(1000);
		
		WebElement disability=driver.findElement(By.id("rdnWstdRetainLiabilityYes"));
		disability.click();
		Thread.sleep(1000);
		
		WebElement spd=driver.findElement(By.id("txtStatusOfSPD"));
		spd.sendKeys("current copy of SPD or PD is needed");
		Thread.sleep(1000);
		
		WebElement ficaexempt=driver.findElement(By.id("rdnWstdFicaExemptYes"));
		ficaexempt.click();
		Thread.sleep(1000);
		
		Select scenarios=new Select(driver.findElement(By.id("selectFicaExempt")));
		scenarios.selectByIndex(2);
		Thread.sleep(1000);
		
		WebElement taxeob=driver.findElement(By.id("txtClaimReports"));
		taxeob.sendKeys("Tax EOB required");
		Thread.sleep(1000);
		
		Select reemittingemp=new Select(driver.findElement(By.id("selectShareOfFica")));
		reemittingemp.selectByIndex(2);
		Thread.sleep(1000);
		
		WebElement metlifeintake=driver.findElement(By.id("chkMetlifeIntake"));
		metlifeintake.click();
		Thread.sleep(1000);
		
		WebElement empbenefits=driver.findElement(By.id("chkMyBenefits"));
		empbenefits.click();
		Thread.sleep(1000);
		
		WebElement paperclaimform=driver.findElement(By.id("chkPaperClaimForm"));
		paperclaimform.click();
		Thread.sleep(1000);
		
		WebElement telephonicintake=driver.findElement(By.id("chkTelephonicIntake"));
		telephonicintake.click();
		Thread.sleep(1000);
		
		WebElement contactingmetlife=driver.findElement(By.id("txtAdditionalName"));
		contactingmetlife.sendKeys("Ways of contacting employees");
		Thread.sleep(1000);
		
		WebElement telephonicintake1=driver.findElement(By.id("rdnWstdPostScriptingYes"));
		telephonicintake1.click();
		Thread.sleep(1000);
		
		WebElement telephonicintake1text=driver.findElement(By.id("txtPostScriptingYes"));
		telephonicintake1text.sendKeys("add essential details");
		Thread.sleep(1000);
		
		WebElement indicateeob=driver.findElement(By.id("rdnWstdCopiesOfEOBYes"));
		indicateeob.click();
		Thread.sleep(1000);
		
		WebElement contactname=driver.findElement(By.id("txtReceiveEOBName1"));
		contactname.sendKeys("Aniket Das");
		Thread.sleep(1000);
		
		WebElement contactaddress=driver.findElement(By.id("txtReceiveEOBAddress1"));
		contactaddress.sendKeys("Thakurpukur");
		Thread.sleep(1000);
		
		WebElement contactfax=driver.findElement(By.id("txtReceiveEOBNum"));
		contactfax.sendKeys("0987654321");
		Thread.sleep(1000);
		
		WebElement viasecuremail=driver.findElement(By.id("rdnWstdSecureEmail"));
		viasecuremail.click();
		Thread.sleep(1000);
		
		WebElement viasecuremailtext=driver.findElement(By.id("txtWstdSecureEmail"));
		viasecuremailtext.sendKeys("Provide secure mail");
		Thread.sleep(1000);
		
		WebElement viatelephone=driver.findElement(By.id("rdnWstdPhone"));
		viatelephone.click();
		Thread.sleep(1000);
		
		WebElement viatelephonetext=driver.findElement(By.id("txtWstdSecurePhone"));
		viatelephonetext.sendKeys("9087654321");
		Thread.sleep(1000);
		
		WebElement other=driver.findElement(By.id("rdnWstdOther"));
		other.click();
		Thread.sleep(1000);
		
		WebElement othertext=driver.findElement(By.id("txtWstdClaimOther"));
		othertext.sendKeys("Provide other claims");
		Thread.sleep(1000);
		
		WebElement offsetcoordination=driver.findElement(By.id("rdnWstdOffsetYes"));
		offsetcoordination.click();
		Thread.sleep(1000);
		
		WebElement offsetcoordinationtext=driver.findElement(By.id("txtRetirementProgramYes"));
		offsetcoordinationtext.sendKeys("Offset coordination text");
		Thread.sleep(1000);
		
		WebElement appealsprocess=driver.findElement(By.id("rdnWstdMetlife"));
		appealsprocess.click();
		Thread.sleep(1000);
		
		WebElement levelsappeal=driver.findElement(By.id("txtLevelsOfAppeal"));
		levelsappeal.sendKeys("Levels of appeal");
		Thread.sleep(1000);
		
		WebElement handlessappeal=driver.findElement(By.id("txtHandlesAppeal"));
		handlessappeal.sendKeys("state who handles appeal");
		Thread.sleep(1000);
		
		WebElement levelssappealreqd=driver.findElement(By.id("txtRequiredAppeal"));
		levelssappealreqd.sendKeys("state true or false");
		Thread.sleep(1000);
		
		WebElement submitappeal=driver.findElement(By.id("txtSubmitAppeal"));
		submitappeal.sendKeys("please submit appeals");
		Thread.sleep(1000);
		
		WebElement makedecision=driver.findElement(By.id("txtClaimDecision"));
		makedecision.sendKeys("make required decisions");
		Thread.sleep(1000);
		
		WebElement claimadministration=driver.findElement(By.id("rdnWstdJobDescriptionYes"));
		claimadministration.click();
		Thread.sleep(1000);
		
		WebElement contactfname=driver.findElement(By.id("txtJobDescriptionFirstPayment"));
		contactfname.sendKeys("Aniket");
		Thread.sleep(1000);
		
		WebElement contactlname=driver.findElement(By.id("txtJobDescriptionLastClaimPayment"));
		contactlname.sendKeys("Das");
		Thread.sleep(1000);
		
		WebElement contactaddress1=driver.findElement(By.id("txtJobDescriptionAdd1Payment"));
		contactaddress1.sendKeys("Kolkata");
		Thread.sleep(1000);
		
		WebElement contactaddress2=driver.findElement(By.id("txtJobDescriptionAdd2Payment"));
		contactaddress2.sendKeys("WestBengal");
		Thread.sleep(1000);
		
		WebElement contactphnumber=driver.findElement(By.id("txtJobDescriptionNumberPayment"));
		contactphnumber.sendKeys("9876543210");
		Thread.sleep(1000);
		
		WebElement contactfaxnumber=driver.findElement(By.id("txtJobDescriptionFaxPayment"));
		contactfaxnumber.sendKeys("301200");
		Thread.sleep(1000);
		
		Select fmlperiod=new Select(driver.findElement(By.id("selectTerminateEmployee")));
		fmlperiod.selectByIndex(2);
		Thread.sleep(1000);
		
		WebElement otherthanfmla=driver.findElement(By.id("rdnWstdLeaveProgramYes"));
		otherthanfmla.click();
		Thread.sleep(1000);
		
		WebElement otherthanfmlatext=driver.findElement(By.id("txtWstdLeaveProgram"));
		otherthanfmlatext.sendKeys("provide FMLA");
		Thread.sleep(1000);
		
		WebElement cba=driver.findElement(By.id("rdnWstdCollectiveBargainingAgreementYes"));
		cba.click();
		Thread.sleep(1000);
		
		WebElement nomodifiedduty=driver.findElement(By.id("chkWstdReturnToWorkNo"));
		nomodifiedduty.click();
		Thread.sleep(2000);
		
		WebElement nomodifieddutytext=driver.findElement(By.id("txtReturnToWorkNo"));
		nomodifieddutytext.sendKeys("No modified duty");
		Thread.sleep(1000);
		
		WebElement somemodifiedduty=driver.findElement(By.id("chkWstdReturnToWorkSome"));
		somemodifiedduty.click();
		Thread.sleep(1000);
		
		WebElement somemodifieddutytext=driver.findElement(By.id("txtReturnToWorkSome"));
		somemodifieddutytext.sendKeys("Some modified duty");
		Thread.sleep(1000);
		
		WebElement yesallow=driver.findElement(By.id("chkWstdReturnToWorkYes"));
		yesallow.click();
		Thread.sleep(1000);
		
		WebElement yes=driver.findElement(By.id("rdnWstdOnlineMedicalStaffYes"));
		yes.click();
		Thread.sleep(1000);
		
		WebElement contactname1=driver.findElement(By.id("txtReceiveEOBName"));
		contactname1.sendKeys("Aniket Das");
		Thread.sleep(1000);
		
		WebElement contactaddres1=driver.findElement(By.id("txtReceiveEOBAddress"));
		contactaddres1.sendKeys("Thakurpukur");
		Thread.sleep(1000);
		
		WebElement contactph1=driver.findElement(By.id("txtReceiveEOBNumber"));
		contactph1.sendKeys("0987654321");
		Thread.sleep(1000);
		
		WebElement etstates=driver.findElement(By.id("chkETState22"));
		etstates.click();
		Thread.sleep(1000);
		
		WebElement save=driver.findElement(By.id("btnWstdSave"));
		save.click();
		Thread.sleep(2000);
		
		WebElement lgout=driver.findElement(By.id("logoutLink"));
		lgout.click();
		Thread.sleep(1000);
		
		WebElement logOutBtnn=driver.findElement(By.id("btnlogoutYes"));
		logOutBtnn.click();
		Thread.sleep(1000);
		
		driver.quit();
		
		
		
	}

    

}
