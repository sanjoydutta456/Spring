package com.metlife.gsp.admin.caseHistory;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class CaseHistoryTest {

	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    
  
    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
        
       
       JavascriptExecutor js = (JavascriptExecutor)driver; 
       driver.findElement(By.id("RFPID")).sendKeys("1-1F5MT2"); 
       driver.findElement(By.id("SearchButtonIntUser")).click();
       driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
       driver.findElement(By.id("editCustomer")).click();
       driver.findElement(By.id("leftNavAdminInfo")).click();
       driver.manage().window().maximize();
       driver.findElement(By.id("breadCaseHistory")).click();
       Thread.sleep(1000);
       driver.findElement(By.id("btnSecMgnmtHeaderYes")).click();
       Thread.sleep(2000);
       js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"btnReturnToDashboardCaseStatus\"]")));
       Thread.sleep(2000);
  	   js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"logoutLink\"]")));
  	   Thread.sleep(2000);
  	   js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"btnlogoutYes\"]")));
       
       driver.close();
    }

  
}
