package com.metlife.gsp.admin.manageOpportunity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import javax.naming.TimeLimitExceededException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.net.UrlChecker.TimeoutException;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;


public class ManageCommisionTest {

	private static WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();   
  
    }

    @Test
    public void manageCommisionPage() throws NoSuchElementException,ElementNotFoundException,TimeLimitExceededException,ElementNotVisibleException,AssertionError,TimeoutException, InterruptedException{
    		
/*    	driver.findElement(By.id("RFPID")).sendKeys("0065D000007tSCvQAM ");
    	driver.findElement(By.id("SearchButtonIntUser")).click();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	driver.findElement(By.id("editCustomer")).click();
    	driver.findElement(By.id("leftNavAdminInfo")).click(); 
    	driver.manage().window().maximize();
    	driver.findElement(By.id("breadUpdateCommission")).click();
    	driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
    	
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	Select drpLife_0 = new Select(driver.findElement(By.id("selectUpdateCommCI0")));
    	drpLife_0.selectByIndex(0);
    	drpLife_0.selectByIndex(1);
    	drpLife_0.selectByIndex(3);
    	drpLife_0.selectByIndex(4);
    	
    	WebElement rdnGACvgContribYes = driver.findElement(By.id("CICoverageContribution241"));
    	WebElement rdnGACvgContribNo  = driver.findElement(By.id("CICoverageNonContribution241"));
    	rdnGACvgContribYes.click();
    	rdnGACvgContribNo.click();
    	driver.findElement(By.id("btnUpdateCommission")).click();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//*[@id=\"btnReturnToDashboardUpdateComm\"]")).click();
 */   	JavascriptExecutor js = (JavascriptExecutor) driver;
 		driver.manage().window().maximize();
    	driver.findElement(By.id("RFPID")).sendKeys("0061100000DVvsdAAD");
    	driver.findElement(By.id("SearchButtonIntUser")).click();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	driver.findElement(By.id("editCustomer")).click();
    	driver.findElement(By.id("leftNavAdminInfo")).click(); 
    	Thread.sleep(2000);
    	driver.findElement(By.id("breadUpdateCommission")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
    	Thread.sleep(2000);
    	
    	Select drpLife_0 = new Select(driver.findElement(By.id("selectUpdateCommLife0")));
    	WebElement txtLife_0 = driver.findElement(By.id("errtxtManageCommPercentLife0"));
    	drpLife_0.selectByIndex(0);
    	drpLife_0.selectByIndex(1); 
    	drpLife_0.selectByIndex(2);
    	drpLife_0.selectByIndex(3);
    	drpLife_0.selectByIndex(4);
   	
    	// Buy Up Life with AD&D Dropdown
    	//myWaitVar.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\\\"selectUpdateCommLife2\\\"]")));
    	Select drpLife_2 = new Select(driver.findElement(By.id("selectUpdateCommLife2")));
    	drpLife_2.selectByIndex(0);
    	drpLife_2.selectByIndex(1);
    	drpLife_2.selectByIndex(2);
    	drpLife_2.selectByIndex(3);
    	drpLife_2.selectByIndex(4);
    	
    	
    	// Legal Services (MetLaw) Dropdown
    	Select drpHyatt_0 = new Select(driver.findElement(By.id("selectUpdateCommHyatt0")));
    	drpHyatt_0.selectByIndex(0);
    	drpHyatt_0.selectByIndex(1);
    	drpHyatt_0.selectByIndex(2);
    	drpHyatt_0.selectByIndex(3);
    	drpHyatt_0.selectByIndex(4);
    	
    	// CI Attained Age Dropdown
    	Select drpCI_0 = new Select(driver.findElement(By.id("selectUpdateCommCI0")));
    	drpCI_0.selectByIndex(0);
    	drpCI_0.selectByIndex(1);
    	drpCI_0.selectByIndex(2);
    	drpCI_0.selectByIndex(3);
    	drpCI_0.selectByIndex(4);
    	
    	// CI Issue Age Dropdown
    	Select drpCI_1 = new Select(driver.findElement(By.id("selectUpdateCommCI1")));
    	drpCI_1.selectByIndex(0);
    	drpCI_1.selectByIndex(1);
    	drpCI_1.selectByIndex(2);
    	drpCI_1.selectByIndex(3);
    	drpCI_1.selectByIndex(4);
    	
    	// CI Cancer Issue Age Dropdown
    	Select drpCI_2 = new Select(driver.findElement(By.id("selectUpdateCommCI2")));
    	drpCI_2.selectByIndex(0);
    	drpCI_2.selectByIndex(1);
    	drpCI_2.selectByIndex(2);
    	drpCI_2.selectByIndex(3);
    	drpCI_2.selectByIndex(4);
    	
    	// Property & Casualty Dropdown
    	Select drpPnC_0 = new Select(driver.findElement(By.id("selectUpdateCommPC0")));
    	drpPnC_0.selectByIndex(0);
    	drpPnC_0.selectByIndex(1);
    	drpPnC_0.selectByIndex(2);
    	drpPnC_0.selectByIndex(3);
    	drpPnC_0.selectByIndex(4);
    	
    	// Hospital Indemnity Dropdown
    	Select drpHI_0 = new Select(driver.findElement(By.id("selectUpdateCommHI0")));
    	drpHI_0.selectByIndex(0);
    	drpHI_0.selectByIndex(1);
    	drpHI_0.selectByIndex(2);
    	drpHI_0.selectByIndex(3);
    	drpHI_0.selectByIndex(4);   
    	
    	// Group Accident Dropdown
    	Select drpGA_0 = new Select(driver.findElement(By.id("selectUpdateCommGroupAcc0")));
    	drpGA_0.selectByIndex(0);
    	drpGA_0.selectByIndex(1);
    	drpGA_0.selectByIndex(2);
    	drpGA_0.selectByIndex(3);
    	drpGA_0.selectByIndex(4);
    	
    	// Dental Dropdown
    	Select drpDental_1 = new Select(driver.findElement(By.id("selectUpdateCommDental1")));
    	drpDental_1.selectByIndex(0);
    	drpDental_1.selectByIndex(1);
    	drpDental_1.selectByIndex(2);
    	drpDental_1.selectByIndex(3);
    	drpDental_1.selectByIndex(4);
    	
    	// Vision Dropdown
    	Select drpVision_0 = new Select(driver.findElement(By.id("selectUpdateCommVision0")));
    	drpVision_0.selectByIndex(0);
    	drpVision_0.selectByIndex(1);
    	drpVision_0.selectByIndex(2);
    	drpVision_0.selectByIndex(3);
    	drpVision_0.selectByIndex(4);
    	
    	// LTD Dropdown
    	Select drpLTD_0 = new Select(driver.findElement(By.id("selectUpdateCommDisability0")));
    	drpLTD_0.selectByIndex(0);
    	drpLTD_0.selectByIndex(1);
    	drpLTD_0.selectByIndex(2);
    	drpLTD_0.selectByIndex(3);
    	drpLTD_0.selectByIndex(4);
    	
    	// STD Dropdown
    	Select drpSTD_0 = new Select(driver.findElement(By.id("selectUpdateCommDisability1")));
    	drpSTD_0.selectByIndex(0);
    	drpSTD_0.selectByIndex(1);
    	drpSTD_0.selectByIndex(2);
    	drpSTD_0.selectByIndex(3);
    	drpSTD_0.selectByIndex(4);
    	
    	// WSTD Dropdown
    	Select WSTD_0 = new Select(driver.findElement(By.id("selectUpdateCommDisability0")));
    	WSTD_0.selectByIndex(0);
    	WSTD_0.selectByIndex(1);
    	WSTD_0.selectByIndex(2);
    	WSTD_0.selectByIndex(3);
    	WSTD_0.selectByIndex(4);
    	
    	// Group Accident Radio Button Questions
    	WebElement rdnGACvgContribYes = driver.findElement(By.id("GACoverageContribution406000"));
    	WebElement rdnGACvgContribNo  = driver.findElement(By.id("GACoverageContribution406000"));
    	rdnGACvgContribYes.click();
    	rdnGACvgContribNo.click();
    	WebElement rdnGASicknessCvgYes = driver.findElement(By.id("GASickCoverageAnsYes406000"));
    	WebElement rdnGASicknessCvgNo  = driver.findElement(By.id("GASickCoverageAnsNo406000"));
    	rdnGASicknessCvgYes.click();
    	rdnGASicknessCvgNo.click();
    	
    	// Hospital Indemnity Radio Button Questions
    	driver.findElement(By.id("HICoverageContribution406001")).click();;
    	driver.findElement(By.id("HICoverageNonContribution406001")).click();;
    	
    	// Critical Illness Radio Button Questions
    	WebElement rdnCICvgContribYes = driver.findElement(By.id("CICoverageContribution241"));
    	WebElement rdnCICvgContribNo  = driver.findElement(By.id("CICoverageNonContribution241"));
    	rdnCICvgContribYes.click();
    	rdnCICvgContribNo.click();
    	
    	WebElement rdnCIIssueCvgYes = driver.findElement(By.id("CICoverageContribution242"));
    	WebElement rdnCIIssueCvgNo  = driver.findElement(By.id("CICoverageNonContribution242"));
    	rdnCIIssueCvgYes.click();
    	rdnCIIssueCvgNo.click();
    	
    	WebElement rdnCICancerCvgContribYes = driver.findElement(By.id("CICoverageContribution243"));
    	WebElement rdnCICancerCvgContribNo  = driver.findElement(By.id("CICoverageNonContribution243"));
    	rdnCICancerCvgContribYes.click();
    	rdnCICancerCvgContribNo.click();
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnUpdateCommission")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.id("btnReturnToDashboardUpdateComm")).click();

    }
    
	@AfterClass
	public static void after() throws InterruptedException {
		Thread.sleep(2000);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.close();
	}
    
}
