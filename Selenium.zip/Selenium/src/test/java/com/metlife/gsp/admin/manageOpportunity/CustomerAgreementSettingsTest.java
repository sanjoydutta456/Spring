package com.metlife.gsp.admin.manageOpportunity;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.metlife.gsp.login.Login_DEV;

public class CustomerAgreementSettingsTest {
	
	private static WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

 @Test
 public void CustomerAgreementPage() throws InterruptedException {
	 fail();
	 /*
	JavascriptExecutor js = (JavascriptExecutor) driver;
	driver.manage().window().maximize();
	driver.findElement(By.id("RFPID")).sendKeys("0061100000DVvsdAAD");
 	driver.findElement(By.id("SearchButtonIntUser")).click();
 	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
 	driver.findElement(By.id("editCustomer")).click();
 	driver.findElement(By.id("leftNavAdminInfo")).click();
 	Thread.sleep(2000);
 	driver.findElement(By.id("breadUpdateCommission")).click();
 	Thread.sleep(2000);
 	driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
 	driver.findElement(By.id("enrollmentCreditsTab")).click();
 	driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
	WebElement rdnEnrollmentCreditsYes = driver.findElement(By.id("rdnEnrollmentCreditsYes"));
	WebElement rdnEnrollmentCreditsNo  = driver.findElement(By.id("rdnEnrollmentCreditsNo"));
	rdnEnrollmentCreditsYes.click();
	rdnEnrollmentCreditsNo.click();
	WebElement rdnExchangeInformationYes = driver.findElement(By.id("rdnExchangeInformationYes"));
	WebElement rdnExchangeInformationNo  = driver.findElement(By.id("rdnExchangeInformationNo"));
	rdnExchangeInformationYes.click();
	rdnExchangeInformationNo.click();
	driver.findElement(By.id("btnEnrollmentCredits")).click();
 	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
 	Thread.sleep(2000);
	driver.findElement(By.id("btnReturnToDashboardEnrCred")).click();
	
 */}

/*	@AfterClass
	public static void after() throws InterruptedException {
	 Thread.sleep(2000);
     WebElement logOut = driver.findElement(By.id("logoutLink"));
     logOut.click();
     Thread.sleep(1000);
     WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
     yesButton.click();
     Thread.sleep(1000);
     driver.close();
	}*/
}
