package com.metlife.gsp.products;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class GroupAccidentTest {

	private WebDriver driver;
	private Login_INT login;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}

	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException,
			InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MS2");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();

		driver.manage().window().maximize();

		// Group Accident
		WebElement GroupLink = driver.findElement(By.id("navDashGroupAcc"));
		if (GroupLink.isDisplayed()) {
			GroupLink.click();
			assertTrue(driver.findElement(By.id("divProductGroupAccidentId")).isDisplayed());
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}

		/* for SM(35)
		
		driver.findElement(By.id("rdnGrpAcdntIsthisReplacCovNo")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntIsthisReplacCovYes")).click();
		Thread.sleep(500);
		driver.findElement(By.id("effGrpAcdntGroupAccidentCal")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("/html/body/div[3]/div/div[3]/ul[2]/li[5]/div")).click();
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntPaymentAmount0")).clear();
		driver.findElement(By.id("txtGrpAcdntPaymentAmount0")).sendKeys("4000");
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntExpatriatesNo")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntExpatriatesYes")).click();
		Thread.sleep(500);
		driver.findElement(By.id("chkGrpAcdntLifeEventsOT")).click();
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntQualifyingOther")).clear();
		driver.findElement(By.id("txtGrpAcdntQualifyingOther")).sendKeys("ABCDEFGH");
		js.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(500);

		Select status = new Select(driver.findElement(By.id("selectErisaStatusGA")));
		status.selectByIndex(4);

		driver.findElement(By.id("rdnGrpAcdntErisaWrapperNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntErisaWrapperYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntPremiumTaxPost")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntPremiumTaxPre")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("btnGrpAcdntSave")).click();
		Thread.sleep(4000);
		
		WebElement logOut = driver.findElement(By.id("logoutLink"));
		logOut.click();
		Thread.sleep(1000);
		WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
		yesButton.click();
		Thread.sleep(1000);
		driver.quit();
		
		*/
		
		//for GT1000(1035)
		
		driver.findElement(By.id("rdnGrpAcdntIsthisReplacCovNo")).click(); 
		Thread.sleep(500);
			
		driver.findElement(By.id("rdnGrpAcdntIsthisReplacCovYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntRetireesCoveredNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntRetireesCoveredYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntExpatriatesNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntExpatriatesYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntDeathBenefitsNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntDeathBenefitsYes")).click();
		Thread.sleep(500);
		
		
		
		/*
		driver.findElement(By.id("chkCILifeEventsAB")).click();
		Thread.sleep(500);
		driver.findElement(By.id("chkCILifeEventsMD")).click();
		Thread.sleep(500);
		driver.findElement(By.id("chkCILifeEventsDT")).click();
		Thread.sleep(500);*/
		
		
		WebElement others = driver.findElement(By.id("chkGrpAcdntLifeEventsOT"));
		if(others.isDisplayed()) {
			others.click();
			driver.findElement(By.id("txtGrpAcdntQualifyingOther")).clear();
			driver.findElement(By.id("txtGrpAcdntQualifyingOther")).sendKeys("No");
			Thread.sleep(500);
		}
		Thread.sleep(500);
		
		
		
		js.executeScript("window.scrollBy(0,500)", "");
		
		Select status = new Select(driver.findElement(By.id("selectErisaStatusGA")));
		status.selectByIndex(4);
		
		driver.findElement(By.id("rdnGrpAcdntErisaWrapperNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntErisaWrapperYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntPremiumTaxPost")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntPremiumTaxPre")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntEnrollmentFirmNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntEnrollmentFirmYes")).click();
		Thread.sleep(500);
		
		js.executeScript("window.scrollBy(0,400)", "");
		
		driver.findElement(By.id("rdnGrpAcdntEnrollmentOnBallot")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEnrollmentCallCenter")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEnrollmentOnSite")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEnrollmentOther")).click();
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntOtherStrategy")).click();
		driver.findElement(By.id("txtGrpAcdntOtherStrategy")).sendKeys("YYY");
		Thread.sleep(500);
		
		
		driver.findElement(By.id("rdnGrpAcdntOnGoingEnrollmentYes")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntOnGoingEnrollmentNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("txtGrpAcdntManagingNewHires")).clear();
		driver.findElement(By.id("txtGrpAcdntManagingNewHires")).sendKeys("HHH");
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntAnnualEnrollmentNo")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnGrpAcdntAnnualEnrollmentYes")).click();
		Thread.sleep(500);
		
		
		driver.findElement(By.id("rdnGrpAcdntEmployeeCustomer")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEmployeeTPA")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEmployeeBroker")).click();
		Thread.sleep(500);
		driver.findElement(By.id("rdnGrpAcdntEmployeeOther")).click();
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntOtherEmployee")).clear();
		driver.findElement(By.id("txtGrpAcdntOtherEmployee")).sendKeys("EEE");
		Thread.sleep(500);
		
		driver.findElement(By.id("txtGrpAcdntCompanyName")).clear();
		driver.findElement(By.id("txtGrpAcdntCompanyName")).sendKeys("CTS");
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntContactFirstName")).clear();;
		driver.findElement(By.id("txtGrpAcdntContactFirstName")).sendKeys("Arka");;
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntContactLastName")).clear();;
		driver.findElement(By.id("txtGrpAcdntContactLastName")).sendKeys("Das");
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntContactPhoneNumber")).clear();;
		driver.findElement(By.id("txtGrpAcdntContactPhoneNumber")).sendKeys("9123677758");
		Thread.sleep(500);
		driver.findElement(By.id("txtGrpAcdntContactEmailAddress")).clear();;
		driver.findElement(By.id("txtGrpAcdntContactEmailAddress")).sendKeys("A.Das2@cognizant.com");
		Thread.sleep(500);
		//Select dateAge = new Select(driver.findElement(By.id("selectStepRateCalculation")));
		//dateAge.selectByIndex(2);
		
		driver.findElement(By.id("btnGrpAcdntSave")).click();
		Thread.sleep(4000);
		
		WebElement logOut = driver.findElement(By.id("logoutLink"));
		logOut.click();
		Thread.sleep(1000);
		WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
		yesButton.click();
		Thread.sleep(1000);
		driver.quit();
		
		
		
	}

}
