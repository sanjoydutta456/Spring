package com.metlife.gsp.products;

import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.metlife.gsp.login.Login_INT;

public class GeneralProductInformationTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void testGeneralProductInformation() throws InterruptedException{
    	driver.manage().window().maximize();
    	WebElement caseID =driver.findElement(By.id("RFPID"));
        Thread.sleep(2000);
        caseID.sendKeys("1-1F5MT1");
        Thread.sleep(1000);
        WebElement search =driver.findElement(By.id("SearchButtonIntUser"));
        search.click();
        Thread.sleep(3000);
        WebElement edit =driver.findElement(By.id("editCustomer"));
        edit.click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,800)");
        Thread.sleep(1000);
        WebElement genProdInfo = driver.findElement(By.id("navDashGeneralProductInfo"));
        genProdInfo.click();
        Thread.sleep(3000);
        WebElement selectDiffCerificate = driver.findElement(By.id("selectDifferentCertificates"));
        selectDiffCerificate.click();
        Select dropdown = new Select(driver.findElement(By.id("selectDifferentCertificates")));
        for(int i=1;i<=2;i++)
        {
        	dropdown.selectByIndex(i);
        	Thread.sleep(1000);
        }
        dropdown.selectByIndex(3);
        Thread.sleep(1000);
        WebElement otherTextBox = driver.findElement(By.id("divGenTextBox"));
        if(otherTextBox.isDisplayed()==true)
        {
        	System.out.println("New textbox is created for Other");
        }
        else if(otherTextBox.isDisplayed()==false)
        {
        	System.out.println("New textbox is not created for Other");
        }
        Thread.sleep(1000);
//        otherTextBox.sendKeys("Test");
//        Thread.sleep(1000);
//        WebElement compDivName = driver.findElement(By.id("txtExplainAdditionalComp"));
//        compDivName.sendKeys("Test");
        WebElement domesticPartTypeQues = driver.findElement(By.id("divDomesticPartTypes"));
        WebElement designateDomesticEligibility = driver.findElement(By.id("divGrpProdLevel"));
        Thread.sleep(1000);
        WebElement noRadioDomesticPartner = driver.findElement(By.id("rdnDomesticPartNo"));
        noRadioDomesticPartner.click();
        Thread.sleep(1000);
        if(domesticPartTypeQues.isDisplayed()==true && designateDomesticEligibility.isDisplayed()==true)
        {
        		System.out.println("Both the questions are getting displayed after clicking on No");
        	
        }
        else if(domesticPartTypeQues.isDisplayed()==false && designateDomesticEligibility.isDisplayed()==false)
        {
        	System.out.println("None of the questions are getting displayed after clicking on No");
        }
        else
        {
        	System.out.println("Third condition after clicking on No");
        }
        Thread.sleep(1000);
        
        WebElement yesRadioDomesticPartner = driver.findElement(By.id("rdnDomesticPartYes"));
        yesRadioDomesticPartner.click();
        Thread.sleep(1000);
        if(domesticPartTypeQues.isDisplayed()==true && designateDomesticEligibility.isDisplayed()==true)
        {
        		System.out.println("Both the questions are getting displayed after clicking on Yes");
        	
        }
        else if(domesticPartTypeQues.isDisplayed()==false && designateDomesticEligibility.isDisplayed()==false)
        {
        	System.out.println("None of the questions are getting displayed after clicking on Yes");
        }
        else
        {
        	System.out.println("Third condition after clicking on Yes");
        }
        Thread.sleep(1000);
        WebElement definitionNonStandardDiv = driver.findElement(By.id("divNonStd"));
        WebElement radioSameSex = driver.findElement(By.id("rdnDomesticPartTypesSame"));
        WebElement radioOppSex = driver.findElement(By.id("rdnDomesticPartTypesOpp"));
        WebElement radioBoth = driver.findElement(By.id("rdnDomesticPartTypesNo"));
        radioSameSex.click();
        if(definitionNonStandardDiv.isDisplayed()==true)
        {
        	System.out.println("Description textbox is getting displayed after clicking on Same Sex partners only");
        }
        else if(definitionNonStandardDiv.isDisplayed()==false)
        {
        	System.out.println("Description textbox is not getting displayed after clicking on Same Sex partners only");
        }
        Thread.sleep(1000);
        radioOppSex.click();
        if(definitionNonStandardDiv.isDisplayed()==true)
        {
        	System.out.println("Description textbox is getting displayed after clicking on Opposite- Sex partners only");
        }
        else if(definitionNonStandardDiv.isDisplayed()==false)
        {
        	System.out.println("Description textbox is not getting displayed after clicking on Opposite- Sex partners only");
        }
        Thread.sleep(1000);
        radioBoth.click();
        if(definitionNonStandardDiv.isDisplayed()==true)
        {
        	System.out.println("Description textbox is getting displayed after clicking on Both");
        }
        else if(definitionNonStandardDiv.isDisplayed()==false)
        {
        	System.out.println("Description textbox is not getting displayed after clicking on Both");
        }
        Thread.sleep(1000);
        WebElement radioGroup = driver.findElement(By.id("rdnGrpLevel"));
        WebElement radioProduct = driver.findElement(By.id("rdnProdLevel"));
        radioGroup.click();
        Thread.sleep(1000);
        radioProduct.click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,700)");
        Thread.sleep(1000);
        WebElement radioYesSubjectToERISA = driver.findElement(By.id("rdnPolicyHolderCovSubToErisaYes"));
        WebElement radioNoSubjectToERISA = driver.findElement(By.id("rdnPolicyHolderCovSubToErisaNo"));
        radioYesSubjectToERISA.click();
        WebElement planYearEndsDiv = driver.findElement(By.id("divErisaDetails"));
        if(planYearEndsDiv.isDisplayed()==true)
        {
        	System.out.println("Plan Year Ends oprions are coming after clicking on Yes");
        }
        else if(planYearEndsDiv.isDisplayed()==false)
        {
        	System.out.println("Plan Year Ends oprions are not coming after clicking on Yes");
        }
        Thread.sleep(1000);
        radioNoSubjectToERISA.click();
        if(planYearEndsDiv.isDisplayed()==true)
        {
        	System.out.println("Plan Year Ends oprions are coming after clicking on No");
        }
        else if(planYearEndsDiv.isDisplayed()==false)
        {
        	System.out.println("Plan Year Ends oprions are not coming after clicking on No");
        }
        Thread.sleep(1000);
        radioYesSubjectToERISA.click();
        Thread.sleep(1000);
        WebElement noCheckboxERISAInfo = driver.findElement(By.id("chkErisaInformation"));
        noCheckboxERISAInfo.click();
        Thread.sleep(1000);
        WebElement administratorDiv = driver.findElement(By.id("divPlanYearEnds"));
        if(administratorDiv.isDisplayed()==true)
        {
        	System.out.println("Administrator and ERISA Plan Details are getting displayed after unchecking on No checkbox");
        }
        else if(administratorDiv.isDisplayed()==false)
        {
        	System.out.println("Administrator and ERISA Plan Details are not getting displayed after unchecking on No checkbox");
        }
        Thread.sleep(1000);
        noCheckboxERISAInfo.click();
        if(administratorDiv.isDisplayed()==true)
        {
        	System.out.println("Administrator and ERISA Plan Details are getting displayed after checking on No checkbox");
        }
        else if(administratorDiv.isDisplayed()==false)
        {
        	System.out.println("Administrator and ERISA Plan Details are not getting displayed after checking on No checkbox");
        }
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
        Thread.sleep(1000);
        WebElement selectPlanYearEnds = driver.findElement(By.id("selectErisaPlanYearEnds"));
        selectPlanYearEnds.click();
        Thread.sleep(1000);
        Select dropdown1 = new Select(driver.findElement(By.id("selectErisaPlanYearEnds")));
        for(int i=1;i<=2;i++)
        {
        	dropdown1.selectByIndex(i);
        	Thread.sleep(1000);
        }
        WebElement fiscalDateDiv = driver.findElement(By.id("divFiscalDate"));
        if(fiscalDateDiv.isDisplayed()==true)
        {
        	System.out.println("Fiscal Year End Date field is getting displayed");
        }
        else if(fiscalDateDiv.isDisplayed()==false)
        {
        	System.out.println("Fiscal Year End Date field is not getting displayed");
        }
        Thread.sleep(1000);
        WebElement calendarForFiscal = driver.findElement(By.id("effFiscalYearEndDateErisa"));
        calendarForFiscal.click();
        Thread.sleep(1000);
        WebElement anyDate = driver.findElement(By.xpath("/html/body/div[3]/div/div[3]/ul[2]/li[7]/div"));
        anyDate.click();
        Thread.sleep(1000);
        dropdown1.selectByIndex(3);
        Thread.sleep(1000);
        noCheckboxERISAInfo.click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,1000)");
        Thread.sleep(1000);
        WebElement selectAdministrator = driver.findElement(By.id("selectErisaAdministrator"));
        selectAdministrator.click();
        Thread.sleep(1000);
        Select  dropdown2 = new Select(driver.findElement(By.id("selectErisaAdministrator")));
        for(int i=1;i<=3;i++)
        {
        	dropdown2.selectByIndex(i);
        	Thread.sleep(1000);
        }
        WebElement adminName = driver.findElement(By.id("txtErisaAdministratorName"));
        adminName.sendKeys("Test123");
        Thread.sleep(1000);
        WebElement adminFedTaxID = driver.findElement(By.id("txtErisaAdministratorFederalTaxID"));
        adminFedTaxID.sendKeys("123456789");
        Thread.sleep(1000);
        WebElement contactFirstName = driver.findElement(By.id("txtErisaAdministratorContactFName"));
        contactFirstName.sendKeys("Test123");
        Thread.sleep(1000);
        WebElement contactLastName = driver.findElement(By.id("txtErisaAdministratorContactLName"));
        contactLastName.sendKeys("Test123");
        Thread.sleep(1000);
        WebElement phoneNumber = driver.findElement(By.id("txtErisaAdministratorPhoneNumber"));
        phoneNumber.sendKeys("1234567890");
        Thread.sleep(1000);
        WebElement ext = driver.findElement(By.id("txtErisaAdministratorExt"));
        ext.sendKeys("12345");
        Thread.sleep(1000);
        WebElement addrLine1 = driver.findElement(By.id("txtErisaAddressOne"));
        addrLine1.sendKeys("Test123");
        Thread.sleep(1000);
        WebElement addrLine2 = driver.findElement(By.id("txtErisaAddressTwo"));
        addrLine2.sendKeys("Test123");
        Thread.sleep(1000);
        WebElement city = driver.findElement(By.id("txtErisaCity"));
        city.sendKeys("Test");
        Thread.sleep(1000);
        WebElement selectState = driver.findElement(By.id("selectErisaState"));
        selectState.click();
        Thread.sleep(1000);
        Select dropdown3 = new Select(driver.findElement(By.id("selectErisaState")));
        for(int i=1;i<=56;i++)
        {
        	dropdown3.selectByIndex(i);
        }
        Thread.sleep(1000);
        WebElement zipCode = driver.findElement(By.id("txtErisaZipCode"));
        zipCode.sendKeys("12345");
        Thread.sleep(1000);
        radioYesSubjectToERISA.click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("scroll(0,1400)");
        Thread.sleep(1000);
        WebElement radioIncludeERISAYes = driver.findElement(By.id("rdnIncludeErisaFilingSTDErisaYes"));
        radioIncludeERISAYes.click();
        Thread.sleep(1000);
        WebElement erisaPlanName = driver.findElement(By.id("txtErisaSTDPlanName"));
        WebElement erisaPlanNumber = driver.findElement(By.id("txtErisaSTDPlanNumber"));
        if(erisaPlanName.isEnabled()==true && erisaPlanNumber.isEnabled()==true)
        {
        	System.out.println("Both ERISA Plan Name and ERISA Plan Number fields are enabled after clicking on Yes");
        }
        else if(erisaPlanName.isEnabled()==false || erisaPlanNumber.isEnabled()==false)
        {
        	System.out.println("Both ERISA Plan Name and ERISA Plan Number fields are disabled after clicking on Yes");
        }
        Thread.sleep(1000);
        WebElement radioIncludeERISANo = driver.findElement(By.id("rdnIncludeErisaFilingSTDErisaNo"));
        radioIncludeERISANo.click();
        Thread.sleep(1000);
        if(erisaPlanName.isEnabled()==true && erisaPlanNumber.isEnabled()==true)
        {
        	System.out.println("Both ERISA Plan Name and ERISA Plan Number fields are enabled after clicking on No");
        }
        else if(erisaPlanName.isEnabled()==false || erisaPlanNumber.isEnabled()==false)
        {
        	System.out.println("Both ERISA Plan Name and ERISA Plan Number fields are disabled after clicking on No");
        }
        Thread.sleep(1000);
        //hidden div: divSubToErisa
        WebElement radioNotSubjectToERISA = driver.findElement(By.id("rdnNotSubToErisaYes"));
        radioNotSubjectToERISA.click();
        Thread.sleep(1000);
        WebElement explainDivUnderPlanDetails = driver.findElement(By.id("divSubToErisa"));
        if(explainDivUnderPlanDetails.isDisplayed()==true)
        {
        	System.out.println("Textbox is getting displayed under ERISA Plan Details after clicking on Yes");
        }
        else if(explainDivUnderPlanDetails.isDisplayed()==false)
        {
        	System.out.println("Textbox is not getting displayed under ERISA Plan Details after clicking on Yes");
        }
        Thread.sleep(1000);
        WebElement radioYestSubjectToERISA = driver.findElement(By.id("rdnNotSubToErisaNo"));
        radioYestSubjectToERISA.click();
        Thread.sleep(1000);
        if(explainDivUnderPlanDetails.isDisplayed()==true)
        {
        	System.out.println("Textbox is getting displayed under ERISA Plan Details after clicking on No");
        }
        else if(explainDivUnderPlanDetails.isDisplayed()==false)
        {
        	System.out.println("Textbox is not getting displayed under ERISA Plan Details after clicking on No");
        }
        Thread.sleep(1000);
        WebElement saveButton = driver.findElement(By.id("btnGeneralProdInfoSave"));
        saveButton.click();
        Thread.sleep(2000);
        WebElement logout = driver.findElement(By.id("logoutLink"));
        logout.click();
        Thread.sleep(1000);
        WebElement yesAfterLogout = driver.findElement(By.id("btnlogoutYes"));
        yesAfterLogout.click();
        Thread.sleep(1000);
        driver.quit();
        
        
    }

}
