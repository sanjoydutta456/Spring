package com.metlife.gsp.classSetup;



import org.junit.Before;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.Test;


import com.metlife.gsp.login.Login_INT;

public class ClassSetup_CriticalIllnessTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    
    @Test
   	public void critical()throws Exception
   	{
   		
   		WebElement caseId=driver.findElement(By.id("RFPID"));
   		caseId.sendKeys("4-4A7ONV");
   		WebElement submit=driver.findElement(By.id("SearchButtonIntUser"));
   		submit.click();
   		Thread.sleep(2000);
   		WebElement edit=driver.findElement(By.id("editCustomer"));
   		edit.click();
   		Thread.sleep(1000);
   		
   		WebElement criticillness=driver.findElement(By.id("navDashCritIll"));
   		criticillness.click();
   		Thread.sleep(3000);
   		
   		WebElement replacementcov=driver.findElement(By.id("rdnCIreplacementCoverageYes"));
   		replacementcov.click();
   		Thread.sleep(1000);
   		
   		WebElement retireescov=driver.findElement(By.id("rdnCIRetireesCoveredYes"));
   		retireescov.click();
   		Thread.sleep(1000);
   		
   		WebElement expariates=driver.findElement(By.id("rdnCIExpatriatesYes"));
   		expariates.click();
   		Thread.sleep(1000);
   		
   		WebElement adoption=driver.findElement(By.id("chkCILifeEventsAB"));
   		adoption.click();
   		Thread.sleep(1000);
   		
   		WebElement marriage=driver.findElement(By.id("chkCILifeEventsMD"));
   		marriage.click();
   		Thread.sleep(1000);
   		
   		WebElement death=driver.findElement(By.id("chkCILifeEventsDT"));
   		death.click();
   		Thread.sleep(1000);
   		
   		WebElement other1=driver.findElement(By.id("chkCILifeEventsOT"));
   		other1.click();
   		Thread.sleep(1000);
   		
   		WebElement other1text=driver.findElement(By.id("txtCIQualifyingOther"));
   		other1text.sendKeys("other qualifying events");
   		Thread.sleep(1000);
   		
   		Select erisastatus=new Select(driver.findElement(By.id("selectErisaStatusCI")));
   		erisastatus.selectByIndex(2);
   		Thread.sleep(1000);
   		
   		WebElement erisawrapper=driver.findElement(By.id("rdnCIErisaWrapperYes"));
   		erisawrapper.click();
   		Thread.sleep(1000);
   		
   		WebElement pretax=driver.findElement(By.id("rdnCIPremiumTaxPre"));
   		pretax.click();
   		Thread.sleep(1000);
   		
   		WebElement enrollmentfirm=driver.findElement(By.id("rdnCIEnrollmentFirmYes"));
   		enrollmentfirm.click();
   		Thread.sleep(1000);
   		
   		WebElement onballot=driver.findElement(By.id("rdnCIEnrollmentOnBallot"));
   		onballot.click();
   		Thread.sleep(1000);
   		
   		WebElement callcenter=driver.findElement(By.id("rdnCIEnrollmentCallCenter"));
   		callcenter.click();
   		Thread.sleep(1000);
   		
   		WebElement onsite=driver.findElement(By.id("rdnCIEnrollmentOnSite"));
   		onsite.click();
   		Thread.sleep(1000);
   		
   		WebElement other2=driver.findElement(By.id("rdnCIEnrollmentOther"));
   		other2.click();
   		Thread.sleep(1000);
   		
   		WebElement other2text=driver.findElement(By.id("txtCIOtherStrategy"));
   		other2text.sendKeys("other enrollment strategies");
   		Thread.sleep(1000);
   		
   		WebElement ongoingenrollments=driver.findElement(By.id("rdnCIOnGoingEnrollmentNo"));
   		ongoingenrollments.click();
   		Thread.sleep(1000);
   		
   		WebElement ongoingenrollmentstext=driver.findElement(By.id("txtCIManagingNewHires"));
   		ongoingenrollmentstext.sendKeys("state reasons for clicking on no button");
   		Thread.sleep(1000);
   		
   		WebElement annualenrollments=driver.findElement(By.id("rdnCIAnnualEnrollmentYes"));
   		annualenrollments.click();
   		Thread.sleep(1000);
   		
   		WebElement customer=driver.findElement(By.id("rdnCIEmployeeCustomer"));
   		customer.click();
   		Thread.sleep(1000);
   		
   		WebElement tpa=driver.findElement(By.id("rdnCIEmployeeTPA"));
   		tpa.click();
   		Thread.sleep(1000);
   		
   		WebElement brokerproducer=driver.findElement(By.id("rdnCIEmployeeBroker"));
   		brokerproducer.click();
   		Thread.sleep(1000);
   		
   		WebElement other3=driver.findElement(By.id("rdnCIEmployeeOther"));
   		other3.click();
   		Thread.sleep(1000);
   		
   		WebElement other3text=driver.findElement(By.id("txtCIOtherEmployee"));
   		other3text.sendKeys("other coverages");
   		Thread.sleep(1000);
   		
   		WebElement companyname=driver.findElement(By.id("txtCICompanyName"));
   		companyname.sendKeys("Cognizant Technology Solutions India Pvt Ltd");
   		Thread.sleep(1000);
   		
   		WebElement contactfname=driver.findElement(By.id("txtCIContactFirstName"));
   		contactfname.sendKeys("Aniket");
   		Thread.sleep(1000);
   		
   		WebElement contactlname=driver.findElement(By.id("txtCIContactLastName"));
   		contactlname.sendKeys("Das");
   		Thread.sleep(1000);
   		
   		WebElement contactphnumber=driver.findElement(By.id("txtCIContactPhoneNumber"));
   		contactphnumber.sendKeys("0987654321");
   		Thread.sleep(1000);
   		
   		WebElement contactemailaddress=driver.findElement(By.id("txtCIContactEmailAddress"));
   		contactemailaddress.sendKeys("joy999@gmail.com");
   		Thread.sleep(1000);
   		
   		Select steprate=new Select(driver.findElement(By.id("selectStepRateCalculation")));
   		steprate.selectByIndex(2);
   		Thread.sleep(1000);
   		
   		WebElement saveBtn=driver.findElement(By.id("btnCISave"));
   		saveBtn.click();
   		Thread.sleep(3000);
   		
   		WebElement logoutBtn=driver.findElement(By.id("logoutLink"));
   		logoutBtn.click();
   		Thread.sleep(1000);
   		
   		WebElement logoutBtnyes=driver.findElement(By.id("btnlogoutYes"));
   		logoutBtnyes.click();
   		Thread.sleep(1000);
   		
   		driver.quit();
   		
   	}

    

}
