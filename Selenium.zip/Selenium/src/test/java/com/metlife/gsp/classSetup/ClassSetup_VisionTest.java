package com.metlife.gsp.classSetup;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class ClassSetup_VisionTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();   
        Thread.sleep(1500);
        driver.findElement(By.id("navDashClass")).click();  
        driver.manage().window().maximize();
        Thread.sleep(8000);
        driver.findElement(By.id("btnClsSetupAddClass")).click(); 
        Thread.sleep(1500);
        driver.findElement(By.id("Vision9")).click();  
        Select drop1=new Select( driver.findElement(By.id("selectClsDesc9")));
        drop1.selectByIndex(5);
        driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo9")).click();   
        driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes9")).click();   
        driver.findElement(By.id("chkClsSelect102_9_0")).click(); 
        driver.findElement(By.id("txtClsVisionNumOfEmpForVisionCov_9_0")).sendKeys("25");  
        driver.findElement(By.id("txtClsVisionEmployerContriEmpVisionCov_9_0")).sendKeys("15");   
        driver.findElement(By.id("txtClsVisionPartialContributionVisionCov_9_0")).sendKeys("14");   
        driver.findElement(By.id("txtClsVisionEmployerContriDepVisionCov_9_0")).sendKeys("16");   
        driver.findElement(By.id("rdnClassVisionEligibiltyWaitPeriodNo9")).click();    
        driver.findElement(By.id("rdnClassVisionEligibiltyWaitPeriodYes9")).click();   
        Select drop4=new Select( driver.findElement(By.id("selectVisionNewHirePolicyBenefitsEffDate9")));  
        drop4.selectByIndex(1);
        drop4.selectByIndex(2);
        drop4.selectByIndex(3);
        drop4.selectByIndex(4);
        drop4.selectByIndex(5);
        drop4.selectByIndex(6);
        drop4.selectByIndex(7);
        drop4.selectByIndex(8);
        drop4.selectByIndex(9);
        driver.findElement(By.id("otherVisionEffDate9")).sendKeys("02/15/2019");   
        Select drop5=new Select( driver.findElement(By.id("selectVisionNewHireWaitingPeriod9")));  
        drop5.selectByIndex(1);
        drop5.selectByIndex(2);
        drop5.selectByIndex(3);
        drop5.selectByIndex(4);
        drop5.selectByIndex(5);
        drop5.selectByIndex(6);
        drop5.selectByIndex(7);
        drop5.selectByIndex(8);
        driver.findElement(By.id("txtClsVisionEnterWaitperiod9")).sendKeys("25");   
        Select drop6=new Select( driver.findElement(By.id("selectVisionNewHirePolicyEffDate9")));  
        drop6.selectByIndex(1);
        drop6.selectByIndex(2);
        //drop6.selectByIndex(3);
        Select drop7=new Select( driver.findElement(By.id("selectVisionClassEmploymentEnds9")));
        drop7.selectByIndex(1);
        drop7.selectByIndex(2);
        drop7.selectByIndex(3);
        drop7.selectByIndex(4);
        driver.findElement(By.id("txtdivVisionEmploymentEndsOther9")).sendKeys("25");    
        Select drop8=new Select( driver.findElement(By.id("selectVisionClassEligibleClassDate9")));
        drop8.selectByIndex(1);
        drop8.selectByIndex(2);
        drop8.selectByIndex(3);
        drop8.selectByIndex(4);
        driver.findElement(By.id("txtdivVisionEligibleClassDateOther9")).sendKeys("25");   
        Select drop9=new Select( driver.findElement(By.id("selectRetirementVision9"))); 
        drop9.selectByIndex(1);
        drop9.selectByIndex(2);
        drop9.selectByIndex(3);
        drop9.selectByIndex(4);
        driver.findElement(By.id("txtdivVisionRetirementOther9")).sendKeys("25"); 
        Select drop10=new Select( driver.findElement(By.id("selectVisionDependentLimitingAge9")));  
        drop10.selectByIndex(1);
        drop10.selectByIndex(2);
        drop10.selectByIndex(3);
       drop10.selectByIndex(4);
        driver.findElement(By.id("txtdivVisionDependentLimitingAgeOther9")).sendKeys("25"); 
        Select drop11=new Select( driver.findElement(By.id("selectVisionDependentNotMetDefinition9")));   
        drop11.selectByIndex(1);
        drop11.selectByIndex(2);
        drop11.selectByIndex(3);
       drop11.selectByIndex(4);
        driver.findElement(By.id("txtdivVisionDependentNotMetDefinitionOther9")).sendKeys("25");  
        driver.findElement(By.id("chkVisionApplyChangesToAll9")).click();    
        driver.findElement(By.id("txtClsTempHoursWorkedVision9")).sendKeys("25");  
        Select drop12=new Select( driver.findElement(By.id("selectClsTempPayPeriodVision9")));
        drop12.selectByIndex(1);
        drop12.selectByIndex(2);
        drop12.selectByIndex(3);
        drop12.selectByIndex(4);
        driver.findElement(By.id("rdnContinuationOfCoverageNoVision9")).click();  
        driver.findElement(By.id("rdnContinuationOfCoverageYesVision9")).click();  
        driver.findElement(By.id("chkLeaveOfAbsenceVision9")).click();   
        driver.findElement(By.id("txtLeaveOfAbsenceDtVision9")).sendKeys("02/14/2019");  
        driver.findElement(By.id("chkInjuryOrSicknessVision9")).click();  
        driver.findElement(By.id("txtInjuryOrSicknessDtVision9")).sendKeys("02/14/2019");  
        driver.findElement(By.id("chkPartTimeStatusVision9")).click();  
        driver.findElement(By.id("txtPartTimeStatusDtVision9")).sendKeys("02/14/2019");   
        driver.findElement(By.id("chkLayoffVision9")).click();  
        driver.findElement(By.id("txtLayoffDtVision9")).sendKeys("02/14/2019");   
        driver.findElement(By.id("chkStrikeVision9")).click();  
        driver.findElement(By.id("txtStrikeDtVision9")).sendKeys("02/14/2019");   
        
        driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("25");   
        
} 

}
