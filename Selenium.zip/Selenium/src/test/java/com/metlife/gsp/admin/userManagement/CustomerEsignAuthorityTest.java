package com.metlife.gsp.admin.userManagement;

import java.util.NoSuchElementException;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class CustomerEsignAuthorityTest {

	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	WebDriverWait myWaitVar = new WebDriverWait(driver,20);
        driver.findElement(By.id("RFPID")).sendKeys("1-1F5MS1"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.className("P10")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        /*driver.findElement(By.id("breadCustEsignAuthority")).click();*/ 
        WebElement we = myWaitVar.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"breadCustEsignAuthority\"]")));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"breadCustEsignAuthority\"]")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        
        //Test case 1 when no customer
        if("Currently there are no Customer Approvers for this opportunity.".contentEquals("Currently there are no Customer Approvers for this opportunity.")) {
        	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        	Thread.sleep(2000);
        	driver.findElement(By.id("btnReturnToDashboardCustEsignList")).click();
        }
        System.out.println("Test case 1 Passed");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //Test 2 when only 1 customer
        /*driver.findElement(By.xpath("//*[@id=\"leftNavsearchCustomer\"]")).click();*/
        Thread.sleep(2000);
        driver.findElement(By.id("leftNavsearchCustomer")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.id("RFPID")).clear();
        driver.findElement(By.id("RFPID")).sendKeys("0062a000005Ot6kAAC");
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.id("editCustomer")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("breadCustEsignAuthority")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        try {
        	 if(driver.findElement(By.id("rdnCustomerApprovalIntUser1")).isDisplayed()) {
        		 Thread.sleep(2000);
        		 driver.findElement(By.id("btnReturnToDashboardCustEsignList")).click();
        		 
             }
    
        }
       catch(Exception ex){
    	   Thread.sleep(2000);
    	   driver.findElement(By.id("btnReturnToDashboardCustEsignList")).click();
    	   System.out.println("Test case 2 Passed");
       }
        Thread.sleep(2000);
        //Test case 3 when no update having more than 1 customer
        driver.findElement(By.id("leftNavsearchCustomer")).click();
        driver.findElement(By.id("RFPID")).clear();
        driver.findElement(By.id("RFPID")).sendKeys("6-4A7ONV");
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.id("editCustomer")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("breadCustEsignAuthority")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        if(driver.findElement(By.id("rdnCustomerApprovalIntUser0")).isDisplayed()) {
        	if(driver.findElement(By.id("rdnCustomerApprovalIntUser0")).isSelected()) {
        		Thread.sleep(2000);
        		driver.findElement(By.id("rdnCustomerApprovalIntUser1")).click();
        	}
        	else {
        		Thread.sleep(2000);
        		driver.findElement(By.id("rdnCustomerApprovalIntUser0")).click();
        	}
        	driver.findElement(By.id("btnAdminPopupNo")).click();
        	Assert.assertFalse("Test case 3 failed",driver.findElement(By.id("divCustEsignUpdated")).isDisplayed());
        	System.out.println("Test case 3 Passed");
        	}
        Thread.sleep(2000);
        driver.findElement(By.id("btnReturnToDashboardCustEsignList")).click();
        
        Thread.sleep(2000);
        //Test case 4 when updated having more than 1 customer
        driver.findElement(By.id("leftNavAdminInfo")).click();
        driver.findElement(By.id("breadCustEsignAuthority")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("btnSecMgnmtHeaderNo")).click();
        if(driver.findElement(By.id("rdnCustomerApprovalIntUser0")).isDisplayed()) {
        	if(driver.findElement(By.id("rdnCustomerApprovalIntUser0")).isSelected()) {
        		Thread.sleep(2000);
        		driver.findElement(By.id("rdnCustomerApprovalIntUser1")).click();
        	}
        	else {
        		Thread.sleep(2000);
        		driver.findElement(By.id("rdnCustomerApprovalIntUser0")).click();
        	}
        	Thread.sleep(2000);
        	driver.findElement(By.id("btnAdminPopupYes")).click();
        	//Assert.assertTrue("Test case 4 failed",driver.findElement(By.id("divCustEsignUpdated")).isDisplayed());
        	System.out.println("Test case 4 passed");	
        }
        Assert.assertTrue(driver.findElement(By.id("logoutLink")).isDisplayed());
        Thread.sleep(2000);
    	driver.findElement(By.id("logoutLink")).click();
    	Assert.assertTrue(driver.findElement(By.id("viewLogoutOverlay")).isDisplayed());
        driver.findElement(By.id("btnlogoutViewYes")).click();
        driver.close();
       
        //WebElement element =driver.findElement(By.className("emptyResult"));
        // System.out.println("Element"+element);
        
        
    } 
}
