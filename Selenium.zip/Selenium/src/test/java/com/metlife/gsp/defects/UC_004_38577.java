package com.metlife.gsp.defects;

import static org.junit.Assert.fail;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class UC_004_38577 {

	@Test
	public void testDropdownText() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev.custadmin.metlife.com/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement username = driver.findElement(By.id("USER"));
        WebElement password = driver.findElement(By.id("PASSWORD"));
        WebElement signIn = driver.findElement(By.id("cmdEnter"));
        username.sendKeys("gspcatqauser1");
        Thread.sleep(1000);
        password.sendKeys("metlife1");
        Thread.sleep(1000);
        signIn.click();
        WebElement caseID =driver.findElement(By.id("RFPID"));
        Thread.sleep(2000);
        caseID.sendKeys("1-1F5MT1");
        Thread.sleep(1000);
        WebElement search =driver.findElement(By.id("SearchButtonIntUser"));
        search.click();
        Thread.sleep(2000);
        WebElement edit =driver.findElement(By.id("editCustomer"));
        edit.click();
        WebElement classSetupNav = driver.findElement(By.id("leftNavClassSetup"));
        classSetupNav.click();
        Thread.sleep(7000);
        WebElement addClass =driver.findElement(By.id("btnClsSetupAddClass"));
        addClass.click();
        Thread.sleep(2000);
        WebElement dentalTab =driver.findElement(By.id("Dental1"));
        dentalTab.click();
        Thread.sleep(1000);
        WebElement selectCheckbox = driver.findElement(By.id("chkClsSelect9999_1_1"));
        selectCheckbox.click();
        ((JavascriptExecutor)driver).executeScript("scroll(0,600)");
        Thread.sleep(4000);
        JavascriptExecutor js = ((JavascriptExecutor)driver);   //to scroll inside popup
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1100);
        Thread.sleep(1000);
        WebElement selectIncludeQualEve = driver.findElement(By.id("selectDentalIncludedQualifyingEvents1"));
        selectIncludeQualEve.click();
        Select dropdown = new Select(driver.findElement(By.id("selectDentalIncludedQualifyingEvents1")));
        dropdown.selectByIndex(2);
        String selectedOption = dropdown.getFirstSelectedOption().getText();
        if(selectedOption.equals("You or your dependent's loss of coverage under any group health coverage"))
        {
        	System.out.println("Text has been successfully updated to "
        			+ "\"You or your dependent's loss of coverage under any group health coverage\"");
        }
        else
        {
        	System.err.println("The old text, that is �You or your dependent's loss of coverage under any group health� "
        			+ "is still getting displayed");
        	Thread.sleep(3000);
            ((JavascriptExecutor)driver).executeScript("scroll(0, -400)");
            WebElement closeButton = driver.findElement(By.id("closeBtn1"));
            closeButton.click();
            Thread.sleep(1000);
            closeButton.click();
            Thread.sleep(1000);
            WebElement logOut = driver.findElement(By.id("logoutLink"));
            logOut.click();
            Thread.sleep(1000);
            WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
            yesButton.click();
            Thread.sleep(1000);
            driver.quit();
            fail("The old text, that is �You or your dependent's loss of coverage under any group health");
        }
        Thread.sleep(3000);
        ((JavascriptExecutor)driver).executeScript("scroll(0, -400)");
        WebElement closeButton = driver.findElement(By.id("closeBtn1"));
        closeButton.click();
        Thread.sleep(1000);
        closeButton.click();
        Thread.sleep(1000);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.quit();
        
	}
}
