package com.metlife.gsp.authorization;

 

import static org.junit.Assert.assertTrue;

 

import java.util.concurrent.TimeUnit;

 

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.ElementNotInteractableException;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

 

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

import com.metlife.gsp.login.Login_DEV;

 

public class AuthorizationAndSubmitTest {

  

                private WebDriver driver;

                private Login_DEV login;

                private boolean iterationFlag;

 

                @Before

                public void setUp() {

                                login = new Login_DEV();

                                driver = login.setUp();
                                
                }
                                
                                @Test

                                public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

                                               

                                                JavascriptExecutor js = (JavascriptExecutor) driver;

                                               

                                               

                                                WebElement oppID = driver.findElement(By.id("RFPID"));

                                                oppID.sendKeys("1-1F5MT1");

                                                driver.findElement(By.id("SearchButtonIntUser")).click();

                                                driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

                                                driver.findElement(By.id("editCustomer")).click();
                                                
                                                
                                                
                                                
                                                
                                                
                                                

                       driver.findElement(By.id("navDashAuthSign")).click();
                       Thread.sleep(1000);
                       driver.manage().window().maximize();
                                              /*  if (authorisationSubmitLink.isDisplayed()) {

                                                                authorisationSubmitLink.click();

                                                                assertTrue(driver.findElement(By.id("divAuthorizationContent")).isDisplayed());

                                                                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

                                                }                                       

                                                               */
                       							Thread.sleep(1000);
                                                driver.findElement(By.id("chkAuthPrivacyNotice")).click();
                                         		 Thread.sleep(1000);
                                                               
                                         		
                                         		driver.findElement(By.id("chkAuthIntermediaryCompensationNotice")).click();   
                                        		 Thread.sleep(1000);
                                        		 
                                
                                        		 driver.findElement(By.id("rdnHippaInfoAccessClaim")).click();
                                        		 Thread.sleep(1000);
                                        		
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("rdnAuthHippaInformationPhiTitYes")).click();
                                        		 Thread.sleep(1000);
                                
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("btnAuthHIPPAInformationAddPHIAccEmpTit")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                
                                        		 driver.findElement(By.id("txtAuthHIPPAInformationPHIAccEmpTit0")).clear();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 driver.findElement(By.id("txtAuthHIPPAInformationPHIAccEmpTit0")).sendKeys("abc");
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 
                                        		 //REMOVE
                                        		 /*
                                        		 driver.findElement(By.xpath("//*[@id=\"btnPHIRemove2\"]")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 driver.findElement(By.id("btnDeleteWarningYes")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 System.out.println(33);*/
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		/* driver.findElement(By.id("")).click();
                                        		 Thread.sleep(2000);*/
                                        		 /*driver.findElement(By.id("btnDeleteWarningYes")).click();
                                        		 Thread.sleep(2000);*/
                                        		 
                                
                                        		 driver.findElement(By.id("chkAuthHIPPAInformationReferenceToPrivacy")).click();    
                                        		 Thread.sleep(2000);
                                        		 driver.findElement(By.id("chkAuthHIPPAInformationRParticipantsRights")).click();
                                        		 Thread.sleep(2000);
                                        		 driver.findElement(By.id("chkAuthHIPPAInformationRPrivacyCompliantsIssues")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 driver.findElement(By.id("rdnAuthHippaInformationPhiTitNo")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 driver.findElement(By.id("rdnHippaInfoDoNotAccessClaim")).click();
                                        		 Thread.sleep(2000);
                                        		 driver.findElement(By.id("chkAuthHIPPACertifyInformationRecieved")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("chkAuthParticipateInPortabilityTrustIndicator")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 

                                        		
                 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("chkAuthNoPendingClaimsIndicator")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("chkAuthPolicyCertificateMailingTypeAuthorizeMetlife")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 driver.findElement(By.id("chkAuthPolicyCertificateMailingTypePaperPolicy")).click();
                                        		 Thread.sleep(2000);
                                        		
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 
                                        		 driver.findElement(By.id("chkAuthSignatureOverrideCustomer")).click();
                                        		 Thread.sleep(2000);
                                        		 driver.findElement(By.id("chkAuthSignatureOverrideBroker")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 
                                        		 driver.findElement(By.id("txtAuthoriCommenSection")).sendKeys("defg");
                                        		 Thread.sleep(2000);
                                        		 

                                        		 //test customer validation
                                        		 driver.findElement(By.id("btnvalidateCustomer")).click();
                                        		 Thread.sleep(2000);
                                        		 
                                        		 /*((JavascriptExecutor)driver).executeScript("scroll(0,2000)");
                                        		 Thread.sleep(2000); */
                                        		 js.executeScript("window.scrollBy(0,2000)");
                                        		 
                                                 //testbrokervalidation
                                                     		 
                                        		 Thread.sleep(2000);   		 
                                                  driver.findElement(By.id("btnvalidateBroker")).click();      
                                                  
                                        		  System.out.println("Passed Broker Validation");
                                        		  Thread.sleep(4000);
                                        		  
                                           		
                                        		  
                                          		  js.executeScript("window.scrollBy(0,2000)");
                                           	
                                        		  //validateapptab  btnValidateESignIUser
                                        			 
                                        		  
                                        		  
                                             		driver.findElement(By.xpath("//*[@id=\"btnValidateESignIUser\"]")).click();      
                                            		 Thread.sleep(4000);
                                            		
                                            		 

                                            		 System.out.println("validatetab");
                                            		 

                                             		driver.findElement(By.id("chkAuthSignatureOverrideCustomer")).click();      
                                            		 Thread.sleep(2000);

                                              		driver.findElement(By.id("chkAuthSignatureOverrideBroker")).click();      
                                             		 Thread.sleep(2000);
                                             		 
                                        		              
                                        		              
                                                   		 
                                                                  		 
                                        		 
 
                                        		 
                                                     		 
                                                     		 
                                             		  js.executeScript("window.scrollBy(0,2000)");
                                        		 
                                              
                                                     		 
                                                     		//ReviewESignIUser
                                                                  		driver.findElement(By.id("btnAuthorReviewESignIUser")).click();      
                                                                 		 Thread.sleep(2000);
                                                                  		
                                                                  		 
                                                                   		/*driver.findElement(By.id("chkAuthPrivacyNotice")).click();      
                                                                  		 Thread.sleep(2000);
                                                                   		*/
                                                                  		 
                                                                  	
                                                                 		
                                                                 		
                                                                 		
/*
                                                                  		driver.findElement(By.id("chkAuthSignatureOverrideCustomer"));      
                                                                 		 Thread.sleep(2000);

                                                                   		driver.findElement(By.id("chkAuthSignatureOverrideBroker"));      
                                                                  		 Thread.sleep(2000);*/
                                                                  		 
/*
                                                      		driver.findElement(By.id("btnAuthorReviewESignIUser"));      
                                                     		 Thread.sleep(4000);
                                                     		 System.out.println(999);
                                                     		
                                                     		driver.findElement(By.id("okBtnReviewEsignPackWarningOverlay"));      
                                                     		 Thread.sleep(1000);
                                                     		 

                                                      		driver.findElement(By.id("btnViewImplFolder"));      
                                                     		 Thread.sleep(4000);
                                                     		                		 
                                                     		 
                                                     		 */
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                                     		 
                                        		 
                }

               


               
                               

                }

























