package com.metlife.gsp.classSetup;

import java.util.concurrent.TimeUnit;


import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class ClassSetup_LifeTest {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	driver.findElement(By.id("RFPID")).sendKeys("4-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.id("editCustomer")).click();
        
        Thread.sleep(1500);
        driver.findElement(By.id("navDashClass")).click();  
        driver.manage().window().maximize();
        Thread.sleep(8000);
        
        driver.findElement(By.id("btnClsSetupAddClass")).click(); 
        Thread.sleep(1500);
        Select drop1=new Select( driver.findElement(By.id("selectClsDesc9")));
        drop1.selectByIndex(5);
        driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo9")).click();   
        driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes9")).click();   
       // driver.findElement(By.id("rdnClsTempOpenClass9")).click();   
        //driver.findElement(By.id("rdnClsTempClosedClass9")).click();   
        driver.findElement(By.id("chkClsSelect49_9_0")).click(); 
        driver.findElement(By.id("txtClassLifeBasicLifeEligibles_9_0")).sendKeys("25");  
        driver.findElement(By.id("txtClassLifeBasicLifeEmployee_9_0")).sendKeys("15");   
        driver.findElement(By.id("txtClassLifeBasicLifePartialContribution_9_0")).sendKeys("14");   
        Select drop2=new Select( driver.findElement(By.id("selectClsCurrentEmpEarningsDefinition9"))); 
        drop2.selectByIndex(1);
        drop2.selectByIndex(2);
        drop2.selectByIndex(3);
        drop2.selectByIndex(4);
        drop2.selectByIndex(5);
        drop2.selectByIndex(6);
        //drop2.selectByIndex(7);
       driver.findElement(By.id("txtLifeClsOtherEarningsDescription9")).sendKeys("15");    
        Select drop3=new Select( driver.findElement(By.id("selectClsCurrentEmpAveragedOver9"))); 
        drop3.selectByIndex(1);
        drop3.selectByIndex(2);
        drop3.selectByIndex(3);
        drop3.selectByIndex(4);
        //drop3.selectByIndex(5);
        driver.findElement(By.id("txtLifeClsOtherAveragedOver9")).sendKeys("25");  
        driver.findElement(By.id("rdnClassLifeEligibiltyWaitPeriodNo9")).click();    
        driver.findElement(By.id("rdnClassLifeEligibiltyWaitPeriodYes9")).click();   
        Select drop4=new Select( driver.findElement(By.id("selectLifeNewHirePolicyBenefitsEffDate9")));  
        drop4.selectByIndex(1);
        drop4.selectByIndex(2);
        drop4.selectByIndex(3);
        drop4.selectByIndex(4);
        drop4.selectByIndex(5);
        drop4.selectByIndex(6);
        drop4.selectByIndex(7);
        drop4.selectByIndex(8);
       // drop4.selectByIndex(9);
        Select drop5=new Select( driver.findElement(By.id("selectLifeNewHireWaitingPeriod9")));  
        drop5.selectByIndex(1);
        drop5.selectByIndex(2);
        drop5.selectByIndex(3);
        drop5.selectByIndex(4);
        drop5.selectByIndex(5);
        drop5.selectByIndex(6);
        drop5.selectByIndex(7);
        drop5.selectByIndex(8);
       // drop5.selectByIndex(9);
        driver.findElement(By.id("txtClsLifeEnterWaitperiod9")).sendKeys("25");   
        Select drop6=new Select( driver.findElement(By.id("selectLifeNewHirePolicyEffDate9")));  
        drop6.selectByIndex(1);
        drop6.selectByIndex(2);
        //drop6.selectByIndex(3);
        Select drop7=new Select( driver.findElement(By.id("selectClassLifeEmploymentEnds9")));
        drop7.selectByIndex(1);
        drop7.selectByIndex(2);
        drop7.selectByIndex(3);
       // drop7.selectByIndex(4);
        driver.findElement(By.id("txtdivLifeEmploymentEndsOther9")).sendKeys("25");    
        Select drop8=new Select( driver.findElement(By.id("selectClassEligibleClassDate9")));
        drop8.selectByIndex(1);
        drop8.selectByIndex(2);
        drop8.selectByIndex(3);
        //drop8.selectByIndex(4);
        driver.findElement(By.id("txtdivLifeEligibleClassDateOther9")).sendKeys("25");   
        Select drop9=new Select( driver.findElement(By.id("selectLifeRetirement9"))); 
        drop9.selectByIndex(1);
        drop9.selectByIndex(2);
        drop9.selectByIndex(3);
        //drop9.selectByIndex(4);
        driver.findElement(By.id("txtdivLifeRetirementOther9")).sendKeys("25"); 
        Select drop10=new Select( driver.findElement(By.id("selectLifeDependentLimitingAge9")));  
        drop10.selectByIndex(1);
        drop10.selectByIndex(2);
        drop10.selectByIndex(3);
       // drop10.selectByIndex(4);
        driver.findElement(By.id("txtdivLifeDependentLimitingAgeOther9")).sendKeys("25"); 
        Select drop11=new Select( driver.findElement(By.id("selectLifeDependentNotMetDefinition9")));   
        drop11.selectByIndex(1);
        drop11.selectByIndex(2);
        drop11.selectByIndex(3);
       // drop11.selectByIndex(4);
        driver.findElement(By.id("txtdivLifeDependentNotMetDefinitionOther9")).sendKeys("25");  
        driver.findElement(By.id("chkLifeApplyChangesToAll9")).click();    
        driver.findElement(By.id("txtClsTempHoursWorkedLife9")).sendKeys("25");   
        driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("25");   
        driver.findElement(By.id("productNextBtn9")).click();   
}
}
