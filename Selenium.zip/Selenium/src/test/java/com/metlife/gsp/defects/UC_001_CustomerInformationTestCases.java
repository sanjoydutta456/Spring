package com.metlife.gsp.defects;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class UC_001_CustomerInformationTestCases {
	private WebDriver driver;
	private Login_DEV login;

	@Before
	public void setUp() {
		login = new Login_DEV();
		driver = login.setUp();
	}

	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MT1");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.id("editCustomer")).click();
		
		
		WebElement customerInformationLink = driver.findElement(By.id("navDashCustInfoBroker"));
		if (customerInformationLink.isDisplayed()) {
			customerInformationLink.click();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Thread.sleep(2000);
			assertTrue(driver.findElement(By.id("divCustomerTab")).isDisplayed());
		}
		
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//1.1.The users clicks on Add Location/Subsidiary button on customer section
		try {
		
		WebElement addLocSubs = driver.findElement(By.id("addLocBtn"));
		addLocSubs.click();
		Thread.sleep(2000);
		}catch(Exception e) {}
		
		Thread.sleep(2000);
		//1.2. Doing Business As (Customer Name) [CUST060] inside the pop-up is auto-populated from the value provided in customer information section
		if(driver.findElement(By.id("txtCustCompanyLegalName1")).getAttribute("value").contentEquals(driver.findElement(By.id("txtCustCompanyName1")).getAttribute("value"))){
			System.out.println("Test Case Auto-Populated Passed");
		}
		
		
		Thread.sleep(1000);
		//1.3. The field is editable
		WebElement some_element = driver.findElement(By.id("txtCustCompanyName1"));
	     String readonly = some_element.getAttribute("readonly");
	     Assert.assertNull(readonly);
	     System.out.println("The field is editable");
	     
	     
	     //Select drpBilling=new Select(driver.findElement(By.id("txtCustCompanyName1")));
	     Thread.sleep(2000);
	     //1.5.	The field can be blank
	     WebElement inputBox = driver.findElement(By.id("txtCustCompanyName1"));
	     String textInsideInputBox = inputBox.getAttribute("value");
	     if(textInsideInputBox.isEmpty())
	     {
	        System.out.println("Input field is empty");
	     }
	     else
	    	 System.out.println("Input field is not empty");
	     
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnCustAdditionalLocCancel3")).click();
	     Thread.sleep(1000);
	     driver.findElement(By.id("closeBtn3")).click();
	          
	     
	     Thread.sleep(2000);
	        
	        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divCustCustomerDetailsContent")),1100);
	        Thread.sleep(1000);
	     
	     //8.	Federal Tax ID field is editable inside Additional Location Popup in Customer Information screen
	     
	     driver.findElement(By.id("btnSubLocEditReview0")).click();
	     Thread.sleep(2000);
	     WebElement fedTaxID = driver.findElement(By.id("txtCustAdditionalLocFederalTaxID0"));
	     String fedTaxIsEditable = fedTaxID.getAttribute("readonly");
	     Assert.assertNull(fedTaxIsEditable);
	     System.out.println("The field is editable");
	     
	     
	     Thread.sleep(2000);
	     driver.findElement(By.id("btnCustAdditionalLocCancel0")).click();
	     Thread.sleep(2000);
	     driver.findElement(By.id("closeBtn0")).click();
	     
	     Thread.sleep(2000);
	    
	     
	     
	     //2.	Customer MetLink Chart shows Additional Location Primary Contact/Benefit Administrator name only
	     
/*	     WebElement name = driver.findElement(By.xpath("//*[@id=\"divMetlinkCustAccess\"]/div/div/div/div[4]/div/div[3]/div[2]"));
	     Thread.sleep(2000);
	     String nameText = name.getText();
	     if(nameText.contentEquals("mohit kumer")) {
	    	 System.out.println("Name Test Case Passed");
	     }
	     else {
	    	 System.out.println("Name Test Case Failed");
	     }*/
		    //Logout and quit
	      
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
	}
}
