package com.metlife.gsp.products;

import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.metlife.gsp.login.Login_INT;

public class CriticalIllnessTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    @Test
	public void critical()throws Exception
	{
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MS2");
		WebElement submit=driver.findElement(By.id("SearchButtonIntUser"));
		submit.click();
		Thread.sleep(3000);
		WebElement edit=driver.findElement(By.id("editCustomer"));
		edit.click();
		Thread.sleep(1000);
		
		WebElement criticillness=driver.findElement(By.id("navDashCritIll"));
		criticillness.click();
		Thread.sleep(3000);
		
		WebElement replacementcov=driver.findElement(By.id("rdnCIreplacementCoverageYes"));
		replacementcov.click();
		Thread.sleep(1000);
		
		WebElement retireescov=driver.findElement(By.id("rdnCIRetireesCoveredYes"));
		retireescov.click();
		Thread.sleep(1000);
		
		WebElement expariates=driver.findElement(By.id("rdnCIExpatriatesYes"));
		expariates.click();
		Thread.sleep(1000);
		
		/*WebElement adoption=driver.findElement(By.id("chkCILifeEventsAB"));
		adoption.click();
		Thread.sleep(1000);
		
		WebElement marriage=driver.findElement(By.id("chkCILifeEventsMD"));
		marriage.click();
		Thread.sleep(1000);
		
		WebElement death=driver.findElement(By.id("chkCILifeEventsDT"));
		death.click();
		Thread.sleep(1000);*/
		
		
		WebElement other=driver.findElement(By.id("chkCILifeEventsOT"));
		other.click();
		Thread.sleep(2000);
		
		WebElement othertext=driver.findElement(By.id("txtCIQualifyingOther"));
		othertext.sendKeys("additional qualifying events required");
		Thread.sleep(1000);
		
		Select erisaplan=new Select(driver.findElement(By.id("selectErisaStatusCI")));
		erisaplan.selectByIndex(2);
		Thread.sleep(1000);
		
		WebElement erisawrapper=driver.findElement(By.id("rdnCIErisaWrapperYes"));
		erisawrapper.click();
		Thread.sleep(1000);
		
		WebElement premiumstax=driver.findElement(By.id("rdnCIPremiumTaxPre"));
		premiumstax.click();
		Thread.sleep(1000);
		
		WebElement enrollmentfirm=driver.findElement(By.id("rdnCIEnrollmentFirmYes"));
		enrollmentfirm.click();
		Thread.sleep(1000);
		
		WebElement onballot=driver.findElement(By.id("rdnCIEnrollmentOnBallot"));
		onballot.click();
		Thread.sleep(1000);
		
		WebElement callcenter=driver.findElement(By.id("rdnCIEnrollmentCallCenter"));
		callcenter.click();
		Thread.sleep(1000);
		
		WebElement onsite=driver.findElement(By.id("rdnCIEnrollmentOnSite"));
		onsite.click();
		Thread.sleep(1000);
		
		WebElement other1=driver.findElement(By.id("rdnCIEnrollmentOther"));
		other1.click();
		Thread.sleep(1000);
		
		WebElement other1text=driver.findElement(By.id("txtCIOtherStrategy"));
		other1text.sendKeys("other strategies");
		Thread.sleep(1000);
		
		WebElement ongoingenrollments=driver.findElement(By.id("rdnCIOnGoingEnrollmentYes"));
		ongoingenrollments.click();
		Thread.sleep(1000);
		
		WebElement annualenrollments=driver.findElement(By.id("rdnCIAnnualEnrollmentYes"));
		annualenrollments.click();
		Thread.sleep(1000);
		
		WebElement customer=driver.findElement(By.id("rdnCIEmployeeCustomer"));
		customer.click();
		Thread.sleep(1000);
		
		WebElement tpa=driver.findElement(By.id("rdnCIEmployeeTPA"));
		tpa.click();
		Thread.sleep(1000);
		
		WebElement brokerproducer=driver.findElement(By.id("rdnCIEmployeeBroker"));
		brokerproducer.click();
		Thread.sleep(1000);
		
		WebElement other2=driver.findElement(By.id("rdnCIEmployeeOther"));
		other2.click();
		Thread.sleep(1000);
		
		WebElement other2text=driver.findElement(By.id("txtCIOtherEmployee"));
		other2text.sendKeys("other updates");
		Thread.sleep(1000);
		
		WebElement companyname=driver.findElement(By.id("txtCICompanyName"));
		companyname.sendKeys("Cognizant Technology Solutions");
		Thread.sleep(1000);
		
		WebElement contactfname=driver.findElement(By.id("txtCIContactFirstName"));
		contactfname.sendKeys("Aniket");
		Thread.sleep(1000);
		
		WebElement contactlname=driver.findElement(By.id("txtCIContactLastName"));
		contactlname.sendKeys("Das");
		Thread.sleep(1000);
		
		WebElement contactphnumber=driver.findElement(By.id("txtCIContactPhoneNumber"));
		contactphnumber.sendKeys("9087654321");
		Thread.sleep(1000);
		
		WebElement contactemail=driver.findElement(By.id("txtCIContactEmailAddress"));
		contactemail.sendKeys("ani999@gmail.com");
		Thread.sleep(1000);
		
		Select age=new Select(driver.findElement(By.id("selectStepRateCalculation")));
		age.selectByIndex(3);
		Thread.sleep(1000);
		
		WebElement save=driver.findElement(By.id("btnCISave"));
		save.click();
		Thread.sleep(3000);
		
		WebElement logout=driver.findElement(By.id("logoutLink"));
		logout.click();
		Thread.sleep(1000);
		
		WebElement logoutyes=driver.findElement(By.id("btnlogoutYes"));
		logoutyes.click();
		Thread.sleep(1000);
		
		driver.quit();
	
	}
    

}
