package com.metlife.gsp.defects;

import java.util.List;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class UC_004_EBS_877 {

	@Test
	public void testVisibilityAfterNo() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://int.custadmin.metlife.com/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement username = driver.findElement(By.id("USER"));
        WebElement password = driver.findElement(By.id("PASSWORD"));
        WebElement signIn = driver.findElement(By.id("cmdEnter"));
	      username.sendKeys("gspcatqauser1");
	      Thread.sleep(1000);
	      password.sendKeys("metlife1");
	      Thread.sleep(1000);
	      signIn.click();
	      WebElement caseID =driver.findElement(By.id("RFPID"));
	      Thread.sleep(2000);
	      String oppurnityID = "1-1F5MT1"; 
	      caseID.sendKeys(oppurnityID);
	      Thread.sleep(1000);
	      WebElement search =driver.findElement(By.id("SearchButtonIntUser"));
	      search.click();
	      Thread.sleep(2000);
	      WebElement edit =driver.findElement(By.id("editCustomer"));
	      edit.click();
	      Thread.sleep(500);
	      WebElement classSetupNav = driver.findElement(By.id("leftNavClassSetup"));
	      classSetupNav.click();
	      Thread.sleep(4000);
	      WebElement editAndReview = driver.findElement(By.id("btnClsTempEditReview2"));
	      editAndReview.click();
	      Thread.sleep(1000);	
	      JavascriptExecutor js = ((JavascriptExecutor)driver);
	      js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1000);
	      Thread.sleep(1000);
	      WebElement selectCheckbox = driver.findElement(By.id("chkClsSelect61_2_1"));
	      selectCheckbox.click();
	      js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1200);
	      Thread.sleep(1000);
	      WebElement noRadio = driver.findElement(By.id("rdnClassDisEligibilityWaitingPeriodExistNo2"));
	      noRadio.click();
	      Thread.sleep(1000);
	      List<WebElement> firstQuestion = driver.findElements(By.id("selectDisablityWaitingPeriodEffective2"));
	      if(firstQuestion.size()!=0)
	      {
	    	  System.out.println("First question is getting displayed after clicking on No");
	      }
	      else
	      {
	    	  System.out.println("First question is not getting displayed after clicking on No");
	      }
	      
	      List<WebElement> secondQuestion = driver.findElements(By.id("selectDisabilityNewHireWaitingPeriod2"));
	      if(secondQuestion.size()!=0)
	      {
	    	  System.out.println("Second question is getting displayed after clicking on No");
	      }
	      else
	      {
	    	  System.out.println("Second question is not getting displayed after clicking on No");
	      }
	      
	      List<WebElement> thirdQuestion = driver.findElements(By.id("selectDisabilityWaitingPeriodWaive2"));
	      if(thirdQuestion.size()!=0)
	      {
	    	  System.out.println("Third question is getting displayed after clicking on No");
	      }
	      else
	      {
	    	  System.out.println("Third question is not getting displayed after clicking on No");
	      }
	      Thread.sleep(1000);
	      WebElement closeButton = driver.findElement(By.id("closeBtn2"));
	      closeButton.click();
	      Thread.sleep(1000);
	      closeButton.click();
	      
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
	      
	}
	
}
