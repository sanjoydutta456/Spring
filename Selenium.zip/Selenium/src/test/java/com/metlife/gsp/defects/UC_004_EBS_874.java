package com.metlife.gsp.defects;

import static org.junit.Assert.fail;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UC_004_EBS_874 {

	@Test
	public void testDropdownText() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev.custadmin.metlife.com/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement username = driver.findElement(By.id("USER"));
        WebElement password = driver.findElement(By.id("PASSWORD"));
        WebElement signIn = driver.findElement(By.id("cmdEnter"));
        username.sendKeys("gspcatqauser1");
        Thread.sleep(1000);
        password.sendKeys("metlife1");
        Thread.sleep(1000);
        signIn.click();
        WebElement caseID =driver.findElement(By.id("RFPID"));
        Thread.sleep(2000);
        caseID.sendKeys("1-1F5MT1");
        Thread.sleep(1000);
        WebElement search =driver.findElement(By.id("SearchButtonIntUser"));
        search.click();
        Thread.sleep(2000);
        WebElement edit =driver.findElement(By.id("editCustomer"));
        edit.click();
        WebElement classSetupNav = driver.findElement(By.id("leftNavClassSetup"));
        classSetupNav.click();
        Thread.sleep(7000);
        WebElement addClass =driver.findElement(By.id("btnClsSetupAddClass"));
        addClass.click();
        Thread.sleep(2000);
        WebElement dentalTab =driver.findElement(By.id("Dental1"));
        dentalTab.click();
        Thread.sleep(1000);
        WebElement selectCheckbox = driver.findElement(By.id("chkClsSelect9999_1_1"));
        selectCheckbox.click();
        ((JavascriptExecutor)driver).executeScript("scroll(0,600)");
        Thread.sleep(4000);
        JavascriptExecutor js = ((JavascriptExecutor)driver);
        js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1100);
        Thread.sleep(1000);
        WebElement yesCheckBox = driver.findElement(By.id("rdnClassSetupStateListYes1"));
        yesCheckBox.click();
        Thread.sleep(2000);
        WebElement checkHiddenBlock = driver.findElement(By.id("divDentalEmployeeResideIn1"));
        boolean booleanValueOfStyle1AfterYes = checkHiddenBlock.isDisplayed();
        if(booleanValueOfStyle1AfterYes == true)
        {
        	System.out.println("List of states is getting displayed after click on yes");
        }
        WebElement noCheckBox = driver.findElement(By.id("rdnClassSetupStateListNo1"));
        noCheckBox.click();
        Thread.sleep(2000);
        boolean booleanValueOfStyle1AfterNo = checkHiddenBlock.isDisplayed();
        if(booleanValueOfStyle1AfterNo == false)
        {
        	System.out.println("List of states is not getting displayed after click on no");
        }
        else
        {
        	System.err.println("List of states is still getting displayed even after click on no");
        	Thread.sleep(3000);
            ((JavascriptExecutor)driver).executeScript("scroll(0, -400)");
            WebElement closeButton = driver.findElement(By.id("closeBtn1"));
            closeButton.click();
            Thread.sleep(1000);
            closeButton.click();
            Thread.sleep(1000);
            WebElement logOut = driver.findElement(By.id("logoutLink"));
            logOut.click();
            Thread.sleep(1000);
            WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
            yesButton.click();
            Thread.sleep(1000);
            driver.quit();
        	fail("List of states is still getting displayed even after click on no");
        }
        Thread.sleep(3000);
        ((JavascriptExecutor)driver).executeScript("scroll(0, -400)");
        WebElement closeButton = driver.findElement(By.id("closeBtn1"));
        closeButton.click();
        Thread.sleep(1000);
        closeButton.click();
        Thread.sleep(1000);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.quit();
        
	}
	
}
