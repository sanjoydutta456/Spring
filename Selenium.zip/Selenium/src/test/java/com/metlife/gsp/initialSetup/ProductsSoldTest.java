package com.metlife.gsp.initialSetup;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class ProductsSoldTest {
	
	@Test
	public void testProductsSold() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		//Writing URL
		driver.get("https://int.custadmin.metlife.com");
		Thread.sleep(2000);
		
		//Writing Username and Password
		WebElement user=driver.findElement(By.id("USER"));
		user.sendKeys("gspcatqauser1");
		Thread.sleep(2000);
		WebElement pass=driver.findElement(By.id("PASSWORD"));
		pass.sendKeys("metlife1");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("cmdEnter"));
		login.click();
		Thread.sleep(2000);
		driver.manage().window().maximize();

		
		//Search Page
		/*Select drp=new Select(driver.findElement(By.id("appStatus")));
		drp.selectByIndex(1);
		Thread.sleep(2000);
		WebElement searchBtn=driver.findElement(By.id("SearchButtonIntUser"));
		searchBtn.click();
		Thread.sleep(2000);
		*/
		
		//Search Page
		WebElement caseId=driver.findElement(By.id("RFPID"));
		caseId.sendKeys("1-1F5MT2");
		Thread.sleep(2000);
		WebElement searchBtn=driver.findElement(By.id("SearchButtonIntUser"));
		searchBtn.click();
		Thread.sleep(2000);
		WebElement editBtn=driver.findElement(By.id("editCustomer"));
		editBtn.click();
		
		//Dashboard Page
		WebElement productsSoldLink=driver.findElement(By.id("navDashProductsSold"));
		productsSoldLink.click();
		Thread.sleep(2000);
		
		//Product Information Page
		WebElement liferemove=driver.findElement(By.id("linkCovProductSold49"));
		liferemove.click();
		Thread.sleep(2000);
		WebElement lifepopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		lifepopup.click();
		Thread.sleep(2000);
		
		WebElement dentalremove=driver.findElement(By.id("linkCovProductSold9999"));
		dentalremove.click();
		Thread.sleep(2000);
		WebElement dentalpopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		dentalpopup.click();
		Thread.sleep(2000);
		
		WebElement disabilityltdremove=driver.findElement(By.id("linkCovProductSold60"));
		disabilityltdremove.click();
		Thread.sleep(2000);
		WebElement disabilitystdremove=driver.findElement(By.id("linkCovProductSold61"));
		disabilitystdremove.click();
		Thread.sleep(2000);
		WebElement disabilitystdpopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		disabilitystdpopup.click();
		Thread.sleep(2000);
		WebElement visionremove=driver.findElement(By.id("linkCovProductSold102"));
		visionremove.click();
		Thread.sleep(2000);
		WebElement visionpopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		visionpopup.click();
		Thread.sleep(2000);
		WebElement propertycasualtyremove=driver.findElement(By.id("linkCovProductSold207000"));
		propertycasualtyremove.click();
		Thread.sleep(2000);
		WebElement propertycasualtypopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		propertycasualtypopup.click();
		Thread.sleep(2000);
		WebElement legalservicesremove=driver.findElement(By.id("linkCovProductSold206000"));
		legalservicesremove.click();
		Thread.sleep(2000);
		WebElement atleastOneProduct=driver.findElement(By.id("btnRemoveWarninglogoutOK"));
		atleastOneProduct.click();
		Thread.sleep(2000);
		
		/*WebElement legalservicespopup=driver.findElement(By.id("btnRemoveRestoreWarningYes"));
		legalservicespopup.click();
		Thread.sleep(2000);*/
		
		WebElement liferestore=driver.findElement(By.id("linkCovProductSold49"));
		liferestore.click();
		Thread.sleep(2000);
		WebElement dentalrestore=driver.findElement(By.id("linkCovProductSold9999"));
		dentalrestore.click();
		Thread.sleep(2000);
		WebElement disabilityltdrestore=driver.findElement(By.id("linkCovProductSold60"));
		disabilityltdrestore.click();
		Thread.sleep(2000);
		WebElement disabilitystdrestore=driver.findElement(By.id("linkCovProductSold61"));
		disabilitystdrestore.click();
		Thread.sleep(2000);
		WebElement visionrestore=driver.findElement(By.id("linkCovProductSold102"));
		visionrestore.click();
		Thread.sleep(2000);
		WebElement propertycasualtyrestore=driver.findElement(By.id("linkCovProductSold207000"));
		propertycasualtyrestore.click();
		Thread.sleep(2000);
		
		//Log Out
		WebElement logout=driver.findElement(By.id("logoutLink"));
		logout.click();
		Thread.sleep(2000);
		WebElement popup=driver.findElement(By.id("btnlogoutYes"));
		popup.click();
		Thread.sleep(2000);
		
		//Window closed
		driver.quit();
		
		}

}
