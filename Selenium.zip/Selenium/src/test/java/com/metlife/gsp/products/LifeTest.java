package com.metlife.gsp.products;

import java.util.NoSuchElementException;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;

public class LifeTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	WebDriverWait myWaitVar = new WebDriverWait(driver,20);
        //driver.findElement(By.id("RFPID")).sendKeys("0062a000005vNSzAAM"); 
        driver.findElement(By.id("RFPID")).sendKeys("6-4A7ONV"); 
        
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.className("P10")).click();
        driver.manage().window().maximize();
        
        js.executeScript("scroll(0,1000)");
        if(driver.findElement(By.id("navDashLife")).isDisplayed()) {
        	driver.findElement(By.id("navDashLife")).click();
        }
        
        driver.findElement(By.id("rdnLifeProdSetIsReplacementCoverageYes")).click();
        
        //Table portion
        if(driver.findElement(By.id("txtBasicLifeEffectiveDate0")).isDisplayed()) {
        	driver.findElement(By.id("txtBasicLifeEffectiveDate0")).clear();
        	driver.findElement(By.id("txtBasicLifeEffectiveDate0")).sendKeys("12/12/2019");
        }
        
        if(driver.findElement(By.id("txtProdLifeBasicLifePayment0")).isDisplayed()) {
        	driver.findElement(By.id("txtProdLifeBasicLifePayment0")).clear();
            driver.findElement(By.id("txtProdLifeBasicLifePayment0")).sendKeys("1200");
        }
        
        //Employees not actively at Work
        if(driver.findElement(By.id("rdnLifeProdSetEmpWorkYes")).isDisplayed()) {
        	driver.findElement(By.id("rdnLifeProdSetEmpWorkYes")).click();
        }
        
        if(driver.findElement(By.id("addEmpWork")).isDisplayed()) {
        	driver.findElement(By.id("addEmpWork")).click();
        	driver.findElement(By.id("btnProdLifeEmpSave3")).click();
        	Assert.assertTrue(driver.findElement(By.id("errMandField3")).isDisplayed());
        	
        	driver.findElement(By.id("txtLifeProdSetFirstName3")).clear();
            driver.findElement(By.id("txtLifeProdSetFirstName3")).sendKeys("rajarshi");
            
            driver.findElement(By.id("txtLifeProdSetLastName3")).clear();
            driver.findElement(By.id("txtLifeProdSetLastName3")).sendKeys("bhattacharya");
            
            driver.findElement(By.id("txtLifeProdSetReason3")).clear();
            driver.findElement(By.id("txtLifeProdSetReason3")).sendKeys("testing");
            
            driver.findElement(By.id("btnProdLifeEmpCancel3")).click();
            
            Assert.assertTrue(driver.findElement(By.id("divCancelMsg3")).isDisplayed());
            
            driver.findElement(By.id("btnProdLifeEmpSave3")).click();
        }
        
        
        System.out.println("Test case 1 for SM and SM & LT1000 passed");
        
        
        
        if(driver.findElement(By.id("selectDisabilityEffectiveDateSal")).isDisplayed()) {
        
        driver.findElement(By.id("selectDisabilityEffectiveDateSal")).click();
        Select date =new Select(driver.findElement(By.id("selectDisabilityEffectiveDateSal")));
        date.selectByVisibleText("Date of Change");
        
        driver.findElement(By.id("enrollmentStartDtdriver")).click();
        driver.findElement(By.id("enrollmentStartDtdriver")).sendKeys("01/16/2019");
        
        driver.findElement(By.id("rdnSupplementalOtherExplain")).click();
        
        driver.findElement(By.id("txtdivOthers")).click();
        driver.findElement(By.id("txtdivOthers")).sendKeys("testing");
        
        driver.findElement(By.id("chkAdoption")).click();
        
        driver.findElement(By.id("chkOther")).click();
        if(driver.findElement(By.id("txtLifeQualifyingTextBox")).isDisplayed()) {
        	driver.findElement(By.id("txtLifeQualifyingTextBox")).sendKeys("abcdefghijkl");
        }
        
        driver.findElement(By.id("grandFatheredCoverageNo")).click();
        driver.findElement(By.id("grandFatheredYes")).click();
        
        if(driver.findElement(By.id("txtExplainForempOrClassesficaExempt")).isDisplayed()) {
        	driver.findElement(By.id("txtExplainForempOrClassesficaExempt")).sendKeys("jayatasree");
        }
        
        driver.findElement(By.id("rdnCopyofForms")).click();
        driver.findElement(By.id("rdnOriginalForms")).click();
        
        driver.findElement(By.id("rdnFederalTaxClaim")).click();
        driver.findElement(By.id("rdnFederalTaxRequested")).click();
        
        driver.findElement(By.id("rdnOtherExplain")).click();
        if(driver.findElement(By.id("txtdivOthers")).isDisplayed()) {
        	driver.findElement(By.id("txtdivOthers")).sendKeys("12/12/2000");
        }
        
        //Who should receive evidence of insurability reports?
        
        driver.findElement(By.id("txtInsurabilityReportFirstName")).clear();
        driver.findElement(By.id("txtInsurabilityReportFirstName")).sendKeys("jaya");
        
        driver.findElement(By.id("txtInsurabilityReportLastName")).clear();
        driver.findElement(By.id("txtInsurabilityReportLastName")).sendKeys("ganguly");
        
        driver.findElement(By.id("txtInsurabilityReportPhoneNumber")).clear();
        driver.findElement(By.id("txtInsurabilityReportPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtInsurabilityReportExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errInsurabilityReportPhoneNumber")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("txtInsurabilityReportPhoneNumber")).clear();
        driver.findElement(By.id("txtInsurabilityReportPhoneNumber")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtInsurabilityReportExt")).clear();
        driver.findElement(By.id("txtInsurabilityReportExt")).sendKeys("123456");
        
        driver.findElement(By.id("txtInsurabilityReportEmailAddress")).clear();
        driver.findElement(By.id("txtInsurabilityReportEmailAddress")).sendKeys("abc.com");
        driver.findElement(By.id("txtInsurabilityReportExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errInsurabilityReportEmailAddress")).isDisplayed());
        driver.findElement(By.id("txtInsurabilityReportEmailAddress")).clear();
        driver.findElement(By.id("txtInsurabilityReportEmailAddress")).sendKeys("abc@gmail.com");
        
        //Who is contact for life claims?
        
        driver.findElement(By.id("txtClaimContactFirstName")).clear();
        driver.findElement(By.id("txtClaimContactFirstName")).sendKeys("sayani");
        
        driver.findElement(By.id("txtClaimContactLastName")).clear();
        driver.findElement(By.id("txtClaimContactLastName")).sendKeys("basak");
        
        driver.findElement(By.id("txtClaimContactPhoneNumber")).clear();
        driver.findElement(By.id("txtClaimContactPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtLifeClaimExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errClaimContactPhoneNumber")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("txtClaimContactPhoneNumber")).clear();
        driver.findElement(By.id("txtClaimContactPhoneNumber")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtLifeClaimExt")).clear();
        driver.findElement(By.id("txtLifeClaimExt")).sendKeys("123456");
        
        driver.findElement(By.id("txtClaimContactEmailAddress")).clear();
        driver.findElement(By.id("txtClaimContactEmailAddress")).sendKeys("abc.com");
        driver.findElement(By.id("txtLifeClaimExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errClaimContactEmailAddress")).isDisplayed());
        driver.findElement(By.id("txtClaimContactEmailAddress")).clear();
        driver.findElement(By.id("txtClaimContactEmailAddress")).sendKeys("abc@gmail.com");
        
        driver.findElement(By.id("txtBeneficiaryClaimPhoneNumber")).clear();
        driver.findElement(By.id("txtBeneficiaryClaimPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtLifeClaimExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errBeneficiaryClaimPhoneNumber")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("txtBeneficiaryClaimPhoneNumber")).clear();
        driver.findElement(By.id("txtBeneficiaryClaimPhoneNumber")).sendKeys("1234567890");
        
        //travel assistance
        
        driver.findElement(By.id("txtEligibilityContactFirstName")).clear();
        driver.findElement(By.id("txtEligibilityContactFirstName")).sendKeys("amit");
        
        driver.findElement(By.id("txtEligibilityContactLastName")).clear();
        driver.findElement(By.id("txtEligibilityContactLastName")).sendKeys("dhara");
        
        driver.findElement(By.id("txtEligibilityContactPhoneNumber")).clear();
        driver.findElement(By.id("txtEligibilityContactPhoneNumber")).sendKeys("1234");
        driver.findElement(By.id("txtEligibilityContactExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errEligibilityContactPhoneNumber")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("txtEligibilityContactPhoneNumber")).clear();
        driver.findElement(By.id("txtEligibilityContactPhoneNumber")).sendKeys("1234567890");
        
        driver.findElement(By.id("txtEligibilityContactExt")).clear();
        driver.findElement(By.id("txtEligibilityContactExt")).sendKeys("123456");
        
        driver.findElement(By.id("txtEligibilityContactEmailAddress")).clear();
        driver.findElement(By.id("txtEligibilityContactEmailAddress")).sendKeys("abc.com");
        driver.findElement(By.id("txtLifeClaimExt")).click();
        Assert.assertTrue(driver.findElement(By.id("errEligibilityContactEmailAddress")).isDisplayed());
        driver.findElement(By.id("txtEligibilityContactEmailAddress")).clear();
        driver.findElement(By.id("txtEligibilityContactEmailAddress")).sendKeys("abc@gmail.com");
        
        
        System.out.println("Test case 2 for GT1000 passed");
        }
        
        else{
        		driver.findElement(By.id("btnLifeSave")).click();
        	
        
        	driver.findElement(By.id("logoutLink")).click();
        	if(driver.findElement(By.id("logoutOverlay")).isDisplayed()) {
        		driver.findElement(By.id("btnlogoutYes")).click();
        	}
    	}
    }
}
