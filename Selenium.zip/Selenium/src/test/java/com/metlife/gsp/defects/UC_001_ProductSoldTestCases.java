package com.metlife.gsp.defects;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class UC_001_ProductSoldTestCases {

	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    public void searchOpportunity() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"editCustomer\"]"))).click();
		
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
    	
    	WebDriverWait wait = new WebDriverWait(driver,60);
        JavascriptExecutor js = (JavascriptExecutor)driver;
    	driver.findElement(By.id("RFPID")).sendKeys("1-1F5MS1"); 
        searchOpportunity();
    	Thread.sleep(1000);
    	
    	
    	driver.findElement(By.id("leftNavInitialSetupInfo")).click();
    	Thread.sleep(1000);
    
    	Assert.assertTrue("Product Sold does not exist", driver.findElement(By.id("productSoldTab")).isDisplayed());
    	Thread.sleep(1000);
    	driver.manage().window().maximize();
    	driver.findElement(By.id("productSoldTab")).click();
    	Assert.assertTrue(driver.findElement(By.id("customerHeaderOverlay")).isDisplayed());
    	driver.findElement(By.id("btnCustomerHeaderNo")).click();
    	Thread.sleep(2000);
    	// Defect - 39454 (Test Case 1) --> Check whether the product link is disabled if the product is removed
    	driver.findElement(By.id("linkCovProductSold61")).click();
    	Thread.sleep(2000);
    	Assert.assertTrue("This product link is not present", driver.findElement(By.id("navProductSold61")).isDisplayed());
    	Thread.sleep(1500);
    	try{
    		
			driver.findElement(By.id("navProductSold61")).click();
			System.out.println("Test Case 1 failed");
			
    	}
    	catch(Exception e)
    	{
    		System.out.println("Product link not clickable");
    		System.out.println("Test Case 1 passed");
    	}	
    	
    	Thread.sleep(1500);
    	// Defect - 39454 (Test Case 2) --> Check whether the product link is disabled if the product is removed and popup appears if it is the last coverage of the product
    	driver.findElement(By.id("linkCovProductSold60")).click();
    	Thread.sleep(2000);
    	Assert.assertTrue(driver.findElement(By.id("divRemResCovWarningOverlay")).isDisplayed());
    	driver.findElement(By.id("btnRemoveRestoreWarningYes")).click();
    	Assert.assertTrue("This product link is not present", driver.findElement(By.id("navProductSold60")).isDisplayed());
    	Thread.sleep(1500);
    	try{
    		
    			driver.findElement(By.id("navProductSold60")).click();
    			System.out.println("Test Case 2 failed");
    			
    	}
    	catch(Exception e)
    	{
    		System.out.println("Pop up appeared.Product link not clickable");
    		System.out.println("Test Case 2 passed");
    	}	
 
    	Thread.sleep(1000);
    	
    	// Defect - 39454 (Test Case 2) --> Check whether popup appears when all the products are removed
    	Assert.assertTrue(driver.findElement(By.id("linkCovProductSold9999")).isDisplayed());
    	driver.findElement(By.id("linkCovProductSold9999")).click();
    	Thread.sleep(1000);
    	Assert.assertTrue(driver.findElement(By.id("linkCovProductSold49")).isDisplayed());
    	driver.findElement(By.id("linkCovProductSold49")).click();
    	Thread.sleep(1000);
    	Assert.assertTrue("Popup not appearing. Test Case 1 failed.",driver.findElement(By.id("popup_login")).isDisplayed());
    	driver.findElement(By.id("btnRemoveWarninglogoutOK")).click();
    	Thread.sleep(1500);
    	Assert.assertTrue(driver.findElement(By.id("linkCovProductSold49")).isDisplayed());
    	System.out.println("Test Case 1 passed");
    	Thread.sleep(1500);
    	driver.findElement(By.id("linkCovProductSold9999")).click();
    	Thread.sleep(1500);
    	driver.findElement(By.id("linkCovProductSold60")).click();
    	Thread.sleep(1500);
    	driver.findElement(By.id("linkCovProductSold61")).click();
    	Thread.sleep(1000);
    	driver.findElement(By.id("logoutLink")).click();
    	Thread.sleep(1000);
    	Assert.assertTrue(driver.findElement(By.id("logoutOverlay")).isDisplayed());
    	driver.findElement(By.id("btnlogoutYes")).click();
    	driver.quit();
    	
    }
}
