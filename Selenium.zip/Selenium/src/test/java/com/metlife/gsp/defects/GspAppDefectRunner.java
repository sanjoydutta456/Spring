package com.metlife.gsp.defects;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import com.metlife.gsp.GspAppSeleniumTest.GSPTestSuite;
import com.metlife.gsp.defects.GspAppDefectTest.GSPDefectTestSuite;


public class GspAppDefectRunner {

		  public static void main(String[] args) {
		    Result result = JUnitCore.runClasses(GSPDefectTestSuite.class);
		    for (Failure failure : result.getFailures()) {
		      System.out.println(failure.toString());
		    }
		    System.out.println("Was Successful.?"+result.wasSuccessful());
		    System.out.println("Total Run Count : "+result.getRunCount());	            
		  }
		  
}
