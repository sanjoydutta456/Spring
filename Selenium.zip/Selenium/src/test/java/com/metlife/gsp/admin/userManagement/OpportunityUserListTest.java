package com.metlife.gsp.admin.userManagement;

import java.util.NoSuchElementException;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

import com.metlife.gsp.login.Login_INT;


public class OpportunityUserListTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException {
        
        driver.findElement(By.id("RFPID")).sendKeys("6-4A7ONV"); 
        driver.findElement(By.id("SearchButtonIntUser")).click();
        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.className("P10")).click();
        driver.findElement(By.id("leftNavAdminInfo")).click();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Test case 1 to add user of new contact without fill up
        JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("scroll(0,1000)");
		Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"addUserOppList\"]")).click();
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        System.out.println("adding user");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"rdnUserNewContact\"]")).click();
        /*driver.findElement(By.id("rdnUserNewContact")).click();*/
        /*driver.findElement(By.className("dijitReset dijitCheckBoxInput")).click();*/
        
        /*driver.findElement(By.id("btnAddNewUser")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        System.out.println("Test case");
        Assert.assertTrue(driver.findElement(By.xpath("//*[@id=\"errMandNewUserFields\"]")).isDisplayed());
        System.out.println("Test case 1 passed");*/
        
       //Test case 2 to add user of new contact after fill up
        driver.findElement(By.id("txtNewUserFirstName")).sendKeys("sayni");
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserLastName")).sendKeys("das");
        Thread.sleep(2000);
        driver.findElement(By.id("txtNewUserEmailId")).sendKeys("jayatasreecom");
        Thread.sleep(2000);
        driver.findElement(By.id("txtNewUserLastName")).click();
        Assert.assertTrue(driver.findElement(By.id("errAddNewUserEmail")).isDisplayed());
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserEmailId")).clear();
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserEmailId")).sendKeys("sayaniiii@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("selectNewUserType")).click();
        Select user =new Select(driver.findElement(By.id("selectNewUserType")));
        Thread.sleep(2000);
        user.selectByVisibleText("Customer");
        Thread.sleep(1000);
        driver.findElement(By.id("btnAddNewUser")).click();
        Assert.assertTrue(driver.findElement(By.id("adminAddUserOverlay")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("adminAddUserOverlayYes")).click();
        //Assert.assertTrue(driver.findElement(By.id("divSoapFaultForUser")).isDisplayed());
        System.out.println("Test case 2 passed");
        Thread.sleep(2000);
        driver.findElement(By.id("btnReturnToAddUserList")).click();
        
        //Test case 3 to add existing user
        Thread.sleep(1000);
        driver.findElement(By.id("addUserOppList")).click();
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(2000);
        driver.findElement(By.id("rdnUserExistingContact")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("selectAdminExistingContact")).click();
        Select existingUser =new Select(driver.findElement(By.id("selectAdminExistingContact")));
        Thread.sleep(1000);
        existingUser.selectByVisibleText("adasd asdasfd");
        Thread.sleep(1000);
        driver.findElement(By.id("btnAddExistingUser")).click();
        Assert.assertTrue(driver.findElement(By.id("adminAddUserOverlay")).isDisplayed());
        Thread.sleep(2000);
        driver.findElement(By.id("adminAddUserOverlayYes")).click();
        Thread.sleep(2000);
        Assert.assertTrue(driver.findElement(By.id("divSoapFaultForUser")).isDisplayed());
        System.out.println("Test case 3 passed");
        driver.findElement(By.id("btnReturnToAddUserList")).click();
        
         //test case 4 update user
        Thread.sleep(1000);
        driver.findElement(By.id("userList0")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("updateUserAdmin")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserFirstName")).clear();
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserLastName")).clear();
        Thread.sleep(1000);
        /*driver.findElement(By.id("btnAdminUpdateUser")).click();*/
        /*Assert.assertTrue(driver.findElement(By.id("errMandNewUserFields")).isDisplayed());*/
       
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserFirstName")).sendKeys("asgad");
        Thread.sleep(1000);
        driver.findElement(By.id("txtNewUserLastName")).sendKeys("pal");
        Thread.sleep(1000);
        driver.findElement(By.id("btnAdminUpdateUser")).click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.findElement(By.id("displaySuccessMsg")).isDisplayed());
        System.out.println("Test case 4 passed");
        Thread.sleep(1000);
        driver.findElement(By.id("btnRtnToAddUserListFrmUpdateUser")).click();
        
        //test case 5 send email
        Thread.sleep(1000);
        driver.findElement(By.id("userList0")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("sendEmailAdmin")).click();
        Thread.sleep(1000);
        driver.findElement(By.id("btnEmailPasswordLinkAdmin")).click();
        Thread.sleep(1000);
        //Assert.assertTrue(driver.findElement(By.id("divSoapFaultForSendEmail")).isDisplayed());
        System.out.println("Test case 5 passed");
        
      //test case 6
        Thread.sleep(2000);
        //driver.findElement(By.id("btnCompleteProfileEmail")).click();
        Assert.assertTrue(driver.findElement(By.id("errPwdEmailSentErr")).isDisplayed());
        System.out.println("Test case 6 passed");
        Thread.sleep(2000);
    	driver.findElement(By.id("logoutLink")).click();
    	Assert.assertTrue(driver.findElement(By.id("viewLogoutOverlay")).isDisplayed());
        driver.findElement(By.id("btnlogoutViewYes")).click();
        driver.close();
       
        
    } 
    
    
    

}
