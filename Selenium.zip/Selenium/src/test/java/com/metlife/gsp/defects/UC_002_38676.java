package com.metlife.gsp.defects;

import static org.junit.Assert.assertTrue;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

public class UC_002_38676 {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

    
    @Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

    	int custEligableLifeInt = 0;
		WebElement oppID = driver.findElement(By.id("RFPID"));
		//Dev
		oppID.sendKeys("1-4AEFQP"); 
		//QA
		//oppID.sendKeys("1-5CVVKI");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		driver.manage().window().maximize();
		
		try {
			WebElement cutomerInformationLink = driver.findElement(By.id("navDashCustInfo"));
			if (cutomerInformationLink.isDisplayed()) {
				cutomerInformationLink.click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				String custEligableLife = driver.findElement(By.id("txtCustEligibleEmployees")).getAttribute("value");
				custEligableLifeInt = Integer.parseInt(custEligableLife);
			}
			Thread.sleep(1000);
			
			driver.findElement(By.id("breadcrumbToProduct")).click();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.findElement(By.id("btnBreadcrumbNo")).click();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			
			if (driver.findElement(By.id("generalProdInfoTab")).isDisplayed()) {
				assertTrue(driver.findElement(By.id("generalProdInfoTab")).isDisplayed());
			}
			Thread.sleep(1000);
			
			boolean isDomesticPatnerCover = driver.getPageSource().contains("Are Domestic Partners covered for any coverage");
			if(isDomesticPatnerCover){
				System.out.println("Testcase Pass");
			}else{
				System.out.println("Testcase Fail");
			}
			Thread.sleep(1000);
		}catch(Exception e) {
			System.out.println("Exception :- "+ e);
		}
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
	}

}
