package com.metlife.gsp.defects;

import static org.junit.Assert.assertTrue;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

public class UC_002_39192 {
	
	private WebDriver driver;
    private Login_DEV login;
	
    @Before
    public void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

    
    @Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {

		//JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-4AEFQP");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		
		//WebElement generalProductInformationLink = driver.findElement(By.xpath("//*[@id=\"navDashGeneralProductInfo\"]"));
		WebElement generalProductInformationLink = driver.findElement(By.id("navDashGeneralProductInfo"));
		if (generalProductInformationLink.isDisplayed()) {
			generalProductInformationLink.click();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			assertTrue(driver.findElement(By.id("generalProdInfoTab")).isDisplayed());
		}
				
		driver.manage().window().maximize();
		Thread.sleep(2000);
        //js.executeScript("window.scrollBy(0,1000);");
		try {
			//WebElement dependentCovered = driver.findElement(By.xpath("//*[@id=\"divGeneralProductInfo\"]/div/div/div[1]/div[14]/div[1]/div/div[2]"));
			boolean result = driver.getPageSource().contains("Are Dependents being covered");
			if(result){
				System.out.println("Test case Pass");
			}else{
				System.out.println("Test case Fail");
			}
			Thread.sleep(2000);
		}catch(Exception e) {
			System.out.println("Exception :- "+ e);
		}
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
	}

}
