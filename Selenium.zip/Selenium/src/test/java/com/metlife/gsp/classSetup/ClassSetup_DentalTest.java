package com.metlife.gsp.classSetup;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;
public class ClassSetup_DentalTest {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("4-4A7ONV");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		
		driver.manage().window().maximize();
		
		
		//WebElement classSetupInformationLink = driver.findElement(By.id("navDashClass"));
		//if (classSetupInformationLink.isDisplayed()) {
			//classSetupInformationLink.click();
			//assertTrue(driver.findElement(By.id("divClassSetupContent")).isDisplayed());
			//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//}
		
		driver.findElement(By.id("navDashClass")).click();
		
		Thread.sleep(9000);
		
		//driver.findElement(By.id("btnClsSetupAddClass")).click();
		//driver.findElement(By.id("btnClsSetupAddClass")).click();
		WebElement addClass = driver.findElement(By.id("btnClsSetupAddClass"));
		if(addClass.isDisplayed()) {
			addClass.click();
			Thread.sleep(300);
			
		}
		//driver.findElement(By.xpath("//*[@id=\"btnClsSetupAddClass\"]")).click();
		
		Thread.sleep(500);
		
		Select classDescription = new Select(driver.findElement(By.id("selectClsDesc9")));
		classDescription.selectByIndex(19);
		Thread.sleep(100);
		driver.findElement(By.id("txtClsTempClassDescription9")).clear();
		driver.findElement(By.id("txtClsTempClassDescription9")).sendKeys("CCD");
		
		driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes9")).click();
		Thread.sleep(300);
		
		driver.findElement(By.id("rdnClsTempOpenClass9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass9")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass9")).sendKeys("OOO");
		driver.findElement(By.id("rdnClsTempClosedClass9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass9")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass9")).sendKeys("CCC");
		Thread.sleep(600);
		
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
		Thread.sleep(500);
		driver.findElement(By.id("Dental9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("chkClsSelect9999_9_1")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsDentNumOfEmpEligMultiOptioDent_9_1")).clear();
		driver.findElement(By.id("txtClsDentNumOfEmpEligMultiOptioDent_9_1")).sendKeys("1");
		Thread.sleep(500);
		driver.findElement(By.id("txtClsDentEmpContEmpMultiOptioDent_9_1")).clear();
		driver.findElement(By.id("txtClsDentEmpContEmpMultiOptioDent_9_1")).sendKeys("2");
		Thread.sleep(500);
		driver.findElement(By.id("txtClsDentPartialContributionMultiOptioDent_9_1")).clear();
		driver.findElement(By.id("txtClsDentPartialContributionMultiOptioDent_9_1")).sendKeys("3");
		Thread.sleep(500);
		driver.findElement(By.id("txtClsDentEmpContDepenMultiOptioDent_9_1")).clear();
		driver.findElement(By.id("txtClsDentEmpContDepenMultiOptioDent_9_1")).sendKeys("4");
		Thread.sleep(500);
		
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),800);
		
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnClassDentalEligibiltyWaitPeriodNo9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClassDentalEligibiltyWaitPeriodYes9")).click();
		Thread.sleep(500);
		
		Select benefitsEffective = new Select(driver.findElement(By.id("selectDentalNewHirePolicyBenefitsEffDate9")));
		benefitsEffective.selectByIndex(9);
		Thread.sleep(100);
		driver.findElement(By.id("otherDentalEffDateBtn9")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("/html/body/div[9]/div/div[3]/ul[2]/li[4]/div")).click();
		
		
		
		Select waitingPeriod = new Select(driver.findElement(By.id("selectDentalNewHireWaitingPeriod9")));
		waitingPeriod.selectByIndex(8);
		Thread.sleep(200);
		driver.findElement(By.id("txtClsDentalEnterWaitperiod9")).clear();
		driver.findElement(By.id("txtClsDentalEnterWaitperiod9")).sendKeys("6 months");
		
		
		
		// for eli=1035 
		 
		 
		  Select effectiveOn = new Select(driver.findElement(By.id("selectDentalNewHirePolicyEffDate9")));
		effectiveOn.selectByIndex(2);
		Thread.sleep(300);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1400);
		Thread.sleep(500);
		
		Select employmentEnd = new Select(driver.findElement(By.id("selectDentalClassEmploymentEnds9")));
		employmentEnd.selectByIndex(4);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivEmploymentEndsOther9")).clear();
		driver.findElement(By.id("txtDentaldivEmploymentEndsOther9")).sendKeys("employmentEnd");;
		Thread.sleep(500);
		
		Select eligibleClass = new Select(driver.findElement(By.id("selectDentalClassEligibleClassDate9")));
		eligibleClass.selectByIndex(4);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivEligibleClassDateOther9")).clear();
		driver.findElement(By.id("txtDentaldivEligibleClassDateOther9")).sendKeys("eligibleClass");;
		Thread.sleep(500);
		
		Select retirement = new Select(driver.findElement(By.id("selectDentalRetirement9")));
		retirement.selectByIndex(4);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivRetirementOther9")).clear();
		driver.findElement(By.id("txtDentaldivRetirementOther9")).sendKeys("retirement");;
		Thread.sleep(500);
		
		Select limitingAge = new Select(driver.findElement(By.id("selectDentalDependentLimitingAge9")));
		limitingAge.selectByIndex(4);
		Thread.sleep(100);
		driver.findElement(By.id("txtdivDentalDependentLimitingAgeOther9")).clear();
		driver.findElement(By.id("txtdivDentalDependentLimitingAgeOther9")).sendKeys("limitingAge");;
		Thread.sleep(500);
		
		Select noLonger = new Select(driver.findElement(By.id("selectDentalDependentNotMetDefinition9")));
		noLonger.selectByIndex(4);
		Thread.sleep(100);
		driver.findElement(By.id("txtdivDentalDependentNotMetDefinitionOther9")).clear();
		driver.findElement(By.id("txtdivDentalDependentNotMetDefinitionOther9")).sendKeys("noLonger");;
		Thread.sleep(500);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1100);
		Thread.sleep(500);
		
		Select qualifyingEvents = new Select(driver.findElement(By.id("selectDentalIncludedQualifyingEvents9")));
		qualifyingEvents.selectByIndex(2);
		Thread.sleep(300);
		
		driver.findElement(By.id("chkDentalApplyChangesToAll9")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("txtClsTempHoursWorkedDental9")).clear();
		driver.findElement(By.id("txtClsTempHoursWorkedDental9")).sendKeys("4");
		Thread.sleep(400);
		
		Select payPeriod = new Select(driver.findElement(By.id("selectClsTempPayPeriodDental9")));
		payPeriod.selectByIndex(2);
		Thread.sleep(300);
		
		driver.findElement(By.id("rdnContinuationOfCoverageNoDental9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnContinuationOfCoverageYesDental9")).click();
		Thread.sleep(500);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),2000);
		Thread.sleep(1000);
		driver.findElement(By.id("chkLeaveOfAbsenceDental9")).click();
		driver.findElement(By.id("btnLeaveOfAbsenceDental9")).click();
		driver.findElement(By.xpath("/html/body/div[10]/div/div[3]/ul[2]/li[4]/div")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("chkInjuryOrSicknessDental9")).click();
		driver.findElement(By.id("btnInjuryOrSicknessDental9")).click();
		driver.findElement(By.xpath("/html/body/div[11]/div/div[3]/ul[2]/li[4]/div")).click();
		Thread.sleep(500);
		
		
		driver.findElement(By.xpath("//*[@id=\"chkPartTimeStatusDental9\"]")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//*[@id=\"btnPartTimeStatusDental9\"]")).click();
		driver.findElement(By.xpath("/html/body/div[12]/div/div[3]/ul[2]/li[4]/div")).click();
		Thread.sleep(500);
		
		
		driver.findElement(By.id("chkLayoffDental9")).click();
		driver.findElement(By.id("btnLayoffDental9")).click();
		driver.findElement(By.xpath("/html/body/div[13]/div/div[3]/ul[2]/li[4]/div")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("chkStrikeDental9")).click();
		driver.findElement(By.id("btnStrikeDental9")).click();
		driver.findElement(By.xpath("/html/body/div[14]/div/div[3]/ul[2]/li[4]/div")).click();
		Thread.sleep(500);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1000);
		Thread.sleep(400);
		
		driver.findElement(By.id("rdnClassSetupStateListNo9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClassSetupStateListYes9")).click();
		Thread.sleep(300);
		//driver.findElement(By.id("chkDentalMississippi9")).click();
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divDentalEmployeeResideIn9")),400);
		driver.findElement(By.xpath("//*[@id=\"chkDentalnewMexico9\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"chkDentalnewMexico9\"]")).click();
		Thread.sleep(300);
		
		driver.findElement(By.id("txtClsTempAddComments9")).clear();
		driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("Good Job");
		
		
		  
		  
		 
		 
		
		
		
		
		
		
		
		/* for eli=135
		Select effectiveOn = new Select(driver.findElement(By.id("selectDentalNewHirePolicyEffDate9")));
		effectiveOn.selectByIndex(2);
		Thread.sleep(300);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1400);
		Thread.sleep(500);
		
		Select employmentEnd = new Select(driver.findElement(By.id("selectDentalClassEmploymentEnds9")));
		employmentEnd.selectByIndex(3);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivEmploymentEndsOther9")).clear();
		driver.findElement(By.id("txtDentaldivEmploymentEndsOther9")).sendKeys("employmentEnd");;
		Thread.sleep(500);
		
		Select eligibleClass = new Select(driver.findElement(By.id("selectDentalClassEligibleClassDate9")));
		eligibleClass.selectByIndex(3);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivEligibleClassDateOther9")).clear();
		driver.findElement(By.id("txtDentaldivEligibleClassDateOther9")).sendKeys("eligibleClass");;
		Thread.sleep(500);
		
		Select retirement = new Select(driver.findElement(By.id("selectDentalRetirement9")));
		retirement.selectByIndex(3);
		Thread.sleep(100);
		driver.findElement(By.id("txtDentaldivRetirementOther9")).clear();
		driver.findElement(By.id("txtDentaldivRetirementOther9")).sendKeys("retirement");;
		Thread.sleep(500);
		
		Select limitingAge = new Select(driver.findElement(By.id("selectDentalDependentLimitingAge9")));
		limitingAge.selectByIndex(3);
		Thread.sleep(100);
		driver.findElement(By.id("txtdivDentalDependentLimitingAgeOther9")).clear();
		driver.findElement(By.id("txtdivDentalDependentLimitingAgeOther9")).sendKeys("limitingAge");;
		Thread.sleep(500);
		
		Select noLonger = new Select(driver.findElement(By.id("selectDentalDependentNotMetDefinition9")));
		noLonger.selectByIndex(3);
		Thread.sleep(100);
		driver.findElement(By.id("txtdivDentalDependentNotMetDefinitionOther9")).clear();
		driver.findElement(By.id("txtdivDentalDependentNotMetDefinitionOther9")).sendKeys("noLonger");;
		Thread.sleep(500);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1100);
		Thread.sleep(500);
		
		Select qualifyingEvents = new Select(driver.findElement(By.id("selectDentalIncludedQualifyingEvents9")));
		qualifyingEvents.selectByIndex(2);
		Thread.sleep(300);
		
		driver.findElement(By.id("chkDentalApplyChangesToAll9")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("txtClsTempHoursWorkedDental9")).clear();
		driver.findElement(By.id("txtClsTempHoursWorkedDental9")).sendKeys("4");
		Thread.sleep(400);
		
		
		
		driver.findElement(By.id("rdnClassSetupStateListNo9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClassSetupStateListYes9")).click();
		Thread.sleep(300);
		//driver.findElement(By.id("chkDentalMississippi9")).click();
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),400);
		driver.findElement(By.xpath("//*[@id=\"chkDentalUtah9\"]")).click();
		Thread.sleep(300);
		
		driver.findElement(By.id("txtClsTempAddComments9")).clear();
		driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("Good Job");
		
		*/
		
		
		
		
		
		
    }
}
