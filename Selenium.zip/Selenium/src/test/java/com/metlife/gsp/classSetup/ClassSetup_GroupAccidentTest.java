package com.metlife.gsp.classSetup;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class ClassSetup_GroupAccidentTest {
	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }

    @Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException, InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("4-4A7ONV");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();
		
		driver.manage().window().maximize();
		
driver.findElement(By.id("navDashClass")).click();
		
		Thread.sleep(8000);
		
		WebElement addClass = driver.findElement(By.id("btnClsSetupAddClass"));
		if(addClass.isDisplayed()) {
			addClass.click();
			Thread.sleep(300);
			
		}
		
		Select classDescription = new Select(driver.findElement(By.id("selectClsDesc9")));
		classDescription.selectByIndex(19);
		Thread.sleep(100);
		driver.findElement(By.id("txtClsTempClassDescription9")).clear();
		driver.findElement(By.id("txtClsTempClassDescription9")).sendKeys("CCD");
		
		driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes9")).click();
		Thread.sleep(300);
		
		driver.findElement(By.id("rdnClsTempOpenClass9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass9")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass9")).sendKeys("OOO");
		driver.findElement(By.id("rdnClsTempClosedClass9")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass9")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass9")).sendKeys("CCC");
		Thread.sleep(600);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
		
		driver.findElement(By.id("vbTab")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("GroupAccident9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("chkClsSelect406000_9_0")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("txtClassGrpAcntNumEmpEligible_9_0")).clear();
		driver.findElement(By.id("txtClassGrpAcntNumEmpEligible_9_0")).sendKeys("1");;
		Thread.sleep(500);
		
		driver.findElement(By.id("txtClassGrpAcntEmployerContEmp_9_0")).clear();
		driver.findElement(By.id("txtClassGrpAcntEmployerContEmp_9_0")).sendKeys("2");;
		Thread.sleep(500);
		
		driver.findElement(By.id("txtClassGrpAcntPartialContribution_9_0")).clear();
		driver.findElement(By.id("txtClassGrpAcntPartialContribution_9_0")).sendKeys("3");;
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnClassExpatriatesImpatriatesGANo9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnClassExpatriatesImpatriatesGAYes9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnClassSetGroupAccidentNo9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnClassSetGroupAccidentYes9")).click();
		Thread.sleep(500);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);

		
		driver.findElement(By.id("txtClsTempHoursWorkedGroupAcc9")).clear();
		driver.findElement(By.id("txtClsTempHoursWorkedGroupAcc9")).sendKeys("5");
		
		
		//for eli=1035
		/*
		
		Select payPeriod = new Select(driver.findElement(By.id("selectClsTempPayPeriodGroupAcc9")));
		payPeriod.selectByIndex(2);
		Thread.sleep(300);
		
		driver.findElement(By.id("rdnArePartTimeEmpCoveredGroupAccNo9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnArePartTimeEmpCoveredGroupAccYes9")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("txtClsGroupAccPartTimeHoursWorked9")).clear();
		driver.findElement(By.id("txtClsGroupAccPartTimeHoursWorked9")).sendKeys("10");
		Thread.sleep(500);
		
		Select payPeriod1 = new Select(driver.findElement(By.id("selectClsGroupAccPartTimePayPeriod9")));
		payPeriod1.selectByIndex(3);
		Thread.sleep(300);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),950);
		Thread.sleep(1000);
		
		driver.findElement(By.id("chkLeaveOfAbsenceGroupAcc9")).click();
		driver.findElement(By.id("btnLeaveOfAbsenceGroupAcc9")).click();
		driver.findElement(By.xpath("/html/body/div[32]/div/div[3]/ul[3]/li[5]/div")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("chkInjuryOrSicknessGroupAcc9")).click();
		driver.findElement(By.id("btnInjuryOrSicknessGroupAcc9")).click();
		driver.findElement(By.xpath("/html/body/div[33]/div/div[3]/ul[3]/li[5]/div")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("chkPartTimeStatusGroupAcc9")).click();
		driver.findElement(By.id("btnPartTimeStatusGroupAcc9")).click();
		driver.findElement(By.xpath("/html/body/div[34]/div/div[3]/ul[3]/li[5]/div")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("chkLayoffGroupAcc9")).click();
		driver.findElement(By.id("btnLayoffGroupAcc9")).click();
		driver.findElement(By.xpath("/html/body/div[35]/div/div[3]/ul[3]/li[5]/div")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("chkStrikeGroupAcc9")).click();
		driver.findElement(By.id("btnStrikeGroupAcc9")).click();
		driver.findElement(By.xpath("/html/body/div[36]/div/div[3]/ul[3]/li[5]/div")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("txtClsTempAddComments9")).clear();
		driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("Good Job");
		
		*/
		
		// for eli=135
		driver.findElement(By.id("rdnArePartTimeEmpCoveredGroupAccNo9")).click();
		Thread.sleep(200);
		
		driver.findElement(By.id("rdnArePartTimeEmpCoveredGroupAccYes9")).click();
		Thread.sleep(200);
		
		driver.findElement(By.id("txtClsGroupAccPartTimeHoursWorked9")).clear();
		driver.findElement(By.id("txtClsGroupAccPartTimeHoursWorked9")).sendKeys("10");
		
		driver.findElement(By.id("txtClsTempAddComments9")).clear();
		driver.findElement(By.id("txtClsTempAddComments9")).sendKeys("Good Job");
		
		
    }

}
