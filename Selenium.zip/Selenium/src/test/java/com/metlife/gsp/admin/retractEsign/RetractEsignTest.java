package com.metlife.gsp.admin.retractEsign;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class RetractEsignTest {
	
	private static WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    
    @Test
    public void retractEsignTest() throws NoSuchElementException, ElementNotFoundException, ElementNotVisibleException, InterruptedException {
       
    	  driver.findElement(By.id("RFPID")).sendKeys("1-1F5MT2"); 
          driver.findElement(By.id("SearchButtonIntUser")).click();
          driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
          driver.findElement(By.id("editCustomer")).click();
          driver.findElement(By.id("leftNavAdminInfo")).click();
          driver.manage().window().maximize();
          
          JavascriptExecutor js = (JavascriptExecutor)driver;
          driver.findElement(By.id("breadRetractEsign")).click();
          Thread.sleep(2000);
          driver.findElement(By.id("btnSecMgnmtHeaderYes")).click();
          Thread.sleep(2000);
          js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"btnReturnToDashMangGATPA\"]")));
          Thread.sleep(2000);
     	  js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"logoutLink\"]")));
     	  Thread.sleep(2000);
     	  js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"btnlogoutYes\"]")));
          driver.close();
                 
    }
    
	@AfterClass
	public static void after() throws InterruptedException {
		Thread.sleep(2000);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.close();
	}
}
