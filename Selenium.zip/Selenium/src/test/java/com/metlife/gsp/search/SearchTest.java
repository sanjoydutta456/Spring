package com.metlife.gsp.search;

import static org.junit.Assert.assertTrue;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;

public class SearchTest {

	private static WebDriver driver;
    private static Login_DEV login;
	
    @BeforeClass
    public static void setUp() {
    	login = new Login_DEV();
    	driver=login.setUp();
    }

	private void clearData() {
		driver.findElement(By.id("RFPID")).clear();
		driver.findElement(By.id("customerName")).clear();
		driver.findElement(By.id("prospectNo")).clear();
		driver.findElement(By.id("custNumber")).clear();
		driver.findElement(By.id("brokerNumber")).clear();
		driver.findElement(By.id("brokerFirstName")).clear();
		driver.findElement(By.id("brokerLastName")).clear();
		driver.findElement(By.id("SSAEmpId")).clear();
		driver.findElement(By.id("implementerLastName")).clear();
		driver.findElement(By.id("implementerFirstName")).clear();
		driver.findElement(By.id("effectiveDate")).clear();
	}
	
	private void sendAndClickEle(String component, String value, Boolean isFound) throws InterruptedException {
		
		clearData();
		Thread.sleep(1000);
		driver.findElement(By.id(component)).sendKeys(value);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"SearchButtonIntUser\"]")).click();

		if (isFound) {
			Thread.sleep(1000);
			assertTrue(driver.findElement(By.id("searchTableDetailsFragment")).isDisplayed());
		} else {
			Thread.sleep(1000);
			assertTrue(driver.findElement(By.className("emptyResult")).isDisplayed());
		}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void searchResultByCustNameNotFound() throws InterruptedException {
		sendAndClickEle("customerName", "XYZ", false);
		
	}

	@Test
	public void searchResultByRFPIdNotFound() throws InterruptedException {
		sendAndClickEle("RFPID", "RFPID-1234556", false);
	}

	@Test
	public void searchResultByProspectNumNotFound() throws InterruptedException {
		sendAndClickEle("prospectNo", "P0000001", false);
	}

	@Test
	public void searchResultByCustNumNotFound() throws InterruptedException {
		sendAndClickEle("custNumber", "1111111", false);
	}

	@Test
	public void searchResultByBrokerNumNotFound() throws InterruptedException {
		sendAndClickEle("brokerNumber", "1111111", false);
	}
	
	@Test
	public void searchResultByBrokerFNNotFound() throws InterruptedException {
		sendAndClickEle("brokerFirstName", "FIRST", false);
	}

	@Test
	public void searchResultByBrokerLNNotFound() throws InterruptedException {
		sendAndClickEle("brokerLastName", "LAST", false);
	}
	
	@Test
	public void searchResultByImplIDNotFound() throws InterruptedException {
		sendAndClickEle("SSAEmpId", "123456", false);
	}
	
	
	@Test
	public void searchResultByImplFNNotFound() throws InterruptedException {
		sendAndClickEle("implementerFirstName", "XXXXXXXXX", false);
	}
	

	@Test
	public void searchResultByImplLNNotFound() throws InterruptedException {
		sendAndClickEle("implementerLastName", "XXXXXXXXX", false);
	}
	
	
	@Test
	public void searchResultByEffDtNotFound() throws InterruptedException {
		sendAndClickEle("effectiveDate", "01/18/2019", false);
	}
	
	/*@Test
	public void searchResultByEffDtFound() {
		sendAndClickEle("effectiveDate", "01/18/2019", true);
	}*/
	
	@Test
	public void searchResultByImplLNFound() throws InterruptedException {
		sendAndClickEle("implementerLastName", "Riehl", false);
	}
	
	@Test
	public void searchResultByImplFNFound() throws InterruptedException {
		sendAndClickEle("implementerFirstName", "Laura", false);
	}
	
	@Test
	public void searchResultByImplIDFound() throws InterruptedException {
		sendAndClickEle("SSAEmpId", "9697911", false);
	}
	
	@Test
	public void searchResultByBrokerLNFound() throws InterruptedException {
		sendAndClickEle("brokerLastName", "SAHU", true);
	}	
	@Test
	public void searchResultByBrokerFNFound() throws InterruptedException {
		sendAndClickEle("brokerFirstName", "JASMIN", true);
	}
	@Test
	public void searchResultByBrokerNumFound() throws InterruptedException {
		sendAndClickEle("brokerNumber", "R000000087", true);
	}

	@Test
	public void searchResultByProspectNumFound() throws InterruptedException {
		sendAndClickEle("prospectNo", "P3032231", true);
	}

	@Test
	public void searchResultByRFPIdFound() throws InterruptedException {
		sendAndClickEle("RFPID", "0061100000DVvsdAAD", true);
	}

	@Test
	public void searchResultByCustNumFound() throws InterruptedException {
		sendAndClickEle("custNumber", "700434", true);
	}

	@Test
	public void searchResultByCustNameFound() throws InterruptedException {
		sendAndClickEle("customerName", "fea", true);
		
		 /* if(driver.findElement(By.id("searchTableDetailsFragment")).
		 * isDisplayed()){ driver.manage().timeouts().implicitlyWait(2,
		 * TimeUnit.SECONDS); WebElement we =
		 * driver.findElements(By.id("editCustomer")).get(0); we.click(); }*/
		 
	}
	
	@Test
	public void searchResultByStatusFound() throws InterruptedException{
		clearData();
		Select statusDrpDwn= new Select(driver.findElement(By.id("appStatus")));
		statusDrpDwn.selectByVisibleText("In Progress");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		Thread.sleep(1000);
		assertTrue(driver.findElement(By.id("searchTableDetailsFragment")).isDisplayed());
		statusDrpDwn.deselectAll();
	}

	@AfterClass
	public static void after() throws InterruptedException {
		Thread.sleep(2000);
        WebElement logOut = driver.findElement(By.id("logoutLink"));
        logOut.click();
        Thread.sleep(1000);
        WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
        yesButton.click();
        Thread.sleep(1000);
        driver.close();
	}

}



