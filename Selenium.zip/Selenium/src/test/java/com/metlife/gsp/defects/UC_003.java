package com.metlife.gsp.defects;

import static org.junit.Assert.assertTrue;


import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_INT;

public class UC_003 {

	
	private WebDriver driver;
    private Login_INT login;
	
    @Before
    public void setUp() {
    	login = new Login_INT();
    	driver=login.setUp();
    }
    @Test
    public void succeeded() throws NoSuchElementException,ElementNotFoundException, InterruptedException{
    	
    	 JavascriptExecutor js = (JavascriptExecutor)driver; 
         driver.findElement(By.id("RFPID")).sendKeys("1-1F5MT2"); 
         driver.findElement(By.id("SearchButtonIntUser")).click();
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
         driver.findElement(By.id("editCustomer")).click();
         
         Thread.sleep(2000);
         js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"navDashBillingSetupInfo\"]")));
       
        Thread.sleep(2000);
        Select drpBilling= new Select(driver.findElement(By.id("selectBillTypePerProd")));
        
        //Direct Billing
        drpBilling.selectByIndex(1);
        Thread.sleep(2000);
        assertTrue("testcase failed",driver.findElement(By.id("divDataBillDisplay")).isDisplayed());
        System.out.println("test case passed for Direct Bill");
        
        //List Billing
        drpBilling.selectByIndex(2);
        Thread.sleep(2000);
        assertTrue("testcase failed",driver.findElement(By.id("divDataBillDisplay")).isDisplayed());
        System.out.println("test case passed for List Billing");
 
        //Defect ID � 39098
         if(driver.findElement(By.xpath("//*[@id=\"divShowHidBillGenerate\"]/div/div/span")).getText().contentEquals("MetLife Bill Generated Day"))
         	{
        	    System.out.println(driver.findElement(By.xpath("//*[@id=\"divShowHidBillGenerate\"]/div/div/span")).getText());
        	    System.out.println("Test Case 1 passed");
        	}
         else
        	    System.out.println("Test Case 1 failed"); 
        	 
        
     /*   //List Billing through Metlink
        drpBilling.selectByIndex(3);
        Thread.sleep(2000);
        Assert.assertFalse("testcase failed",driver.findElement(By.id("divDataBillDisplay")).isDisplayed());
        System.out.println("test case passed for SAP");
        //System.out.println("test case passed for List Billing through Metlink");
        
        //SAP
        //drpBilling.selectByIndex(4);
        drpBilling.selectByVisibleText("Self Administered billing ");
        Thread.sleep(2000);
        Assert.assertFalse("testcase failed",driver.findElement(By.id("divDataBillDisplay")).isDisplayed());
        System.out.println("test case passed for SAP");
        
        // SAP through Paper
        drpBilling.selectByIndex(5);
        Thread.sleep(2000); 
        assertTrue("testcase failed",driver.findElement(By.id("divDataBillDisplay")).isDisplayed());
        System.out.println("test case passed for SAP through Paper");
        */
       
        // CR billing medium Remove -[EBS-878]
        Thread.sleep(2000);
        try {
        Assert.assertTrue("testcase failed",driver.findElement(By.id("selectBillingMedium")).isDisplayed());
       
        }
        catch(Exception e)
        {
        	 System.out.println("test case passed");
        }
        
        // File Details tab Defect- 38501
        try {
        	Thread.sleep(2000);
        	Assert.assertTrue("testcase failed",driver.findElement(By.id("billingFileDeatilsTab")).isDisplayed());
        	System.out.println("Test case passed for file details tab");
        	}
        catch(Exception e){
        	System.out.println("test case failed for File details tab");
        	} 
	    //Logout and quit
	      Thread.sleep(1000);
	      WebElement logOut = driver.findElement(By.id("logoutLink"));
	      logOut.click();
	      Thread.sleep(1000);
	      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
	      yesButton.click();
	      Thread.sleep(1000);
	      driver.quit();
    }
	
}
