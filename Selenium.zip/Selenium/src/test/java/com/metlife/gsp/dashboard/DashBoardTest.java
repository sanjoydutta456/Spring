package com.metlife.gsp.dashboard;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_INT;

public class DashBoardTest {

	private WebDriver driver;
	private Login_INT login;
	private boolean iterationFlag;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}
	
	/*private void logoutTest(){
		 WebElement logoutLink =driver.findElement(By.linkText("logoutLink"));
				 logoutLink.click();
				 driver.findElement(By.id("btnlogoutYes")).click();
				 
				 driver.close();
				
				  WebElement helpLink =driver.findElement(By.linkText("dashHelpFAQLinkId"));
				  helpLink.click(); WebElement hereLink
				  =driver.findElement(By.linkText("dashHelpFAQLinkId")); hereLink.click();
				 

				
				  if(driver.findElement(By.id("rdnCustomerApprovalIntUser0")).isSelected()) {
				  driver.findElement(By.id("rdnCustomerApprovalIntUser1")).click(); }
				//WebElement we = myWaitVar.until(ExpectedConditions.elementToBeClickable(By.id("leftNavSummary")));
				 
	}*/
	
	private void returnToHome(){
		
		WebElement homeEle = driver.findElement(By.className("summary"));
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}
	private void returnToHomeforBroker(){
		WebElement homeEle = driver.findElement(By.className("summary"));
		if(!iterationFlag){
			driver.manage().window().maximize();
			iterationFlag = true;
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("scroll(250,0)");
		}
		homeEle.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("btnleftNavigationYes")).click();
	}
	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		
		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MT1");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();

		
		

		// broker producer information
		try {
		WebElement brokerProducerInformationLink = driver.findElement(By.linkText("Broker Producer Information"));
		if (brokerProducerInformationLink.isDisplayed()) {
			brokerProducerInformationLink.click();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			assertTrue(driver.findElement(By.id("divBrokerProdInfoProducerDetails")).isDisplayed());
		}
		returnToHome();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		catch(Exception e) {}
		
		
		// customer information
				WebElement customerInformationLink = driver.findElement(By.id("navDashCustInfoBroker"));
				if (customerInformationLink.isDisplayed()) {
					customerInformationLink.click();
					driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					assertTrue(driver.findElement(By.id("divCustomerTab")).isDisplayed());
				}
				returnToHomeforBroker();
		
		// complete/submit
				WebElement completeSubmitLink = driver.findElement(By.id("navDashAuthSignBroker"));
						if (completeSubmitLink.isDisplayed()) {
							completeSubmitLink.click();
							assertTrue(driver.findElement(By.id("divAuthorizationContent")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
						}
						returnToHome();
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		// initial setup information	
				WebElement initialSetupInformationLink = driver.findElement(By.id("navDashInitialSetupInfo"));
						if (initialSetupInformationLink.isDisplayed()) {
							initialSetupInformationLink.click();
							assertTrue(driver.findElement(By.id("divCustCustomerDetailsContent")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
						}
						returnToHome();
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						
		// distribution channel
		WebElement distributionChannelLink = driver.findElement(By.id("navDashAltDisChn"));
				if (distributionChannelLink.isDisplayed()) {
					distributionChannelLink.click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					assertTrue(driver.findElement(By.id("divBrokerAltDistrChann")).isDisplayed());
					}
				returnToHome();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		// products sold
		WebElement productsSoldLink = driver.findElement(By.id("navDashProductsSold"));
				if (productsSoldLink.isDisplayed()) {
					productsSoldLink.click();
					assertTrue(driver.findElement(By.id("divBrkContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				}
				returnToHome();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		// class setup information
		WebElement classSetupInformationLink = driver.findElement(By.id("navDashClass"));
			if (classSetupInformationLink.isDisplayed()) {
				classSetupInformationLink.click();
				assertTrue(driver.findElement(By.id("divClassSetupContent")).isDisplayed());
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			}
				returnToHome();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		// billing information
		WebElement billingInformationLink = driver.findElement(By.id("navDashBillInfo"));
				if (billingInformationLink.isDisplayed()) {
					billingInformationLink.click();
					assertTrue(driver.findElement(By.id("divbillingSetUpContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				}
					returnToHome();
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//Billing Setup			
		WebElement billingSetupLink = driver.findElement(By.id("navDashBillingSetupInfo"));
				if (billingSetupLink.isDisplayed()) {
					billingSetupLink.click();
					assertTrue(driver.findElement(By.id("divbillingSetUpContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
					}
					returnToHome();
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					
					
		//Billing File				
		WebElement billingFileLink = driver.findElement(By.id("navDashBillingFileDetailsInfo"));
				if (billingFileLink.isDisplayed()) {
					billingFileLink.click();
					assertTrue(driver.findElement(By.id("divbillingFileDetailsContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
								
		//Billing Contact				
		WebElement billingContactsLink = driver.findElement(By.id("navDashBillingContacts"));
				if (billingContactsLink.isDisplayed()) {
					billingContactsLink.click();
					assertTrue(driver.findElement(By.id("divbillingContactContentId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					
		//Product Setup					
		WebElement productsInformationLink = driver.findElement(By.id("navDashProductsInformation"));
				if (productsInformationLink.isDisplayed()) {
					productsInformationLink.click();
					assertTrue(driver.findElement(By.id("divBrkPrimaryBrokerApp")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}			
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
											
		// general product information
		WebElement generalProductInformationLink = driver.findElement(By.id("navDashGeneralProductInfo"));
				if (generalProductInformationLink.isDisplayed()) {
					generalProductInformationLink.click();
					assertTrue(driver.findElement(By.id("divBrkPrimaryBrokerApp")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					
		//Life
			try {
		WebElement lifeLink = driver.findElement(By.id("navDashLife"));
				if (lifeLink.isDisplayed()) {
					lifeLink.click();
					assertTrue(driver.findElement(By.id("divProductSetupLifeId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					catch(Exception e) {}
		// dental
					try {
		WebElement dentalLink = driver.findElement(By.id("navDashDental"));
				if (dentalLink.isDisplayed()) {
					dentalLink.click();
					assertTrue(driver.findElement(By.id("divProductSetupDentalId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					catch(Exception e) {}
		// disability
			try {
		WebElement disabilityLink = driver.findElement(By.id("navDashDisability"));
				if (disabilityLink.isDisplayed()) {
					disabilityLink.click();
					assertTrue(driver.findElement(By.id("divProductSetupDisabilityId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					catch(Exception e){}
							
					
		// vision
			try {
		WebElement visionLink = driver.findElement(By.id("navDashVision"));
				if (visionLink.isDisplayed()) {
					visionLink.click();
					assertTrue(driver.findElement(By.id("divProductSetupVisionId")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					returnToHome();
					//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					catch(Exception e) {}
		//Critical Illness
			try {
				WebElement CriticalLink = driver.findElement(By.id("navDashCritIll"));
						if (CriticalLink.isDisplayed()) {
							CriticalLink.click();
							assertTrue(driver.findElement(By.id("divProductSetupCI")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							returnToHome();
							//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							catch(Exception e) {}
		// Hospital Identity
			try {
				WebElement HospitalLink = driver.findElement(By.id("navDashHosIndemn"));
						if (HospitalLink.isDisplayed()) {
							HospitalLink.click();
							assertTrue(driver.findElement(By.id("divProductHospitalIndm")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							returnToHome();
							//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							catch(Exception e) {}
			
			// Group Accident
						try {
							WebElement GroupLink = driver.findElement(By.id("navDashGroupAcc"));
									if (GroupLink.isDisplayed()) {
										GroupLink.click();
										assertTrue(driver.findElement(By.id("divProductGroupAccidentId")).isDisplayed());
										driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
										}
										returnToHome();
										//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
										}
										catch(Exception e) {}
			//Hyatt
			try {
				WebElement HyattLink = driver.findElement(By.id("navDashHyatt"));
						if (HyattLink.isDisplayed()) {
							HyattLink.click();
							assertTrue(driver.findElement(By.id("divProductHyattId")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							returnToHome();
							//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							catch(Exception e) {}
			
			//Property & Casualty
			try {
				WebElement propertyLink = driver.findElement(By.id("navDashPropCas"));
						if (propertyLink.isDisplayed()) {
							propertyLink.click();
							assertTrue(driver.findElement(By.id("divProductPropertyCasualtyId")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							returnToHome();
							//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							catch(Exception e) {}
			//WSTD
			try {
				WebElement wstdLink = driver.findElement(By.id("navDashWstd"));
						if (wstdLink.isDisplayed()) {
							wstdLink.click();
							assertTrue(driver.findElement(By.id("divProductWstdId")).isDisplayed());
							driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							returnToHome();
							//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
							}
							catch(Exception e) {}
			
		
			
		//Authorisation and Submit					
		WebElement authorisationSubmitLink = driver.findElement(By.id("navDashAuthSign"));
				if (authorisationSubmitLink.isDisplayed()) {
					authorisationSubmitLink.click();
					assertTrue(driver.findElement(By.id("divAuthorizationContent")).isDisplayed());
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}			
					returnToHome();
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					
					
					//JavascriptExecutor js = (JavascriptExecutor) driver;
					
	/*try {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement logoutLink = driver.findElement(By.id("logoutLink"));
		js.executeScript("arguments[0].scrollIntoView();", logoutLink);
		if(logoutLink.isDisplayed()) {
			logoutLink.click();
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.findElement(By.id("btnlogoutYes")).click();
		 
	}
	catch(Exception e)
	{}
		*/
					try {
			
						Thread.sleep(500);
						driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
						
						//WebElement logoutLink = driver.findElement(By.id("logoutLink"));
						if(driver.findElement(By.id("logoutLink")).isDisplayed()) {
							js.executeScript("arguments[0].click();",  driver.findElement(By.id("logoutLink")));
							Thread.sleep(500);
						js.executeScript("arguments[0].click();",  driver.findElement(By.id("btnlogoutYes")));
						 
						}
					}catch (Exception e) {}					
					//driver.close();
		
	}

}
