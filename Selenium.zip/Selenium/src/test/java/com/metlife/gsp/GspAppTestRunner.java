package com.metlife.gsp;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import com.metlife.gsp.GspAppSeleniumTest.GSPTestSuite;


public class GspAppTestRunner {

		  public static void main(String[] args) throws IOException {
			  
			String testresult = "PASS";  			 
		    Result result = JUnitCore.runClasses(GSPTestSuite.class);
		    
		    for (Failure failure : result.getFailures()) {
		      System.out.println(failure.toString());
		      testresult = "FAILED";
		      GSPSeleniumReport.gspReportGenerator(testresult); 
		    } 

		     testresult = "PASS"; 
		     GSPSeleniumReport.gspReportGenerator(testresult);

		    GSPSeleniumReport.gspReportGenerator(testresult); 
		    System.out.println("Test Result " +testresult);
		    System.out.println("Was Successful.?"+result.wasSuccessful());
		    System.out.println("Total Run Count : "+result.getRunCount());         
		  }		

}
