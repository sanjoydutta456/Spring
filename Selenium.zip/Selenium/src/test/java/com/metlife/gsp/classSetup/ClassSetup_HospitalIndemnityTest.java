package com.metlife.gsp.classSetup;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.metlife.gsp.login.Login_DEV;
import com.metlife.gsp.login.Login_INT;

public class ClassSetup_HospitalIndemnityTest {

	private WebDriver driver;
	private Login_INT login;

	@Before
	public void setUp() {
		login = new Login_INT();
		driver = login.setUp();
	}

	@Test
	public void succeeded() throws NoSuchElementException, ElementNotFoundException, ElementNotInteractableException,
			InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		WebElement oppID = driver.findElement(By.id("RFPID"));
		oppID.sendKeys("1-1F5MS2");
		driver.findElement(By.id("SearchButtonIntUser")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("editCustomer")).click();

		driver.manage().window().maximize();

		driver.findElement(By.id("navDashClass")).click();

		Thread.sleep(8000);

		WebElement addClass = driver.findElement(By.id("btnClsSetupAddClass"));
		if (addClass.isDisplayed()) {
			addClass.click();
			Thread.sleep(300);

		}

		Select classDescription = new Select(driver.findElement(By.id("selectClsDesc1")));
		classDescription.selectByIndex(19);
		Thread.sleep(100);
		driver.findElement(By.id("txtClsTempClassDescription1")).clear();
		driver.findElement(By.id("txtClsTempClassDescription1")).sendKeys("CCD");

		driver.findElement(By.id("rdnClsTempDoesClassIncRetireNo1")).click();
		Thread.sleep(300);
		driver.findElement(By.id("rdnClsTempDoesClassIncRetireYes1")).click();
		Thread.sleep(300);

		driver.findElement(By.id("rdnClsTempOpenClass1")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass1")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionOpenClass1")).sendKeys("OOO");
		driver.findElement(By.id("rdnClsTempClosedClass1")).click();
		Thread.sleep(300);
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass1")).clear();
		driver.findElement(By.id("txtClsTempEligibilityDefinitionClosedClass1")).sendKeys("CCC");
		Thread.sleep(600);

		js.executeScript("arguments[0].scrollTop = arguments[1];", driver.findElement(By.id("divClassSetUp")), 600);

		driver.findElement(By.id("HospitalIndemnity1")).click();
		Thread.sleep(500);

		js.executeScript("arguments[0].scrollTop = arguments[1];", driver.findElement(By.id("divClassSetUp")), 950);
		Thread.sleep(1000);
		
		driver.findElement(By.id("chkClsSelect406001_1_0")).click();
		Thread.sleep(150);
		
		driver.findElement(By.id("txtClassSetHospIndmNumEmpEligibles_1_0")).clear();
		driver.findElement(By.id("txtClassSetHospIndmNumEmpEligibles_1_0")).sendKeys("1");;
		
		driver.findElement(By.id("txtClassSetHospIndemnEmpContriEmployee_1_0")).clear();
		driver.findElement(By.id("txtClassSetHospIndemnEmpContriEmployee_1_0")).sendKeys("2");;
		
		driver.findElement(By.id("txtClassHIPartialContribution_1_0")).clear();
		driver.findElement(By.id("txtClassHIPartialContribution_1_0")).sendKeys("3");;
		
		driver.findElement(By.id("rdnClassExpatriatesImpatriatesHINo1")).click();
		Thread.sleep(200);
		
		driver.findElement(By.id("rdnClassExpatriatesImpatriatesHIYes1")).click();
		Thread.sleep(200);
		
		driver.findElement(By.id("txtClsTempHoursWorkedHI1")).clear();
		driver.findElement(By.id("txtClsTempHoursWorkedHI1")).sendKeys("5");
		
		
		Select payPeriod = new Select(driver.findElement(By.id("selectClsTempPayPeriodHI1")));
		payPeriod.selectByIndex(4);
		Thread.sleep(500);
		
		driver.findElement(By.id("rdnArePartTimeEmpCoveredHINo1")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("rdnArePartTimeEmpCoveredHIYes1")).click();
		Thread.sleep(400);
		
		driver.findElement(By.id("txtClsHIPartTimeHoursWorked1")).clear();
		driver.findElement(By.id("txtClsHIPartTimeHoursWorked1")).sendKeys("10");
		
		
		Select payPeriod1 = new Select(driver.findElement(By.id("selectClsHIPartTimePayPeriod1")));
		payPeriod1.selectByIndex(4);
		Thread.sleep(500);
		
		
		
		driver.findElement(By.id("chkLeaveOfAbsenceHI1")).click();
		driver.findElement(By.id("txtLeaveOfAbsenceDtHI1")).clear();
		driver.findElement(By.id("txtLeaveOfAbsenceDtHI1")).sendKeys("03/01/2019");;
		Thread.sleep(400);

		driver.findElement(By.id("chkInjuryOrSicknessHI1")).click();
		driver.findElement(By.id("txtInjuryOrSicknessDtHI1")).clear();
		driver.findElement(By.id("txtInjuryOrSicknessDtHI1")).sendKeys("03/01/2019");
		Thread.sleep(400);

		
		driver.findElement(By.id("chkPartTimeStatusHI1")).click();
		driver.findElement(By.id("txtPartTimeStatusDtHI1")).clear();
		driver.findElement(By.id("txtPartTimeStatusDtHI1")).sendKeys("03/01/2019");
		Thread.sleep(400);
		
		driver.findElement(By.id("chkLayoffHI1")).click();
		driver.findElement(By.id("txtPartTimeStatusDtHI1")).clear();
		driver.findElement(By.id("txtPartTimeStatusDtHI1")).sendKeys("03/01/2019");
		Thread.sleep(400);
		
		driver.findElement(By.id("chkStrikeHI1")).click();
		driver.findElement(By.id("txtStrikeDtHI1")).clear();
		driver.findElement(By.id("txtStrikeDtHI1")).sendKeys("03/01/2019");
		Thread.sleep(400);
		
		js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),600);
		driver.findElement(By.id("txtClsTempAddComments1")).clear();
		driver.findElement(By.id("txtClsTempAddComments1")).sendKeys("Good Job");
		Thread.sleep(400);
		
		
		
		
		

	}
}
