package com.metlife.gsp.defects;

import java.util.List;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UC_004_EBS_873 {

	@Test
	public void testLT1000Logic() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:/Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev.custadmin.metlife.com/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement username = driver.findElement(By.id("USER"));
        WebElement password = driver.findElement(By.id("PASSWORD"));
        WebElement signIn = driver.findElement(By.id("cmdEnter"));
      
      //Check the value of Eligible Lives
      username.sendKeys("gspcatqauser1");
      Thread.sleep(1000);
      password.sendKeys("metlife1");
      Thread.sleep(1000);
      signIn.click();
      WebElement caseID =driver.findElement(By.id("RFPID"));
      Thread.sleep(2000);
      String oppurnityID = "1-1F5MT1"; 
      caseID.sendKeys(oppurnityID);
      Thread.sleep(1000);
      WebElement search =driver.findElement(By.id("SearchButtonIntUser"));
      search.click();
      Thread.sleep(2000);
      WebElement edit =driver.findElement(By.id("editCustomer"));
      edit.click();
      Thread.sleep(500);
      WebElement custInfo = driver.findElement(By.id("navDashCustInfo"));
      custInfo.click();
      Thread.sleep(3000);
      WebElement eligibleLives = driver.findElement(By.id("txtCustEligibleEmployees"));
      System.out.println("Eligible Lives for Opportunity id: " +  oppurnityID + " is " + eligibleLives.getAttribute("value"));   
        
      //Class Setup
      Thread.sleep(3000);
      WebElement classSetup = driver.findElement(By.id("breadcrumbToClass"));
      classSetup.click();
      Thread.sleep(1000);
      WebElement noButton = driver.findElement(By.id("btnBreadcrumbNo"));
      noButton.click();
      Thread.sleep(8000);
      WebElement editAndReview = driver.findElement(By.id("btnClsTempEditReview0"));
      editAndReview.click();
      Thread.sleep(1000);
      JavascriptExecutor js = ((JavascriptExecutor)driver);
      js.executeScript("arguments[0].scrollTop = arguments[1];",driver.findElement(By.id("divClassSetUp")),1000);
      Thread.sleep(1000);
      List<WebElement> selectUnderCoverage = driver.findElements(By.id("selectClassLifeEmploymentEnds0"));
      if(selectUnderCoverage.size()==1)
      {
    	  System.out.println("Coverage block is getting displayed");
      }
      else if(selectUnderCoverage.size()==0)
      {
    	  System.out.println("Coverage block is not getting displayed");
      }
      Thread.sleep(2000);
      WebElement closeBtnCls = driver.findElement(By.id("closeBtn0"));
      closeBtnCls.click();
      Thread.sleep(1000);
      closeBtnCls.click();
      
      //Logout and quit
      Thread.sleep(1000);
      WebElement logOut = driver.findElement(By.id("logoutLink"));
      logOut.click();
      Thread.sleep(1000);
      WebElement yesButton = driver.findElement(By.id("btnlogoutYes"));
      yesButton.click();
      Thread.sleep(1000);
      driver.quit();
      
	}
	
}
