import DataUsage

d = DataUsage.DataUsage();
dataUsageList = d.parseCSV("datausage.csv");
    
while 1:
    print "1)List Customers\n2)Generate usage details for single customers\n3)Generate usage details for all customers\n4)Exit\nSelect Option"
    option = raw_input();
    try:
        if int(option) == 1:
            customerList = d.listCustomers(dataUsageList)
            i = 0;
            for cus in customerList:
                print str(i+1)+") "+str(cus);
                i = i+1;
        elif int(option) == 2:        
            validCustomer = None;
            while 1:
                cus = raw_input("Enter the customer id\n");
                validCustomer = d.searchCustomer(cus,dataUsageList)
                if validCustomer == None:
                    print "Customer not found.Please enter the valid customer id";
                else:
                    break;
            print "validCustomer "+str(validCustomer)
            if not validCustomer is None:
                print "Date\tPulse\tAmount"
                validCustomer.displayCustomerUsage(dataUsageList);
                cusDataUsageMap = validCustomer.getUsageDetails(dataUsageList,validCustomer.getCustomerId())
                print "Customer\tMin Usage\tMax Usage\tTotal Usage";
                li = cusDataUsageMap[cus]
                print str(cus)+"\t"+str(li[0])+"\t"+str(li[1])+"\t"+str(li[2])                      
        elif int(option) == 3:
            print "Customer\tMin Usage\tMax Usage\tTotal Usage";
            cusDataUsageMap = d.getUsageDetails(dataUsageList,None);
            for key in cusDataUsageMap.keys():
                li = cusDataUsageMap[key];
                print str(key)+"\t"+str(li[0])+"\t"+str(li[1])+"\t"+str(li[2])
        elif int(option) == 4:
            print "Exit";
            break;
        else:
            print "Invalid option.\nEnter the valid option";
    except:
        print "Invalid option.\nEnter the valid option";