from datetime import datetime
import csv


class DataUsage:
    def __init__(self = None,customerId = None,usageDate = None,pulse = None,amount = None):
        self.customerId = customerId;
        self.usageDate = usageDate;
        self.pulse = pulse;
        self.amount = amount;
        
    def getCustomerId(self):
        return self.customerId;
    
    def getUsageDate(self):
        return self.usageDate;
    
    def getPulse(self):
        return self.pulse;
    
    def getAmount(self):
        return self.amount;
    
    def parseCSV(self,filePath):
        dataUsageList = [];
        with open(filePath, 'rb') as csvfile:    
            monthlyBill = csv.reader(csvfile, delimiter=',', quotechar='|')            
            for i, row in enumerate(monthlyBill, start=0):
                if(i > 0):
                    du = DataUsage(row[0],row[1]+" "+row[2],row[3],row[4]);
                    dataUsageList.append(du);
        return dataUsageList
    
    def listCustomers(self,dataUsageList):        
        customerList = []
        for du in dataUsageList:
            customerList.append(du.getCustomerId())
        customerList = list(set(customerList))
        return customerList
    
    def searchCustomer(self,cus,dataUsageList):
        for du in dataUsageList:
            if du.getCustomerId() == cus:
                return du
        return None;
    
    def displayCustomerUsage(self,dataUsageList): 
        for cus in dataUsageList:
            if cus.getCustomerId() == self.getCustomerId():
                print cus.getUsageDate()+"\t"+cus.getPulse()+"\t"+cus.getAmount()
         
                
    def getUsageDetails(self,dataUsageList,cus):
        min = dataUsageList[0].getPulse();
        max = 0;
        totalUsage = 0;
        cusList = self.listCustomers(dataUsageList)
        cusDataUsageMap = {}
        for cc in cusList:
            min = 100000
            max = 0
            totalUsage = 0;
            for du in dataUsageList:
                if du.getCustomerId() == cc:
                    if int(du.getPulse()) < int(min):
                        min = du.getPulse()
                    if int(du.getPulse()) > int(max):
                        max = du.getPulse()                
                    totalUsage += int(du.getPulse())
#                    print "totalUsage ",totalUsage,", ",du.getPulse()
                    if cusDataUsageMap.has_key(du.getCustomerId()):
                        li = cusDataUsageMap[du.getCustomerId()]
                        li[0] = int(min)
                        li[1] = int(max)
                        li[2] = int(totalUsage);
                        cusDataUsageMap[du.getCustomerId()] = li
                    else :
                        cusDataUsageMap[du.getCustomerId()] = [min,max,totalUsage];
#        print "cusDataUsageMap "+str(cusDataUsageMap)
        return cusDataUsageMap
        print "Customer\tMin Usage\tMax Usage\tTotal Usage";
        if cus:
            li = cusDataUsageMap[cus]
            print str(cus)+"\t"+str(li[0])+"\t"+str(li[1])+"\t"+str(li[2])
        else :            
            for key in cusDataUsageMap.keys():
                li = cusDataUsageMap[key];
                print str(key)+"\t"+str(li[0])+"\t"+str(li[1])+"\t"+str(li[2])
        
    
    