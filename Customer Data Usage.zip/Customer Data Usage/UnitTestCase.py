import unittest
import DataUsage
import csv

class  UnitTestCase(unittest.TestCase):
    def test_parseCSV(self):        
        du = DataUsage.DataUsage()
        dataUsageList = []
        obtainedList = du.parseCSV("datausage.csv")
        with open("datausage.csv", 'rb') as csvfile:    
            monthlyBill = csv.reader(csvfile, delimiter=',', quotechar='|')            
            for i, row in enumerate(monthlyBill, start=0):
                if(i > 0):
                    du = DataUsage.DataUsage(row[0],row[1]+" "+row[2],row[3],row[4]);
                    dataUsageList.append(du);        
        self.assertTrue(len(dataUsageList) == len(obtainedList),"Passed")
        
    def test_listCustomers(self):
        customerList = []
        du = DataUsage.DataUsage()
        obtainedList = du.parseCSV("datausage.csv")
        for du in obtainedList:
            customerList.append(du.getCustomerId())
        customerList = list(set(customerList))
        cList = du.listCustomers(obtainedList)
        self.assertTrue(len(cList) == len(customerList),"Passed")
        
    def test_searchCustomer(self):
        du = DataUsage.DataUsage()
        obtainedList = du.parseCSV("datausage.csv")
        c = du.searchCustomer("CUS1101313",obtainedList)
        self.assertFalse(c == None,"Passed")

    def test_searchInvalidCustomer(self):
        du = DataUsage.DataUsage()
        obtainedList = du.parseCSV("datausage.csv")
        c = du.searchCustomer("CUS1",obtainedList)
        self.assertTrue(c == None,"Passed")
        
    def test_getUsageDetails(self):
        du = DataUsage.DataUsage()
        obtainedList = du.parseCSV("datausage.csv")
        cusDataUsageMap = du.getUsageDetails(obtainedList,"CUS1101313")
        li = cusDataUsageMap["CUS1101313"]
        c = 0;
        if li[0] == 213 and li[1] == 1425 and li[2] == 11739:
            c = 1
        self.assertTrue(c == 1,"Passed")
        
if __name__ == '__main__':
    import xmlrunner
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test'))
