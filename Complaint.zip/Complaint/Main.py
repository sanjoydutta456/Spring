import CustomerComplaint

c1 = CustomerComplaint.CustomerComplaint();

 
while 1:
  
    print "1.Create Complaint";
    print "2.Display details";
    print "3.Display details in priority order";
    print "4.Exit\nSelect Option";

    ch = raw_input();
  
    if int(ch)==1: 
        print "Enter the name";
        name = raw_input();
 
        print "Enter the mobile number";
        mobileNumber = raw_input();
  
        while 1:    
            valid = c1.validateMobileNumber(mobileNumber);
            if valid == 1:
                break;
            else:
                print "Invalid mobile number";
                print "Enter the valid mobile number";
                mobileNumber = raw_input();
  
        print "1.High";
        print "2.Medium";
        print "3.Low";
   
        print "Enter the priority";
        priority = raw_input();
    
        print "Enter the complaint";
        complaint = raw_input();
    

     
        c = CustomerComplaint.CustomerComplaint(name, mobileNumber, priority, complaint);
        f= c.insertCustomerComplaint();
        print "Complaint registered successfully";

    elif int(ch)==2: 
        complaintList = c1.getCustomerComplaints();
        for cc in complaintList:
            cc.displayComplaintDetails();
   
    elif int(ch) == 3:
        complaintList = c1.getCustomerComplaintsInOrder();
        for cc in complaintList:
            cc.displayComplaintDetails();
    elif int(ch) == 4:
        print "Exit"
        break;
    else:
        print "Invalid Option\nSelect the correct option";