import MySQLdb
import ConfigParser
import re

class CustomerComplaint:
    
    def __init__(self, name = None, mobileNumber = None, priority = None,  complaint = None):
        self.name = name or '';        
        self.mobileNumber = mobileNumber or '';
        self.priority = priority or '';
        self.complaint = complaint or '';
        
    def getName(self):
        return self.name;
        
    def getComplaint(self):
        return self.complaint;
        
    def getMobileNumber(self):
        return self.mobileNumber;
    
    
    def getPriority(self):
        return self.priority;


 
    
    def validateMobileNumber(self, pno):
        if re.match('((?=.*\\d).{10,})', pno):
            if len(pno) == 10:
                return 1;
        return 0;
    

        
    def connectToDB(self):
        config = ConfigParser.RawConfigParser()
        config.read('mysql.properties')
        dburl = config.get('DatabaseSection', 'db.host');
        dbname = config.get('DatabaseSection', 'db.schema');
        username = config.get('DatabaseSection', 'db.username');
        password = config.get('DatabaseSection', 'db.password');
        port = config.get('DatabaseSection', 'db.port');
        db = MySQLdb.connect(host=dburl, port=int(port),user=username, passwd=password, db=dbname)
        return db;
    
    def insertCustomerComplaint(self):
        db = self.connectToDB()
        cursor = db.cursor()
        sql = """INSERT INTO customer_complaint(name,mobile_number,priority,complaint) VALUES ('"""+self.getName()+"""','"""+self.getMobileNumber()+"""','"""+self.getPriority()+"""','"""+self.getComplaint()+"""');"""
        try:
            cursor.execute(sql);
            db.commit();
        except Exception, e:
            print "Error to insert a data ",e;
            db.rollback();
        db.close();
        
    def getCustomerComplaintsInOrder(self):
        complaintList = []
        db = self.connectToDB();
        cursor = db.cursor();
        sql = """select * from customer_complaint order by priority asc;"""
        c = None
        try:
            cursor.execute(sql);
            data = cursor.fetchall()
            for r in data:
                c = CustomerComplaint(r[1], r[2], r[3], r[4]);
                complaintList.append(c)
        except Exception, e:
            print "Unable to fetch data ",e;
        return complaintList;
       
    def getCustomerComplaints(self):
        complaintList = []
        db = self.connectToDB();
        cursor = db.cursor();
        sql = """select * from customer_complaint;"""
        c = None
        try:
            cursor.execute(sql);
            data = cursor.fetchall()
            for r in data:
                c = CustomerComplaint(r[1], r[2], r[3], r[4]);
                complaintList.append(c)
        except Exception, e:
            print "Unable to fetch data ",e;
        return complaintList;
     
        
    def displayComplaintDetails(self):
        print "Name : ", self.getName();        
        print "Mobile Number : ", self.getMobileNumber();
        print "Priority : ", self.getPriority();
        print "Complaint : ", self.getComplaint();
