import unittest
import CustomerComplaint
import MySQLdb
import ConfigParser

class  UnitTestCase(unittest.TestCase):
    def test_validMobileNumber(self):        
        cc = CustomerComplaint.CustomerComplaint()
        valid = cc.validateMobileNumber("9123456789")
        self.assertTrue(valid == 1,"Passed")
    
    def test_invalidMobileNumber(self):        
        cc = CustomerComplaint.CustomerComplaint()
        valid = cc.validateMobileNumber("9123456")
        self.assertTrue(valid == 0,"Passed")
        
    def test_insertCustomerComplaint(self):
        cc = CustomerComplaint.CustomerComplaint("customer1","9123456789","1","Less Network Speed")
        cc.insertCustomerComplaint();
        
        config = ConfigParser.RawConfigParser()
        config.read('mysql.properties')
        dburl = config.get('DatabaseSection', 'db.host');
        dbname = config.get('DatabaseSection', 'db.schema');
        username = config.get('DatabaseSection', 'db.username');
        password = config.get('DatabaseSection', 'db.password');
        port = config.get('DatabaseSection', 'db.port');
        db = MySQLdb.connect(host=dburl, port=int(port),user=username, passwd=password, db=dbname)
        cursor = db.cursor();
        sql = """select * from customer_complaint order by id desc limit 1"""
        cursor.execute(sql);
        data = cursor.fetchall()
        c = 0
        for r in data:
            if r[1] == "customer1" and r[2] == "9123456789" and r[3] == 1 and r[4] == "Less Network Speed":
                c = 1
        self.assertTrue(c == 1,"Passed")
        
    def test_getCustomerComplaints(self):
        cc = CustomerComplaint.CustomerComplaint("customer1","9123456789","1","Less Network Speed")
        cc.insertCustomerComplaint();
        complaintList = cc.getCustomerComplaints()
        c = 0;
        for cc in complaintList:
            if cc.getName() == "customer1" and cc.getMobileNumber() == "9123456789" and cc.getPriority() == 1 and cc.getComplaint() == "Less Network Speed":
                c = 1;
                break;
        self.assertTrue(c == 1,"Passed")
        
    def test_getCustomerComplaintsInOrder(self):
        cc = CustomerComplaint.CustomerComplaint()
        complaintList = cc.getCustomerComplaintsInOrder()
        
        config = ConfigParser.RawConfigParser()
        config.read('mysql.properties')
        dburl = config.get('DatabaseSection', 'db.host');
        dbname = config.get('DatabaseSection', 'db.schema');
        username = config.get('DatabaseSection', 'db.username');
        password = config.get('DatabaseSection', 'db.password');
        port = config.get('DatabaseSection', 'db.port');
        db = MySQLdb.connect(host=dburl, port=int(port),user=username, passwd=password, db=dbname)
        cursor = db.cursor();
        sql = """select * from customer_complaint order by priority asc;"""
        cursor.execute(sql);
        data = cursor.fetchall()
        c = 0
        i=0
        for r in data:
            if r[1] == complaintList[i].getName() and r[2] == complaintList[i].getMobileNumber() and r[3] == complaintList[i].getPriority() and r[4] == complaintList[i].getComplaint():
                c = 1
                break;
            i = i+1
        self.assertTrue(c == 1,"Passed")
        
        
if __name__ == '__main__':
    import xmlrunner
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test'))
