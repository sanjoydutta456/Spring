import urllib2
import MySQLdb
import ConfigParser
import re
import xml.etree.ElementTree as ET

class CallDetails:
    def __init__(self,customerId=None,mobileNumber=None,duration=None,amount=None):
        self.customerId = customerId or "";
        self.mobileNumber = mobileNumber or "";
        self.duration = duration or "";
        self.amount = amount or 0.0;
        
    def setCustomerId(self, customerId):
        self.customerId = customerId;
     
    def setMobileNumber(self, mobileNumber):
        self.mobileNumber = mobileNumber;
        
    def setDuration(self, duration):
        self.duration = duration;     
   
    def setAmount(self, amount):
        self.amount = amount;
        
    def getCustomerId(self):
        return self.customerId;    
        
    def getDuration(self):
        return self.duration;
    
    def getMobileNumber(self):
        return self.mobileNumber;
    
        
    def getAmount(self):
        return self.amount;
    
    def readXML(self,url):
        request = urllib2.Request(url, headers={"Accept" : "application/xml"})
        u = urllib2.urlopen(request)
        tree = ET.parse(u)
        rootElem = tree.getroot()
        return rootElem
    
    def parseXML(self,root):
        callList = []
        i = 0;
        for child in root:            
            mb = CallDetails()
            mb.setCustomerId(child.find('customerid').text)
            mb.setMobileNumber(child.find('tonumber').text)
            mb.setDuration(child.find('duration').text)
            mb.setAmount(child.find('amount').text)
            callList.append(mb)
        return callList

    def generateBill(self,callList):
        db = self.connectToDB()
        cursor = db.cursor()
        for r in callList:
            sql = """INSERT INTO call_details(customer_id,mobile_number,duration,amount) VALUES ('"""+r.getCustomerId()+"""','"""+r.getMobileNumber()+"""','"""+r.getDuration()+"""','"""+r.getAmount()+"""');"""
            try:
                cursor.execute(sql);
                db.commit();
            except Exception, e:
                print "Error to insert a data ",e;
                db.rollback();
        db.close(); 
   
    def getCallDetails(self):
        callList = []
        db = self.connectToDB();
        cursor = db.cursor();
        sql = """select * from call_details;"""
        c = None
        try:
            cursor.execute(sql);
            data = cursor.fetchall()
            for r in data:
                c = CallDetails(r[0],r[1], r[2], r[3]);
                callList.append(c)
        except Exception, e:
            print "Unable to fetch data ",e;
        print "len ",len(callList)
        return callList;
    
    def connectToDB(self):
        config = ConfigParser.RawConfigParser()
        config.read('mysql.properties')
        dburl = config.get('DatabaseSection', 'db.host');
        dbname = config.get('DatabaseSection', 'db.schema');
        username = config.get('DatabaseSection', 'db.username');
        password = config.get('DatabaseSection', 'db.password');
        port = config.get('DatabaseSection', 'db.port');
        db = MySQLdb.connect(host=dburl, port=int(port),user=username, passwd=password, db=dbname)
        return db;

    
    def displayCallDetails(self):                
        print str(self.getCustomerId())+"\t"+str(self.getMobileNumber())+"\t"+str(self.getDuration())+"\t"+str(self.getAmount());        
        
