import CallDetails
url = 'http://localhost/call.xml'
callObj = CallDetails.CallDetails()
c = CallDetails.CallDetails()
root = callObj.readXML(url)
callList = callObj.parseXML(root)
insert = 0
while True:
    print "1)Generate bill\n2)Display the bill details\n3)Exit\nSelect Option";
#    try:
    op = raw_input();
    if int(op) == 1:   
        if insert == 0 :
            f = c.generateBill(callList);            
            insert = 1
        print "Bill Generated Successfully";
    elif int(op) == 2:
        callList1 = c.getCallDetails();
        print "Customer Id\tMobile Number\tDuration\tAmount";
        for cc in callList1:
            cc.displayCallDetails();
    elif int(op) == 3:
        print "Exit"
        break;                
    else:
        print "Invalid Option.\nPlease choose the correct option";
#    except :
#        print "Invalid Option.\nPlease choose the correct option";