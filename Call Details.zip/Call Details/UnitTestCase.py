import unittest
import urllib2
import xml.etree.ElementTree as ET
import CallDetails
import ConfigParser
import MySQLdb

class  UnitTestCase(unittest.TestCase):
    def test_readXML(self):        
        cd = CallDetails.CallDetails()
        root = cd.readXML("http://test.cognizant.e-box.co.in/uploads/call.xml")
        c = 1
        for child in root:
            c += 1
        self.assertTrue(c == 6,"Passed")
        
    def test_parseXML(self):
        cd = CallDetails.CallDetails()
        request = urllib2.Request("http://test.cognizant.e-box.co.in/uploads/call.xml", headers={"Accept" : "application/xml"})
        u = urllib2.urlopen(request)
        tree = ET.parse(u)
        root = tree.getroot()
        i = 0;
        c = 0
        j=0;
        expectedBillList = []
        for child in root:            
            cd = CallDetails.CallDetails()
            cd.setCustomerId(child.find('customerid').text)
            cd.setMobileNumber(child.find('tonumber').text)
            cd.setDuration(child.find('duration').text)
            cd.setAmount(child.find('amount').text)
            expectedBillList.append(cd)
                
        root = cd.readXML("http://test.cognizant.e-box.co.in/uploads/call.xml")
        billList = cd.parseXML(root)
            
        for expectedBill in expectedBillList:
            tempCount = 0    
            obtainedBill = billList[j]  
            if(obtainedBill.getCustomerId() == expectedBill.getCustomerId()):
                tempCount += 1
            if(obtainedBill.getMobileNumber() == expectedBill.getMobileNumber()):
                tempCount += 1
            if(obtainedBill.getDuration() == expectedBill.getDuration()):
                tempCount += 1
            if(obtainedBill.getAmount() == expectedBill.getAmount()):
                tempCount += 1
            if(tempCount == 4):
                c += 1
            j += 1
        self.assertTrue(c == 5,"Passed")
    
    def test_generateBill(self):
        cd = CallDetails.CallDetails()
        cd1 = CallDetails.CallDetails("CS1111","9123443219","10:28","15")
        cd.generateBill([cd1])
        config = ConfigParser.RawConfigParser()
        
        config.read('mysql.properties')
        dburl = config.get('DatabaseSection', 'db.host');
        dbname = config.get('DatabaseSection', 'db.schema');
        username = config.get('DatabaseSection', 'db.username');
        password = config.get('DatabaseSection', 'db.password');
        port = config.get('DatabaseSection', 'db.port');
        db = MySQLdb.connect(host=dburl, port=int(port),user=username, passwd=password, db=dbname)
        cursor = db.cursor();
        sql = """select * from call_details where customer_id = 'CS1111';"""
        c = 0;
        try:
            cursor.execute(sql);
            data = cursor.fetchall()
            for r in data:
                if r[0] == "CS1111" and r[1] == "9123443219" and r[2] == "10:28" and r[3] == "15":
                    c = 1
        except Exception, e:
            c = 0
            print "Unable to fetch data ",e;
        
        self.assertTrue(c == 1,"Passed")
    
    def test_getCallDetails(self):
        cd = CallDetails.CallDetails()
        callList = cd.getCallDetails()
        c = 0
        for c in callList:
            if c.getCustomerId() == "CS1111" and c.getDuration() == "10:28" and c.getMobileNumber()  == "9123443219" and c.getAmount() == "15":
                c = 1
                break;
        self.assertTrue(c == 1,"Passed")
        
if __name__ == '__main__':
    import xmlrunner
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test'))
