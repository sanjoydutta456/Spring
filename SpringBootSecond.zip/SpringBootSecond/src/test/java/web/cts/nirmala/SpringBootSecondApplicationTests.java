package web.cts.nirmala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
