package web.cts.nirmala;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class InterestController {
	
	@RequestMapping("interest")
	public String showPage()
	{
		return "InterestCalculation";
	}
    @RequestMapping("calculation")
    
   /* public ModelAndView getCalculate(String t1,String t2,String t3)
    {
    	ModelAndView mv=new ModelAndView();
    	
    	int res=(Integer.parseInt(t1)*Integer.parseInt(t2)*Integer.parseInt(t3))/100;
    	mv.addObject("result", res);
    	mv.setViewName("ShowResult");
    	
    	return mv;
    	
    }*/
    
     public ModelAndView getCalculate(@RequestParam("t1") String t4,@RequestParam("t2") String t5,@RequestParam("t3") String t6)
    {
    	ModelAndView mv=new ModelAndView();
    	
    	int res=(Integer.parseInt(t4)*Integer.parseInt(t5)*Integer.parseInt(t6))/100;
    	mv.addObject("result", res);
    	mv.setViewName("ShowResult");
    	
    	return mv;
    	
    }
    
}
